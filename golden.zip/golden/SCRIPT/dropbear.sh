#!/bin/bash
export DEBIAN_FRONTEND=noninteractive

# COLORES
declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;32m"
[3]="\033[1;36m"
[4]="\033[1;31m"
)

barra="\033[0m\e[33m====================================================\033[1;37m"

# ROOT
[[ $(id -u) != 0 ]] && { echo -e "${cor[4]}EJECUTE COMO ROOT${cor[0]}"; exit 1; }

# DEPENDENCIAS
apt-get update -y >/dev/null 2>&1
apt-get install -y dropbear curl jq lsof unzip sudo >/dev/null 2>&1

# =================== FUNCIONES AUXILIARES ===================
fun_bar() {
    comando="$1"
    ( $comando >/dev/null 2>&1; touch /tmp/fim ) &
    tput civis
    echo -ne "\033[1;33m ["
    while true; do
        for ((i=0;i<15;i++)); do echo -ne "\033[1;32m#"; sleep 0.08; done
        [[ -e /tmp/fim ]] && { rm -f /tmp/fim; break; }
        echo -ne "\r\033[1;33m [" 
    done
    echo -e "\033[1;33m] \033[1;32mOK!\033[0m"
    tput cnorm
}

fun_trans() { echo "$@"; }
mportas() { ss -lntp 2>/dev/null | awk 'NR>1 {split($4,a,":"); print a[length(a)]}' | sort -u; }

# =================== FUNCIONES DROPBEAR ===================
instalar_dropbear() {
    clear
    echo -e "$barra"
    echo -e "${cor[3]}ESCRIBE UN PUERTO PARA DROPBEAR (RECOMENDADO 443)${cor[0]}"
    echo -e "$barra"
    while true; do
        read -p "PUERTO: " porta
        [[ -z "$porta" ]] && porta="443"
        [[ "$porta" == "22" ]] && echo -e "${cor[4]}NO USE 22${cor[0]}" && continue
        if mportas | grep -w "$porta" >/dev/null; then echo -e "${cor[4]}PUERTO EN USO${cor[0]}"; continue; fi
        break
    done

    echo -e "$barra"
    echo -e "${cor[3]}INSTALANDO DROPBEAR${cor[0]}"
    fun_bar "apt-get install dropbear -y"

    mkdir -p /etc/dropbear
    touch /etc/dropbear/banner

    cat > /etc/default/dropbear <<EOF
NO_START=0
DROPBEAR_PORT=$porta
DROPBEAR_EXTRA_ARGS="-p $porta"
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

    # Configurar SSH moderno
    sed -i '/^Port /d' /etc/ssh/sshd_config
    echo "Port 22" >> /etc/ssh/sshd_config
    sed -i 's/^#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
    sed -i 's/^#PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config

    systemctl daemon-reload
    systemctl enable ssh dropbear >/dev/null 2>&1
    systemctl restart ssh dropbear >/dev/null 2>&1

    echo -e "$barra"
    echo -e "${cor[2]}DROPBEAR INSTALADO CORRECTAMENTE en puerto ${porta}${cor[0]}"
    sleep 2
}

desinstalar_dropbear() {
    echo -e "$barra"
    echo -e "${cor[4]}REMOVIENDO DROPBEAR${cor[0]}"
    echo -e "$barra"
    systemctl stop dropbear >/dev/null 2>&1
    fun_bar "apt-get purge dropbear -y"
    apt-get autoremove -y >/dev/null 2>&1
    rm -rf /etc/dropbear
    echo -e "$barra"
    echo -e "${cor[2]}DROPBEAR ELIMINADO${cor[0]}"
    sleep 2
}

agregar_puerto() {
    echo -e "${cor[3]}AGREGAR PUERTO EXTRA${cor[0]}"
    while true; do
        read -p "Ingrese nuevo puerto: " nuevo_puerto
        [[ -z "$nuevo_puerto" ]] && echo -e "${cor[4]}Puerto inválido${cor[0]}" && continue
        if mportas | grep -w "$nuevo_puerto" >/dev/null; then echo -e "${cor[4]}Puerto ya en uso${cor[0]}"; else break; fi
    done
    echo "DROPBEAR_EXTRA_ARGS=\"-p $nuevo_puerto\"" >> /etc/default/dropbear
    systemctl restart dropbear >/dev/null 2>&1
    echo -e "${cor[2]}Puerto $nuevo_puerto agregado a Dropbear${cor[0]}"
    sleep 1
}

eliminar_puerto() {
    echo -e "${cor[3]}ELIMINAR PUERTO${cor[0]}"
    echo -e "${cor[2]}Puertos actuales:${cor[0]}"
    grep DROPBEAR_EXTRA_ARGS /etc/default/dropbear | awk -F"-p " '{print $2}'
    read -p "Ingrese puerto a eliminar: " port_del
    if grep -q "$port_del" /etc/default/dropbear; then
        sed -i "/$port_del/d" /etc/default/dropbear
        systemctl restart dropbear >/dev/null 2>&1
        echo -e "${cor[2]}Puerto $port_del eliminado${cor[0]}"
    else
        echo -e "${cor[4]}Puerto no encontrado${cor[0]}"
    fi
    sleep 1
}

# =================== MENU PRINCIPAL ===================
clear&&clear
while true; do
    clear
    echo -e "$barra"
    echo -e " ${cor[3]}ADMINISTRADOR DROPBEAR ${cor[2]}[ NEW-GOLDEN ADM PRO ]"
    echo -e "$barra"
    echo -e "${cor[4]} [1] > ${cor[3]}INSTALAR DROPBEAR"
    echo -e "${cor[4]} [2] > ${cor[3]}DESINSTALAR DROPBEAR"
    echo -e "${cor[4]} [3] > ${cor[3]}AGREGAR PUERTO EXTRA"
    echo -e "${cor[4]} [4] > ${cor[3]}ELIMINAR PUERTO"
    echo -e "${cor[4]} [0] > ${cor[3]}SALIR"
    echo -e "$barra"

    read -p "OPCION: " opcion
    case $opcion in
        1) instalar_dropbear ;;
        2) desinstalar_dropbear ;;
        3) agregar_puerto ;;
        4) eliminar_puerto ;;
        0) exit ;;
        *) echo -e "${cor[4]}Opción inválida${cor[0]}"; sleep 1 ;;
    esac
done