#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

fun_bar () {
    comando="$1"
    $comando >/tmp/goproxy_install.log 2>&1 &
    pid=$!

    i=0
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando GoProxy Fake..." "$s"
        sleep 0.15
    done

    wait "$pid"
    res=$?
    printf "\r\033[K"

    if [[ "$res" != "0" ]]; then
        echo "ERROR EN GOPROXY FAKE"
        tail -n 80 /tmp/goproxy_install.log
        sleep 2
        return 1
    fi

    echo "OK - COMPLETADO"
    sleep 0.5
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

mportas () {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | awk '
        NR>1 {
            n=split($4,a,":");
            port=a[n];
            proc=$0;
            name="desconocido";
            if (proc ~ /goproxyfake/) name="goproxyfake";
            else if (proc ~ /rustyproxy/) name="rustyproxy";
            else if (proc ~ /haproxy/) name="haproxyssl";
            else if (proc ~ /stunnel/) name="stunnel4";
            else if (proc ~ /sshd/) name="sshd";
            else if (proc ~ /dropbear/) name="dropbear";
            else if (proc ~ /apache2/) name="apache2";
            else if (proc ~ /badvpn/) name="badvpn-ud";
            else if (proc ~ /xray/) name="xray";
            else if (proc ~ /v2ray/) name="v2ray";
            print name" "port;
        }' | sort -u
    else
        netstat -ltnp 2>/dev/null | awk '
        NR>2 {
            n=split($4,a,":");
            port=a[n];
            print "desconocido "port;
        }' | sort -u
    fi
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

goproxy_instalado() {
    [[ -x /usr/local/bin/goproxyfake ]]
}

goproxy_servicios_activos() {
    ss -ltnp 2>/dev/null | grep -qi goproxyfake
}

mostrar_goproxy_activos() {
    linea
    echo -e "        ${cor[3]}GOPROXY FAKE - NEW GOLDEN${cor[0]}"
    linea2

    if goproxy_instalado; then
        echo -e "   ${cor[4]}[INSTALADO]${cor[0]} Binario: /usr/local/bin/goproxyfake"
    else
        echo -e "   ${cor[2]}[DESINSTALADO]${cor[0]} GoProxy Fake no esta instalado"
    fi

    if goproxy_servicios_activos; then
        ss -ltnp 2>/dev/null | grep -i goproxyfake | awk '{
            split($4,a,":");
            print "   [ONLINE] Puerto GoProxy : " a[length(a)];
        }'
    else
        echo -e "   ${cor[2]}[OFFLINE]${cor[0]} No hay puertos GoProxy Fake activos"
    fi
}

instalar_base_goproxy() {
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1
    dpkg --configure -a >/dev/null 2>&1
    apt-get update -y
    apt-get install -y golang-go curl wget lsof net-tools iproute2
}

optimizar_goproxy() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-goproxy.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden-goproxy.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    systemctl daemon-reexec >/dev/null 2>&1
    systemctl daemon-reload >/dev/null 2>&1
}

compilar_goproxyfake() {
    mkdir -p /opt/newgolden-goproxyfake
    mkdir -p /etc/goproxyfake

cat >/opt/newgolden-goproxyfake/main.go <<'EOF'
package main

import (
	"flag"
	"fmt"
	"io"
	"net"
	"time"
)

func handle(client net.Conn, target string, banner string) {
	defer client.Close()

	if tcp, ok := client.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	if banner == "" {
		banner = "OK"
	}

	// Primera respuesta fija
	_, _ = client.Write([]byte("HTTP/1.1 101 Connection Established\r\n\r\n"))

	// Leer y tirar payload inicial para que NO llegue al SSH
	client.SetReadDeadline(time.Now().Add(3 * time.Second))
	buffer := make([]byte, 1024)
	_, _ = client.Read(buffer)
	client.SetReadDeadline(time.Time{})

	// Aquí aparece el banner
	_, _ = client.Write([]byte(fmt.Sprintf("HTTP/1.1 200 %s\r\n\r\n", banner)))

	server, err := net.DialTimeout("tcp", target, 10*time.Second)
	if err != nil {
		return
	}
	defer server.Close()

	if tcp, ok := server.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	done := make(chan struct{}, 2)

	go func() {
		_, _ = io.Copy(server, client)
		done <- struct{}{}
	}()

	go func() {
		_, _ = io.Copy(client, server)
		done <- struct{}{}
	}()

	<-done
}

func main() {
	listen := flag.String("listen", "0.0.0.0:80", "listen address")
	target := flag.String("target", "127.0.0.1:22", "target address")
	banner := flag.String("banner", "OK", "banner en respuesta 200")
	flag.Parse()

	ln, err := net.Listen("tcp", *listen)
	if err != nil {
		panic(err)
	}

	fmt.Println("GoProxyFake ONLINE", *listen, "->", *target, "BANNER:", *banner)

	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go handle(conn, *target, *banner)
	}
}
EOF

    cd /opt/newgolden-goproxyfake || return 1
    go build -ldflags="-s -w" -o /usr/local/bin/goproxyfake main.go || return 1
    chmod +x /usr/local/bin/goproxyfake
}

crear_servicio_goproxy() {
    local nombre="$1"
    local puerto_entrada="$2"
    local puerto_local="$3"
    local banner="$4"

    [[ -z "$banner" ]] && banner="OK"

cat >/etc/systemd/system/goproxyfake_${puerto_entrada}.service <<EOF
[Unit]
Description=GoProxyFake NEW GOLDEN ${puerto_entrada} to ${puerto_local}
After=network.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/goproxyfake -listen 0.0.0.0:${puerto_entrada} -target 127.0.0.1:${puerto_local} -banner "${banner}"
Restart=always
RestartSec=2
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
KillSignal=SIGTERM
TimeoutStopSec=5
Nice=-5

[Install]
WantedBy=multi-user.target
EOF

    mkdir -p /etc/goproxyfake
    touch /etc/goproxyfake/newgolden.map

    grep -v "|${puerto_entrada}|" /etc/goproxyfake/newgolden.map > /tmp/goproxyfake.map 2>/dev/null
    mv /tmp/goproxyfake.map /etc/goproxyfake/newgolden.map

    echo "${nombre}|${puerto_entrada}|${puerto_local}|${banner}" >> /etc/goproxyfake/newgolden.map

    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable goproxyfake_${puerto_entrada}.service >/dev/null 2>&1
    systemctl restart goproxyfake_${puerto_entrada}.service >/tmp/goproxyfake_test.log 2>&1
}

restart_goproxy_service() {
    local puerto_check="$1"

    systemctl daemon-reload >/dev/null 2>&1
    systemctl restart goproxyfake_${puerto_check}.service >/tmp/goproxyfake_test.log 2>&1
    sleep 2

    if ss -ltnp 2>/dev/null | grep -q ":${puerto_check} "; then
        return 0
    fi

    echo "ERROR REAL DE GOPROXYFAKE:"
    cat /tmp/goproxyfake_test.log
    systemctl status goproxyfake_${puerto_check}.service --no-pager -l 2>/dev/null
    return 1
}

instalar_goproxy_core() {
    instalar_base_goproxy || return 1
    optimizar_goproxy
    compilar_goproxyfake || return 1
}

pedir_datos_puerto() {
    local titulo="$1"

    clean_screen
    echo "$titulo"
    linea
    echo "Seleccione un puerto interno abierto"
    echo "Ejemplo: 22 OpenSSH, 80 Proxy, 53 Dropbear, 1194 OpenVPN"
    linea

    while true; do
        read -p "Local-Port: " portx
        valid_port "$portx" || { echo "Puerto invalido"; continue; }

        if port_in_use "$portx"; then
            break
        else
            echo "Ese puerto interno no esta abierto"
        fi
    done

    linea
    echo "Que puerto desea abrir como GoProxy Fake"
    linea

    while true; do
        read -p "Listen-GoProxy: " GOPORT
        valid_port "$GOPORT" || { echo "Puerto invalido"; continue; }

        if port_in_use "$GOPORT"; then
            echo "Este puerto ya esta en uso"
        else
            break
        fi
    done

    linea
    echo "Banner que aparecera en HTTP/1.1 200"
    echo "Ejemplo: OK, NewGolden, Cloudflare, Connection Established"
    linea
    read -p "Banner [OK]: " BANNER
    BANNER="${BANNER:-OK}"
}

abrir_puerto_goproxy () {
pedir_datos_puerto "ABRIR PUERTO GOPROXY FAKE"

if ! goproxy_instalado; then
    linea
    echo "GoProxy Fake no esta instalado."
    echo "Primero usa la opcion [1] INSTALAR GOPROXY FAKE"
    linea
    read -p "Presiona ENTER para continuar..."
    return 1
fi

linea
echo "Abriendo puerto GoProxy Fake"
linea

crear_servicio_goproxy "goproxy_${GOPORT}" "$GOPORT" "$portx" "$BANNER"

if restart_goproxy_service "$GOPORT"; then
    linea
    echo "INSTALADO CON EXITO"
    echo "GoProxyFake: ${GOPORT} -> LOCAL: ${portx}"
    echo "Banner 200: ${BANNER}"
    linea
else
    linea
    echo "ERROR: GoProxyFake no pudo iniciar"
    echo "cat /tmp/goproxyfake_test.log"
    echo "systemctl status goproxyfake_${GOPORT}"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

agregar_puerto_goproxy () {
pedir_datos_puerto "AGREGAR MAS PUERTOS GOPROXY FAKE"

if ! goproxy_instalado; then
    linea
    echo "GoProxy Fake no esta instalado."
    echo "Primero usa la opcion [1] INSTALAR GOPROXY FAKE"
    linea
    read -p "Presiona ENTER para continuar..."
    return 1
fi

linea
echo "Agregando puerto GoProxy Fake"
linea

crear_servicio_goproxy "goproxy_${GOPORT}" "$GOPORT" "$portx" "$BANNER"

if restart_goproxy_service "$GOPORT"; then
    linea
    echo "AGREGADO CON EXITO"
    echo "GoProxyFake: ${GOPORT} -> LOCAL: ${portx}"
    echo "Banner 200: ${BANNER}"
    linea
else
    linea
    echo "ERROR: GoProxyFake no pudo iniciar"
    echo "cat /tmp/goproxyfake_test.log"
    echo "systemctl status goproxyfake_${GOPORT}"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

reiniciar_goproxy_all () {
clean_screen
echo "REINICIAR GOPROXY FAKE"
linea

reiniciar_todos_goproxy() {
    systemctl daemon-reload >/dev/null 2>&1
    for svc in /etc/systemd/system/goproxyfake_*.service; do
        [[ -e "$svc" ]] || continue
        base=$(basename "$svc")
        systemctl restart "$base" >/dev/null 2>&1
    done
}

fun_bar "reiniciar_todos_goproxy"

linea
echo "GOPROXY FAKE REINICIADO"
linea

read -p "Presiona ENTER para continuar..."
return 0
}

detener_goproxy () {
clean_screen
echo "DESINSTALAR GOPROXY FAKE"
linea
echo "Esta opcion eliminara GoProxy Fake completo"
echo "Servicios, binario, proyecto y configuraciones"
linea

read -p "¿Deseas continuar? [s/n]: " confirmgo
[[ "$confirmgo" != "s" && "$confirmgo" != "S" ]] && return 0

linea
echo "DESINSTALANDO GOPROXY FAKE COMPLETAMENTE"
linea

desinstalar_goproxy_completo() {
    for svc in /etc/systemd/system/goproxyfake_*.service; do
        [[ -e "$svc" ]] || continue
        base=$(basename "$svc")
        systemctl stop "$base" >/dev/null 2>&1
        systemctl disable "$base" >/dev/null 2>&1
    done

    pkill -9 goproxyfake >/dev/null 2>&1

    rm -f /etc/systemd/system/goproxyfake_*.service
    rm -rf /etc/goproxyfake
    rm -rf /opt/newgolden-goproxyfake
    rm -f /usr/local/bin/goproxyfake
    rm -f /tmp/goproxyfake_test.log
    rm -f /tmp/goproxy_install.log

    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
}

fun_bar "desinstalar_goproxy_completo"

linea
echo "GOPROXY FAKE ELIMINADO COMPLETAMENTE"
echo "Puedes volver a instalar GoProxy limpio sin errores"
linea

read -p "Presiona ENTER para continuar..."
return 0
}

gestor_fun () {
while true; do
clean_screen
mostrar_goproxy_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR GOPROXY FAKE${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  INSTALAR GOPROXY FAKE"
echo -e "   ${cor[2]}[2]${cor[0]}  ABRIR PUERTO GOPROXY FAKE"
echo -e "   ${cor[2]}[3]${cor[0]}  AGREGAR MAS PUERTOS GOPROXY FAKE"
echo -e "   ${cor[2]}[4]${cor[0]}  REINICIAR GOPROXY FAKE"
echo -e "   ${cor[2]}[5]${cor[0]}  ${cor[2]}DESINSTALAR GOPROXY FAKE${cor[0]}"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1)
        clean_screen
        echo "INSTALAR GOPROXY FAKE"
        linea
        fun_bar "instalar_goproxy_core"
        read -p "Presiona ENTER para continuar..."
    ;;
    2) abrir_puerto_goproxy ;;
    3) agregar_puerto_goproxy ;;
    4) reiniciar_goproxy_all ;;
    5) detener_goproxy ;;
esac
done
}

gestor_fun