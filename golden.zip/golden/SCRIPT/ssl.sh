#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

SCPdir="/etc/newadm"
SCPusr="${SCPdir}/ger-user"
SCPfrm="/etc/ger-frm"
SCPfrm3="/etc/adm-lite"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"
colores
lor1='\033[1;31m';lor2='\033[1;32m';lor3='\033[1;33m';lor4='\033[1;34m';lor5='\033[1;35m';lor6='\033[1;36m';lor7='\033[1;37m'

declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
SCPdir="/etc/newadm" && [[ ! -d ${SCPdir} ]] && exit 1
SCPfrm="/etc/ger-frm" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="/etc/ger-inst" && [[ ! -d ${SCPinst} ]] && exit
SCPidioma="${SCPdir}/idioma" && [[ ! -e ${SCPidioma} ]] && touch ${SCPidioma}

fun_bar () {
    comando="$1"
    # Ejecuta el comando en segundo plano
    $comando > /dev/null 2>&1 &
    pid=$!
    
    # Barra de progreso ligera
    while [[ -d /proc/$pid ]]; do
        echo -ne " \033[1;33m["
        for ((i=0; i<10; i++)); do
            echo -ne "\033[1;31m##"
            sleep 0.05   # sleep reducido para no bloquear la CPU
        done
        echo -ne "\033[1;33m]\r"
        sleep 0.1       # espera corta para no saturar
    done
    
    # Barra final completa
    echo -e " \033[1;33m[\033[1;31m####################\033[1;33m] - \033[1;32m100%\033[0m"
}

mportas () {
    # Lista de puertos TCP escuchando, sin duplicados
    ss -tlnp 2>/dev/null | awk 'NR>1 {
        split($4, a, ":")
        print $1, a[length(a)]
    }' | sort -u
}

ssl_stunel () {
    # Si Stunnel ya está activo → reinicia solo
    if systemctl is-active stunnel4 >/dev/null 2>&1; then
        echo -e "\033[1;36mReiniciando Stunnel (fix conexiones)\033[0m"
        systemctl restart stunnel4
        return 0
    fi

    echo -e "\033[1;36mConfigurando SSL Stunnel\033[0m"
    echo -e "\033[1;33mSeleccione un puerto interno (ej: Dropbear, OpenSSH, OpenVPN, etc.)\033[0m"

    # Puerto local
    while true; do
        read -p " Local-Port: " DPORT
        if [[ -n $DPORT ]] && [[ $(mportas | grep -w "$DPORT") ]]; then
            break
        else
            echo -e "\033[1;31mPuerto inválido o cerrado\033[0m"
        fi
    done

    # Puerto SSL a escuchar
    while true; do
        read -p " Listen-SSL: " SSLPORT
        if [[ -n $SSLPORT ]] && [[ ! $(mportas | grep -w "$SSLPORT") ]]; then
            break
        else
            echo -e "\033[1;33mEste puerto ya está en uso\033[0m"
        fi
    done

    echo -e "\033[1;33mInstalando stunnel4 si no está presente...\033[0m"
    fun_bar "apt-get install stunnel4 -y"

    # Generar certificado solo si no existe
    [[ ! -f /etc/stunnel/stunnel.pem ]] && {
        openssl genrsa -out /etc/stunnel/stunnel.key 2048
        openssl req -new -key /etc/stunnel/stunnel.key -x509 -days 1000 -out /etc/stunnel/stunnel.crt -subj "/CN=localhost"
        cat /etc/stunnel/stunnel.crt /etc/stunnel/stunnel.key > /etc/stunnel/stunnel.pem
    }

    # Configuración estable de Stunnel
    cat > /etc/stunnel/stunnel.conf <<EOF
cert = /etc/stunnel/stunnel.pem
client = no
pid = /var/run/stunnel4.pid
output = /var/log/stunnel4.log
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1
TIMEOUTbusy = 300
TIMEOUTclose = 0
TIMEOUTidle = 600
[stunnel]
connect = 127.0.0.1:${DPORT}
accept = ${SSLPORT}
EOF

    sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4
    systemctl enable stunnel4 &>/dev/null
    systemctl restart stunnel4 &>/dev/null || service stunnel4 restart &>/dev/null

    # Limpiar posibles archivos temporales
    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key

    echo -e "\033[1;32mSSL Stunnel instalado correctamente\033[0m"
}

ssl_detener () {
    echo -e "${cor[3]}Deteniendo Stunnel...${cor[0]}"
    
    # Intentar detener el servicio de manera segura
    if systemctl is-active stunnel4 >/dev/null 2>&1; then
        systemctl stop stunnel4 &>/dev/null || service stunnel4 stop &>/dev/null
        echo -e "${cor[4]}Todos los puertos SSL detenidos con éxito${cor[0]}"
    else
        echo -e "${cor[2]}Stunnel no estaba activo${cor[0]}"
    fi
}

ssl_puerto () {
    echo -e "\033[1;36mQue puerto desea agregar como SSL OpenSSH\033[0m"

    # Leer puerto SSL y validar que no esté en uso
    while true; do
        read -p " Puerto SSL: " SSLPORTr
        if [[ -z $SSLPORTr ]]; then
            echo -e "\033[1;31mPuerto inválido\033[0m"
            continue
        fi
        if [[ $(mportas | grep -w "$SSLPORTr") ]]; then
            echo -e "\033[1;33mEste puerto ya está en uso\033[0m"
        else
            break
        fi
    done

    echo -e "\033[1;33mInstalando stunnel4 si no está presente...\033[0m"
    fun_bar "apt-get install stunnel4 -y"

    # Evitar duplicar puerto
    grep -q "accept = ${SSLPORTr}" /etc/stunnel/stunnel.conf 2>/dev/null && {
        echo -e "\033[1;31mPUERTO YA CONFIGURADO!\033[0m"
        return 1
    }

    # Configuración estable
    cat >> /etc/stunnel/stunnel.conf <<EOF
[ssh-${SSLPORTr}]
client = no
accept = ${SSLPORTr}
connect = 127.0.0.1:22
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1
TIMEOUTclose = 0
EOF

    sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4
    systemctl restart stunnel4 2>/dev/null || service stunnel4 restart

    echo -e "\033[1;32mPUERTO SSL AGREGADO CON ÉXITO\033[0m"

    # Limpiar archivos temporales si existen
    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key
}

ssl_redir () {
    echo -e "\033[1;36mAsigne un nombre para el redirecionador\033[0m"
    read -p " Nombre: " namer

    echo -e "\033[1;33mPuerto local a redirigir (ej: Dropbear, OpenSSH, OpenVPN, etc.)\033[0m"
    while true; do
        read -p " Local-Port: " portd
        if [[ -n $portd ]] && [[ $(mportas | grep -w "$portd") ]]; then
            break
        else
            echo -e "\033[1;31mPuerto inválido o cerrado\033[0m"
        fi
    done

    echo -e "\033[1;33mPuerto SSL a asignar\033[0m"
    while true; do
        read -p " Puerto SSL: " SSLPORTr
        if [[ -z $SSLPORTr ]]; then
            echo -e "\033[1;31mPuerto inválido\033[0m"
            continue
        fi
        if [[ $(mportas | grep -w "$SSLPORTr") ]]; then
            echo -e "\033[1;33mEste puerto ya está en uso\033[0m"
        else
            break
        fi
    done

    echo -e "\033[1;33mInstalando stunnel4 si no está presente...\033[0m"
    fun_bar "apt-get install stunnel4 -y"

    # Evitar duplicar puerto
    grep -q "accept = ${SSLPORTr}" /etc/stunnel/stunnel.conf 2>/dev/null && {
        echo -e "\033[1;31mPUERTO YA CONFIGURADO!\033[0m"
        return 1
    }

    # Configuración estable del redireccionador
    cat >> /etc/stunnel/stunnel.conf <<EOF
[${namer}-${SSLPORTr}]
client = no
accept = ${SSLPORTr}
connect = 127.0.0.1:${portd}
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1
TIMEOUTclose = 0
EOF

    sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4
    systemctl restart stunnel4 2>/dev/null || service stunnel4 restart

    echo -e "\033[1;32mRedirección SSL agregada con éxito\033[0m"

    # Limpiar archivos temporales
    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key
}

cert_ssl () {
    # Limpiar certificados antiguos
    rm -f /etc/stunnel/private.key /etc/stunnel/certificate.crt /etc/stunnel/ca_bundle.crt /etc/stunnel/stunnel.pem

    echo -e "${lor7}INGRESA EL LINK DEL CERTIFICADO${lor0}"
    read -p " LINK >>> " linksd

    echo -e "${lor3}Descargando e instalando certificado...${lor0}"

    inscerts() {
        wget -q "$linksd" -O /etc/stunnel/certificado.zip
        cd /etc/stunnel/ || exit
        unzip -o certificado.zip
        cat private.key certificate.crt ca_bundle.crt > stunnel.pem
        systemctl restart stunnel4 &>/dev/null || service stunnel4 restart &>/dev/null
    }

    fun_bar "inscerts"

    echo -e "${lor2}CERTIFICADO INSTALADO CON EXITO${lor0}"
}

clear&&clear
gestor_fun () {
    while true; do
        clear
        echo -e "$barra"
        echo -e " ${cor[3]}ADMINISTRADOR SSL ${cor[2]}[ NEW-GOLDEN ADM PRO ]"
        echo -e "$barra"
        echo -e "${cor[2]} [1] > ${cor[3]}ABRIR PUERTO SSL"
        echo -e "${cor[2]} [2] > ${cor[0]}AGREGAR MAS PUERTOS SSL"
        echo -e "${cor[2]} [3] > ${cor[0]}READIRECCIONAR PUERTO SSL"
        echo -e "${cor[2]} [4] > ${cor[3]}DETENER PUERTOS SSL"
        echo -e "${cor[2]} [5] > ${cor[0]}AGREGAR CERTIFICADO SSL"
        echo -e "${cor[2]} [0] > ${cor[0]}SALIR\n$barra"

        # Leer opción del usuario
        read -p "Selecciona una Opcion: " opx
        tput cuu1 && tput dl1

        # Ejecutar la opción seleccionada
        case $opx in
            1) ssl_stunel ;;
            2) ssl_puerto ;;
            3) ssl_redir ;;
            4) ssl_detener ;;
            5) cert_ssl ;;
            0) echo -e "${cor[2]}Saliendo del panel...${cor[0]}"; break ;;
            *) echo -e "${cor[1]}Opción inválida, intente nuevamente${cor[0]}"; sleep 1 ;;
        esac
    done
}

# Ejecutar el panel
gestor_fun