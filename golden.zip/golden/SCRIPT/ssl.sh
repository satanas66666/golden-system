#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

SCPdir="/etc/newadm"
SCPusr="${SCPdir}/ger-user"
SCPfrm="/etc/ger-frm"
SCPfrm3="/etc/adm-lite"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"
colores
lor1='\033[1;31m';lor2='\033[1;32m';lor3='\033[1;33m';lor4='\033[1;34m';lor5='\033[1;35m';lor6='\033[1;36m';lor7='\033[1;37m'

declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
SCPdir="/etc/newadm" && [[ ! -d ${SCPdir} ]] && exit 1
SCPfrm="/etc/ger-frm" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="/etc/ger-inst" && [[ ! -d ${SCPinst} ]] && exit
SCPidioma="${SCPdir}/idioma" && [[ ! -e ${SCPidioma} ]] && touch ${SCPidioma}

fun_bar () {
comando="$1"
 _=$(
$comando > /dev/null 2>&1
) & > /dev/null
pid=$!
while [[ -d /proc/$pid ]]; do
echo -ne " \033[1;33m["
   for((i=0; i<10; i++)); do
   echo -ne "\033[1;31m##"
   sleep 0.2
   done
echo -ne "\033[1;33m]"
sleep 1s
echo
tput cuu1 && tput dl1
done
echo -e " \033[1;33m[\033[1;31m####################\033[1;33m] - \033[1;32m100%\033[0m"
sleep 1s
}
mportas () {
unset portas
portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
while read port; do
var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
[[ "$(echo -e $portas|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
done <<< "$portas_var"
i=1
echo -e "$portas"
}

ssl_puerto () {
msg -ama "$(fun_trans "Que puerto desea agregar como SSL Openssh")"
msg -bar

while true; do
read -p " Puerto SSL: " SSLPORTr
[[ $(mportas | grep -w "$SSLPORTr") ]] || break
msg -bar
echo -e "$(fun_trans "${cor[0]}Esta puerta está en uso")"
msg -bar
done

msg -bar
msg -ama " $(fun_trans "Instalando SSL")"
msg -bar

fun_bar "apt-get install stunnel4 -y"

# 🔥 EVITA DUPLICAR PUERTO
grep -q "accept = ${SSLPORTr}" /etc/stunnel/stunnel.conf 2>/dev/null && {
echo -e "\033[1;31mPUERTO YA CONFIGURADO!\033[0m"
return 1
}

# 🔥 CONFIG ESTABLE (ANTI CAIDAS)
cat >> /etc/stunnel/stunnel.conf <<EOF

[ssh-${SSLPORTr}]
client = no
accept = ${SSLPORTr}
connect = 127.0.0.1:22

socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1

TIMEOUTclose = 0
EOF

######-------
sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4

# 🔥 REINICIO MODERNO (COMPATIBLE)
systemctl restart stunnel4 2>/dev/null || service stunnel4 restart

msg -bar
msg -ama " $(fun_trans "AGREGADO CON EXITO")"
msg -bar

rm -rf /etc/ger-frm/stunnel.crt > /dev/null 2>&1
rm -rf /etc/ger-frm/stunnel.key > /dev/null 2>&1
rm -rf /root/stunnel.crt > /dev/null 2>&1
rm -rf /root/stunnel.key > /dev/null 2>&1

return 0
}

ssl_redir () {
msg -bra "$(fun_trans "Asigne un nombre para el redirecionador")"
msg -bar
read -p " nombre: " namer

msg -bar
msg -ama "$(fun_trans "A que puerto redirecionara el puerto SSL")"
msg -ama "$(fun_trans "Es decir un puerto abierto en su servidor")"
msg -ama "$(fun_trans "Ejemplo Dropbear, OpenSSH, ShadowSocks, OpenVPN, Etc")"
msg -bar

# 🔥 VALIDAR PUERTO LOCAL
while true; do
read -p " Local-Port: " portd
[[ $(mportas | grep -w "$portd") ]] && break
echo -e "\033[1;31mPuerto inválido o cerrado\033[0m"
done

msg -bar
msg -ama "$(fun_trans "Que puerto desea agregar como SSL")"
msg -bar

while true; do
read -p " Puerto SSL: " SSLPORTr
[[ $(mportas | grep -w "$SSLPORTr") ]] || break
msg -bar
echo -e "$(fun_trans "${cor[0]}Esta puerta está en uso")"
msg -bar
done

msg -bar
msg -ama " $(fun_trans "Instalando SSL")"
msg -bar

fun_bar "apt-get install stunnel4 -y"

# 🔥 EVITA DUPLICADOS
grep -q "accept = ${SSLPORTr}" /etc/stunnel/stunnel.conf 2>/dev/null && {
echo -e "\033[1;31mPUERTO YA CONFIGURADO!\033[0m"
return 1
}

# 🔥 CONFIG ESTABLE (ANTI CAIDAS)
cat >> /etc/stunnel/stunnel.conf <<EOF

[${namer}-${SSLPORTr}]
client = no
accept = ${SSLPORTr}
connect = 127.0.0.1:${portd}
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1
TIMEOUTclose = 0
EOF

######-------
sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4

# 🔥 REINICIO COMPATIBLE
systemctl restart stunnel4 2>/dev/null || service stunnel4 restart

msg -bar
msg -ama " $(fun_trans "AGREGADO CON EXITO")"
msg -bar

rm -rf /etc/ger-frm/stunnel.crt > /dev/null 2>&1
rm -rf /etc/ger-frm/stunnel.key > /dev/null 2>&1
rm -rf /root/stunnel.crt > /dev/null 2>&1
rm -rf /root/stunnel.key > /dev/null 2>&1

return 0
}

ssl_stunel () {

# 🔥 SI YA ESTA ACTIVO → SOLO REINICIA (NO BORRAR)
if systemctl is-active stunnel4 >/dev/null 2>&1; then
msg -ama " $(fun_trans "Reiniciando Stunnel (fix conexiones)")"
msg -bar
systemctl restart stunnel4
msg -bar
return 0
fi

msg -azu " $(fun_trans "SSL Stunnel")"
msg -bar
msg -ama " $(fun_trans "Selecione Un Puerto De Redirecionamento Interno")"
msg -ama " $(fun_trans "Es decir, un puerto abierto en su servidor para SSL")"
msg -ama " $(fun_trans "Ejemplo: Dropbear OpenSSH ShadowSocks OpenVPN etc")"
msg -bar

while true; do
read -p " Local-Port: " portx
if [[ ! -z $portx ]]; then
[[ $(mportas|grep -w "$portx") ]] && break || echo -e "\033[1;31m $(fun_trans "Porta Invalida")\033[0m"
fi
done

msg -bar
DPORT="$portx"

msg -ama " $(fun_trans "Que puerto desea agregar como SSL")"
msg -bar

while true; do
read -p " Listen-SSL: " SSLPORT
[[ $(mportas|grep -w "$SSLPORT") ]] || break
echo -e "\033[1;33m $(fun_trans "este Puerto Ya Esta en Uso")\033[0m"
unset SSLPORT
done

msg -bar
msg -ama " $(fun_trans "Instalando SSL")"
msg -bar

fun_bar "apt-get install stunnel4 -y"

# 🔥 CONFIGURACION ESTABLE (ANTI CAIDAS)
cat > /etc/stunnel/stunnel.conf <<EOF
cert = /etc/stunnel/stunnel.pem
client = no

pid = /var/run/stunnel4.pid
output = /var/log/stunnel4.log

socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = a:SO_REUSEADDR=1

TIMEOUTbusy = 300
TIMEOUTclose = 0
TIMEOUTidle = 600

[stunnel]
connect = 127.0.0.1:${DPORT}
accept = ${SSLPORT}
EOF

####Coreccion2.0#####
msg -bar
msg -ama " $(fun_trans "PRECIONE ENTER A TODAS LAS OPCIONES SIGUIENTES")"
msg -bar
sleep 1

# 🔥 SOLO GENERA CERT SI NO EXISTE
if [[ ! -f /etc/stunnel/stunnel.pem ]]; then
openssl genrsa -out stunnel.key 2048
openssl req -new -key stunnel.key -x509 -days 1000 -out stunnel.crt
cat stunnel.crt stunnel.key > stunnel.pem 
mv stunnel.pem /etc/stunnel/
fi

######-------
sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4

systemctl enable stunnel4 2>/dev/null
systemctl restart stunnel4 2>/dev/null || service stunnel4 restart

msg -bar
msg -ama " $(fun_trans "INSTALADO CON EXITO")"
msg -bar

rm -rf /etc/ger-frm/stunnel.crt > /dev/null 2>&1
rm -rf /etc/ger-frm/stunnel.key > /dev/null 2>&1
rm -rf /root/stunnel.crt > /dev/null 2>&1
rm -rf /root/stunnel.key > /dev/null 2>&1

return 0
}

cert_ssl () {
rm -rf /etc/stunnel/private.key;rm -rf /etc/stunnel/certificate.crt;rm -rf /etc/stunnel/ca_bundle.crt;rm -rf /etc/stunnel/stunnel.pem
echo -e;echo -e "${lor7}INGRESA EL LINK DEL CERTIFICADO ${lor6}"
echo -e;echo -e "${lor6}LINK ${lor1}>>> ${lor7}\c"
read linksd
msg -bar
inscerts(){
wget $linksd -O /etc/stunnel/certificado.zip
cd /etc/stunnel/
unzip certificado.zip 
cat private.key certificate.crt ca_bundle.crt > stunnel.pem
service stunnel restart
service stunnel4 restart
}
fun_bar 'inscerts'
msg -bar
echo -e "${lor2}CERTIFICADO INSTALADO CON EXITO ${lor7}" 
msg -bar
return 0
}
clear&&clear
gestor_fun () {
echo -e "$barra"
echo -e " ${cor[3]} $(fun_trans "ADMINISTRADOR SSL") ${cor[2]}[ NEW-GOLDEN ADM PRO ]"
echo -e "$barra"
while true; do
echo -e "${cor[2]} [1] > ${cor[3]}$(fun_trans "ABRIR PUERTO SSL")"
echo -e "${cor[2]} [2] > ${cor[0]}$(fun_trans "AGREGAR MAS PUERTOS SSL")"
echo -e "${cor[2]} [3] > ${cor[0]}$(fun_trans "READIRECCIONAR PUERTO SSL")"
echo -e "${cor[2]} [4] > ${cor[3]}$(fun_trans "DETENER PUERTOS SSL")"
echo -e "${cor[2]} [5] > ${cor[0]}$(fun_trans "AGREGAR CERTIFICADO SSL")"
echo -e "${cor[2]} [0] > ${cor[0]}$(fun_trans "VOLVER")\n${barra}"
while [[ ${opx} != @(0|[1-5]) ]]; do
echo -ne "${cor[0]}$(fun_trans "Selecciona una Opcion"): \033[1;37m" && read opx
tput cuu1 && tput dl1
done
case $opx in
	0)
	return;;
        1)
	ssl_stunel
	break;;
	    2)
	ssl_puerto
	break;;
        3)
	ssl_redir
	break;;
	    4)
	ssl_stunel
	break;;
      5)
	cert_ssl
	break;;
esac
done
}
gestor_fun
