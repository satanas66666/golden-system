#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPusr="${SCPdir}/ger-user"
SCPfrm="/etc/ger-frm"
SCPfrm3="/etc/adm-lite"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

lor1='\033[1;31m'
lor2='\033[1;32m'
lor3='\033[1;33m'
lor4='\033[1;34m'
lor5='\033[1;35m'
lor6='\033[1;36m'
lor7='\033[1;37m'

declare -A cor=(
    [0]="\033[1;37m"
    [1]="\033[1;34m"
    [2]="\033[1;31m"
    [3]="\033[1;33m"
    [4]="\033[1;32m"
)

barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"

# Compatibilidad si no existen funciones del panel principal
type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
type msg >/dev/null 2>&1 || msg(){
    case "$1" in
        -bar) echo -e "$barra" ;;
        -ama) shift; echo -e "${cor[3]}$*" ;;
        -azu) shift; echo -e "${cor[1]}$*" ;;
        -bra) shift; echo -e "${cor[0]}$*" ;;
        *) echo -e "$*" ;;
    esac
}

colores

is_root() {
    [[ "$(id -u)" -eq 0 ]] || {
        echo -e "${lor1}Ejecuta como root.${lor7}"
        exit 1
    }
}

install_base() {
    apt-get update -y >/dev/null 2>&1
    apt-get install -y stunnel4 openssl lsof curl wget unzip net-tools ca-certificates >/dev/null 2>&1
}

restart_stunnel() {
    systemctl daemon-reload >/dev/null 2>&1

    if command -v systemctl >/dev/null 2>&1; then
        systemctl enable stunnel4 >/dev/null 2>&1
        systemctl restart stunnel4 >/dev/null 2>&1
    else
        service stunnel4 restart >/dev/null 2>&1
    fi
}

optimize_system_limits() {
    cat >/etc/sysctl.d/99-vpn-ssl-tuning.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_keepalive_time = 300
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fastopen = 3
EOF

    sysctl --system >/dev/null 2>&1

    cat >/etc/security/limits.d/99-vpn-ssl.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

    mkdir -p /etc/systemd/system/stunnel4.service.d

    cat >/etc/systemd/system/stunnel4.service.d/override.conf <<'EOF'
[Service]
LimitNOFILE=1048576
Restart=always
RestartSec=2
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

ensure_cert() {
    mkdir -p /etc/stunnel

    if [[ ! -f /etc/stunnel/stunnel.pem ]]; then
        openssl req -new -x509 -days 3650 -nodes \
            -out /etc/stunnel/stunnel.pem \
            -keyout /etc/stunnel/stunnel.pem \
            -subj "/C=MX/ST=VPN/L=Server/O=NewGoldenADM/OU=SSL/CN=localhost" >/dev/null 2>&1

        chmod 600 /etc/stunnel/stunnel.pem
    fi
}

enable_stunnel_default() {
    if [[ -f /etc/default/stunnel4 ]]; then
        sed -i 's/^ENABLED=.*/ENABLED=1/g' /etc/default/stunnel4
        grep -q '^ENABLED=1' /etc/default/stunnel4 || echo "ENABLED=1" >> /etc/default/stunnel4
    else
        echo "ENABLED=1" >/etc/default/stunnel4
    fi
}

fun_bar() {
    comando="$1"
    bash -c "$comando" >/dev/null 2>&1 &
    pid=$!

    while kill -0 "$pid" >/dev/null 2>&1; do
        echo -ne " \033[1;33m["
        for((i=0; i<10; i++)); do
            echo -ne "\033[1;31m##"
            sleep 0.1
        done
        echo -ne "\033[1;33m]"
        sleep 0.5
        echo
        tput cuu1 >/dev/null 2>&1
        tput dl1 >/dev/null 2>&1
    done

    wait "$pid"
    echo -e " \033[1;33m[\033[1;31m####################\033[1;33m] - \033[1;32m100%\033[0m"
    sleep 0.5
}

mportas() {
    if command -v lsof >/dev/null 2>&1; then
        lsof -iTCP -sTCP:LISTEN -P -n 2>/dev/null | awk 'NR>1 {
            split($9,a,":");
            print $1" "a[length(a)]
        }' | sort -u
    else
        netstat -tulpn 2>/dev/null | grep LISTEN | awk '{print $7" "$4}' | awk -F: '{print $1" "$NF}' | sort -u
    fi
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

write_stunnel_base() {
    cat >/etc/stunnel/stunnel.conf <<EOF
pid = /var/run/stunnel4.pid
foreground = no
client = no
cert = /etc/stunnel/stunnel.pem
delay = yes
socket = a:SO_REUSEADDR=1
socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
TIMEOUTclose = 0
TIMEOUTidle = 86400
EOF
}

add_stunnel_service() {
    local name="$1"
    local accept_port="$2"
    local connect_port="$3"

    cat >>/etc/stunnel/stunnel.conf <<EOF

[$name]
accept = 0.0.0.0:${accept_port}
connect = 127.0.0.1:${connect_port}
EOF
}

ssl_puerto() {
    msg -ama "$(fun_trans "Que puerto desea agregar como SSL Openssh")"
    msg -bar

    while true; do
        read -rp " Puerto SSL: " SSLPORTr

        valid_port "$SSLPORTr" || {
            echo -e "${lor1}Puerto inválido.${lor7}"
            continue
        }

        port_in_use "$SSLPORTr" && {
            msg -bar
            echo -e "$(fun_trans "${cor[0]}Esta puerta está en uso")"
            msg -bar
            continue
        }

        break
    done

    msg -bar
    msg -ama " $(fun_trans "Instalando SSL")"
    msg -bar

    fun_bar "install_base"
    optimize_system_limits
    ensure_cert
    enable_stunnel_default

    [[ ! -f /etc/stunnel/stunnel.conf ]] && write_stunnel_base

    if ! grep -q "accept = 0.0.0.0:${SSLPORTr}" /etc/stunnel/stunnel.conf; then
        add_stunnel_service "ssh_${SSLPORTr}" "$SSLPORTr" "22"
    fi

    restart_stunnel

    msg -bar
    msg -ama " $(fun_trans "AGREGADO CON EXITO")"
    msg -bar

    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key
    return 0
}

ssl_redir() {
    msg -bra "$(fun_trans "Asigne un nombre para el redirecionador")"
    msg -bar
    read -rp " nombre: " namer

    namer=$(echo "$namer" | tr -cd 'a-zA-Z0-9_-')
    [[ -z "$namer" ]] && namer="redir_ssl"

    msg -bar
    msg -ama "$(fun_trans "A que puerto redirecionara el puerto SSL")"
    msg -ama "$(fun_trans "Es decir un puerto abierto en su servidor")"
    msg -ama "$(fun_trans "Ejemplo Dropbear, OpenSSH, ShadowSocks, OpenVPN, Etc")"
    msg -bar

    while true; do
        read -rp " Local-Port: " portd

        valid_port "$portd" || {
            echo -e "${lor1}Puerto local inválido.${lor7}"
            continue
        }

        break
    done

    msg -bar
    msg -ama "$(fun_trans "Que puerto desea agregar como SSL")"
    msg -bar

    while true; do
        read -rp " Puerto SSL: " SSLPORTr

        valid_port "$SSLPORTr" || {
            echo -e "${lor1}Puerto SSL inválido.${lor7}"
            continue
        }

        port_in_use "$SSLPORTr" && {
            msg -bar
            echo -e "$(fun_trans "${cor[0]}Esta puerta está en uso")"
            msg -bar
            continue
        }

        break
    done

    msg -bar
    msg -ama " $(fun_trans "Instalando SSL")"
    msg -bar

    fun_bar "install_base"
    optimize_system_limits
    ensure_cert
    enable_stunnel_default

    [[ ! -f /etc/stunnel/stunnel.conf ]] && write_stunnel_base

    if ! grep -q "accept = 0.0.0.0:${SSLPORTr}" /etc/stunnel/stunnel.conf; then
        add_stunnel_service "$namer" "$SSLPORTr" "$portd"
    fi

    restart_stunnel

    msg -bar
    msg -ama " $(fun_trans "AGREGADO CON EXITO")"
    msg -bar

    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key
    return 0
}

ssl_stunel() {
    if systemctl is-active --quiet stunnel4 2>/dev/null || [[ $(mportas | grep stunnel4 | head -1) ]]; then
        msg -ama " $(fun_trans "Parando Stunnel")"
        msg -bar

        if command -v systemctl >/dev/null 2>&1; then
            systemctl stop stunnel4 >/dev/null 2>&1
            systemctl disable stunnel4 >/dev/null 2>&1
        else
            service stunnel4 stop >/dev/null 2>&1
        fi

        msg -bar
        msg -ama " $(fun_trans "Parado Con Exito!")"
        msg -bar
        return 0
    fi

    msg -azu " $(fun_trans "SSL Stunnel")"
    msg -bar
    msg -ama " $(fun_trans "Selecione Un Puerto De Redirecionamento Interno")"
    msg -ama " $(fun_trans "Es decir, un puerto abierto en su servidor para SSL")"
    msg -ama " $(fun_trans "Ejemplo: Dropbear OpenSSH ShadowSocks OpenVPN etc")"
    msg -bar

    while true; do
        read -rp " Local-Port: " portx

        valid_port "$portx" || {
            echo -e "\033[1;31m $(fun_trans "Puerto Invalido")\033[0m"
            continue
        }

        break
    done

    msg -bar
    msg -ama " $(fun_trans "Que puerto desea agregar como SSL")"
    msg -bar

    while true; do
        read -rp " Listen-SSL: " SSLPORT

        valid_port "$SSLPORT" || {
            echo -e "${lor1}Puerto inválido.${lor7}"
            continue
        }

        port_in_use "$SSLPORT" && {
            echo -e "\033[1;33m $(fun_trans "este Puerto Ya Esta en Uso")\033[0m"
            continue
        }

        break
    done

    msg -bar
    msg -ama " $(fun_trans "Instalando SSL")"
    msg -bar

    fun_bar "install_base"
    optimize_system_limits
    ensure_cert
    enable_stunnel_default

    write_stunnel_base
    add_stunnel_service "stunnel" "$SSLPORT" "$portx"

    restart_stunnel

    msg -bar
    msg -ama " $(fun_trans "INSTALADO CON EXITO")"
    msg -bar

    rm -f /etc/ger-frm/stunnel.crt /etc/ger-frm/stunnel.key /root/stunnel.crt /root/stunnel.key
    return 0
}

cert_ssl() {
    rm -f /etc/stunnel/private.key /etc/stunnel/certificate.crt /etc/stunnel/ca_bundle.crt /etc/stunnel/stunnel.pem

    echo -e
    echo -e "${lor7}INGRESA EL LINK DEL CERTIFICADO ${lor6}"
    echo -e
    echo -ne "${lor6}LINK ${lor1}>>> ${lor7}"
    read -r linksd

    msg -bar

    inscerts() {
        mkdir -p /etc/stunnel
        wget -q "$linksd" -O /etc/stunnel/certificado.zip || return 1
        cd /etc/stunnel/ || return 1
        unzip -o certificado.zip >/dev/null 2>&1

        if [[ -f private.key && -f certificate.crt && -f ca_bundle.crt ]]; then
            cat private.key certificate.crt ca_bundle.crt > stunnel.pem
            chmod 600 stunnel.pem
        elif [[ -f private.key && -f certificate.crt ]]; then
            cat private.key certificate.crt > stunnel.pem
            chmod 600 stunnel.pem
        else
            return 1
        fi

        restart_stunnel
    }

    fun_bar "inscerts"

    msg -bar

    if [[ -f /etc/stunnel/stunnel.pem ]]; then
        echo -e "${lor2}CERTIFICADO INSTALADO CON EXITO ${lor7}"
    else
        echo -e "${lor1}ERROR: No se pudo instalar el certificado.${lor7}"
    fi

    msg -bar
    return 0
}

gestor_fun() {
    clear
    echo -e "$barra"
    echo -e " ${cor[3]} $(fun_trans "ADMINISTRADOR SSL") ${cor[2]}[ NEW-GOLDEN ADM PRO ]"
    echo -e "$barra"

    while true; do
        unset opx
        echo -e "${cor[2]} [1] > ${cor[3]}$(fun_trans "ABRIR PUERTO SSL")"
        echo -e "${cor[2]} [2] > ${cor[0]}$(fun_trans "AGREGAR MAS PUERTOS SSL")"
        echo -e "${cor[2]} [3] > ${cor[0]}$(fun_trans "READIRECCIONAR PUERTO SSL")"
        echo -e "${cor[2]} [4] > ${cor[3]}$(fun_trans "DETENER PUERTOS SSL")"
        echo -e "${cor[2]} [5] > ${cor[0]}$(fun_trans "AGREGAR CERTIFICADO SSL")"
        echo -e "${cor[2]} [0] > ${cor[0]}$(fun_trans "VOLVER")\n${barra}"

        while [[ ! "$opx" =~ ^[0-5]$ ]]; do
            echo -ne "${cor[0]}$(fun_trans "Selecciona una Opcion"): \033[1;37m"
            read -r opx
            tput cuu1 >/dev/null 2>&1
            tput dl1 >/dev/null 2>&1
        done

        case "$opx" in
            0) return ;;
            1) ssl_stunel; break ;;
            2) ssl_puerto; break ;;
            3) ssl_redir; break ;;
            4) ssl_stunel; break ;;
            5) cert_ssl; break ;;
        esac
    done
}

is_root
gestor_fun