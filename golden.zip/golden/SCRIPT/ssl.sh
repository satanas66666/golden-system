#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }

clean_screen() {
    reset >/dev/null 2>&1
    clear
}

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

fun_bar () {
    comando="$1"
    $comando >/tmp/ssl_install.log 2>&1 &
    pid=$!

    i=0
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando SSL..." "$s"
        sleep 0.15
    done

    wait "$pid"
    res=$?
    printf "\r\033[K"

    if [[ "$res" != "0" ]]; then
        echo "ERROR EN LA INSTALACION SSL"
        tail -n 20 /tmp/ssl_install.log
        sleep 2
        return 1
    fi

    echo "OK - COMPLETADO"
    sleep 0.6
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

mportas () {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | awk '
        NR>1 {
            split($4,a,":");
            port=a[length(a)];
            proc=$0;
            name="desconocido";
            if (proc ~ /stunnel/) name="stunnel4";
            else if (proc ~ /sshd/) name="sshd";
            else if (proc ~ /dropbear/) name="dropbear";
            else if (proc ~ /apache2/) name="apache2";
            else if (proc ~ /badvpn/) name="badvpn-ud";
            else if (proc ~ /rusty/) name="rustyprox";
            else if (proc ~ /xray/) name="xray";
            else if (proc ~ /v2ray/) name="v2ray";
            print name" "port;
        }' | sort -u
    else
        netstat -ltnp 2>/dev/null | awk '
        NR>2 {
            split($4,a,":");
            port=a[length(a)];
            print "desconocido "port;
        }' | sort -u
    fi
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

instalar_base_ssl() {
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1
    dpkg --configure -a >/dev/null 2>&1
    apt-get update -y
    apt-get install -y stunnel4 openssl lsof net-tools curl wget unzip ca-certificates iproute2 openssh-server
}

optimizar_ssl() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-ssl.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_syn_retries = 3
net.ipv4.tcp_synack_retries = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    systemctl daemon-reexec >/dev/null 2>&1
    systemctl daemon-reload >/dev/null 2>&1
}

optimizar_sshd_ssl() {
    mkdir -p /etc/ssh/sshd_config.d

    sed -i '/^MaxStartups/d;/^MaxSessions/d;/^LoginGraceTime/d;/^ClientAliveInterval/d;/^ClientAliveCountMax/d;/^TCPKeepAlive/d;/^UseDNS/d;/^GSSAPIAuthentication/d' /etc/ssh/sshd_config 2>/dev/null

cat >/etc/ssh/sshd_config.d/99-newgolden-ssl.conf <<'EOF'
MaxStartups 1000:30:2000
MaxSessions 2000
LoginGraceTime 20
ClientAliveInterval 60
ClientAliveCountMax 3
TCPKeepAlive yes
UseDNS no
GSSAPIAuthentication no
EOF

    if command -v sshd >/dev/null 2>&1; then
        sshd -t >/tmp/sshd_test.log 2>&1 || {
            echo "ERROR EN CONFIG SSHD"
            cat /tmp/sshd_test.log
            return 1
        }
    fi

    systemctl restart ssh 2>/dev/null
    systemctl restart sshd 2>/dev/null
    service ssh restart 2>/dev/null
    service sshd restart 2>/dev/null

    return 0
}

generar_cert_ssl() {
    mkdir -p /etc/stunnel
    rm -f /root/stunnel.key /root/stunnel.crt /etc/stunnel/stunnel.pem

    echo -ne "Ingrese dominio SSL/SNI [localhost]: "
    read -r dominio
    dominio=$(echo "${dominio:-localhost}" | tr -d ' ')

    openssl genrsa -out /root/stunnel.key 2048 >/dev/null 2>&1 || {
        echo "ERROR: No se pudo generar la clave SSL"
        return 1
    }

    openssl req -new -key /root/stunnel.key -x509 -days 1000 \
        -out /root/stunnel.crt \
        -subj "/CN=${dominio}" \
        -addext "subjectAltName=DNS:${dominio}" >/dev/null 2>&1 || {
        echo "ERROR: No se pudo generar el certificado SSL"
        rm -f /root/stunnel.key /root/stunnel.crt
        return 1
    }

    cat /root/stunnel.crt /root/stunnel.key > /etc/stunnel/stunnel.pem
    chmod 600 /etc/stunnel/stunnel.pem
    chown root:root /etc/stunnel/stunnel.pem 2>/dev/null
    rm -f /root/stunnel.key /root/stunnel.crt

    [[ -s /etc/stunnel/stunnel.pem ]] || {
        echo "ERROR: No se pudo crear /etc/stunnel/stunnel.pem"
        return 1
    }

    echo "Certificado SSL generado correctamente"
    echo "Dominio/SNI: $dominio"
}

asegurar_certificado() {
    [[ ! -s /etc/stunnel/stunnel.pem ]] && generar_cert_ssl
}

activar_stunnel_boot() {
    mkdir -p /etc/default
    mkdir -p /etc/stunnel
    mkdir -p /etc/systemd/system/stunnel4.service.d

cat >/etc/default/stunnel4 <<'EOF'
ENABLED=1
FILES="/etc/stunnel/*.conf"
OPTIONS=""
PPP_RESTART=0
EOF

cat >/etc/systemd/system/stunnel4.service.d/override.conf <<'EOF'
[Service]
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Restart=always
RestartSec=2
TimeoutStartSec=30
TimeoutStopSec=10
EOF

    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable stunnel4 >/dev/null 2>&1
    systemctl enable stunnel.target >/dev/null 2>&1
}

write_base_conf() {
cat >/etc/stunnel/stunnel.conf <<'EOF'
foreground = no
pid = /var/run/stunnel4.pid
client = no
cert = /etc/stunnel/stunnel.pem

socket = l:TCP_NODELAY=1
socket = r:TCP_NODELAY=1
socket = l:SO_REUSEADDR=1
socket = r:SO_REUSEADDR=1

TIMEOUTidle = 7200
TIMEOUTclose = 0
TIMEOUTconnect = 10

options = NO_SSLv2
options = NO_SSLv3
compression = no
renegotiation = no
EOF

    if [[ -f /etc/stunnel/newgolden.map ]]; then
        while IFS='|' read -r nombre ssl local; do
            [[ -z "$nombre" || -z "$ssl" || -z "$local" ]] && continue
cat >>/etc/stunnel/stunnel.conf <<EOF

[$nombre]
accept = 0.0.0.0:$ssl
connect = 127.0.0.1:$local
EOF
        done < /etc/stunnel/newgolden.map
    fi
}

agregar_servicio_ssl() {
    local nombre="$1"
    local puerto_ssl="$2"
    local puerto_local="$3"

    mkdir -p /etc/stunnel
    touch /etc/stunnel/newgolden.map

    grep -v "|${puerto_ssl}|" /etc/stunnel/newgolden.map > /tmp/newgolden.map 2>/dev/null
    mv /tmp/newgolden.map /etc/stunnel/newgolden.map

    echo "${nombre}|${puerto_ssl}|${puerto_local}" >> /etc/stunnel/newgolden.map

    write_base_conf
}

restart_stunnel_compatible() {
    activar_stunnel_boot
    chmod 600 /etc/stunnel/stunnel.pem 2>/dev/null

    pkill -f "stunnel4 /etc/stunnel/stunnel.conf" >/dev/null 2>&1
    pkill -f "/usr/bin/stunnel4" >/dev/null 2>&1
    pkill -f "stunnel" >/dev/null 2>&1

    sleep 1

    stunnel4 /etc/stunnel/stunnel.conf >/tmp/stunnel_test.log 2>&1 &
    sleep 2

    if ss -ltnp 2>/dev/null | grep -qi stunnel; then
        return 0
    fi

    service stunnel4 restart >/dev/null 2>&1
    /etc/init.d/stunnel4 restart >/dev/null 2>&1
    systemctl restart stunnel4 >/dev/null 2>&1
    systemctl restart stunnel.target >/dev/null 2>&1

    sleep 2

    ss -ltnp 2>/dev/null | grep -qi stunnel
}

mostrar_ssl_activos() {
    linea
    echo -e "        ${cor[3]}SSL ACTIVOS - NEW GOLDEN${cor[0]}"
    linea2

    if ss -ltnp 2>/dev/null | grep -qi stunnel; then
        ss -ltnp 2>/dev/null | grep -i stunnel | awk '{
            split($4,a,":");
            print "   [ONLINE] Puerto SSL : " a[length(a)];
        }'
    else
        echo -e "   ${cor[2]}[OFFLINE] No hay puertos SSL activos.${cor[0]}"
    fi
}

ssl_stunel () {
clean_screen
echo "SSL STUNNEL"
linea
echo "Seleccione un puerto interno abierto"
echo "Ejemplo: 22 OpenSSH, 80 Proxy, 53 Dropbear"
linea

while true; do
    read -p "Local-Port: " portx
    valid_port "$portx" || { echo "Puerto invalido"; continue; }

    if port_in_use "$portx"; then
        break
    else
        echo "Ese puerto interno no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Listen-SSL: " SSLPORT
    valid_port "$SSLPORT" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORT"; then
        echo "Este puerto ya esta en uso"
    else
        break
    fi
done

linea
echo "Instalando SSL"
linea

fun_bar "instalar_base_ssl" || return 1
optimizar_ssl
optimizar_sshd_ssl || return 1
asegurar_certificado || return 1

agregar_servicio_ssl "stunnel_${SSLPORT}" "$SSLPORT" "$portx"

if restart_stunnel_compatible; then
    linea
    echo "INSTALADO CON EXITO"
    echo "SSL: ${SSLPORT} -> LOCAL: ${portx}"
    linea
else
    linea
    echo "ERROR: stunnel no pudo iniciar"
    echo "Revisa:"
    echo "cat /etc/stunnel/stunnel.conf"
    echo "cat /tmp/stunnel_test.log"
    linea
fi

sleep 1
return 0
}

ssl_puerto () {
clean_screen
echo "AGREGAR PUERTO SSL OPENSSH"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando SSL"
linea

fun_bar "instalar_base_ssl" || return 1
optimizar_ssl
optimizar_sshd_ssl || return 1
asegurar_certificado || return 1

agregar_servicio_ssl "ssh_${SSLPORTr}" "$SSLPORTr" "22"

if restart_stunnel_compatible; then
    linea
    echo "AGREGADO CON EXITO"
    echo "SSL: ${SSLPORTr} -> LOCAL: 22"
    linea
else
    linea
    echo "ERROR: stunnel no pudo iniciar"
    echo "cat /etc/stunnel/stunnel.conf"
    echo "cat /tmp/stunnel_test.log"
    linea
fi

sleep 1
return 0
}

ssl_redir () {
clean_screen
echo "REDIRECCIONAR PUERTO SSL"
linea

read -p "Nombre: " namer
namer=$(echo "$namer" | tr -cd 'a-zA-Z0-9_-')
[[ -z "$namer" ]] && namer="redir_ssl"

linea
echo "A que puerto redireccionara el puerto SSL"
linea

while true; do
    read -p "Local-Port: " portd
    valid_port "$portd" || { echo "Puerto local invalido"; continue; }

    if port_in_use "$portd"; then
        break
    else
        echo "Ese puerto local no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto SSL invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando SSL"
linea

fun_bar "instalar_base_ssl" || return 1
optimizar_ssl
optimizar_sshd_ssl || return 1
asegurar_certificado || return 1

agregar_servicio_ssl "$namer" "$SSLPORTr" "$portd"

if restart_stunnel_compatible; then
    linea
    echo "REDIRECCION SSL AGREGADA CON EXITO"
    echo "SSL: ${SSLPORTr} -> LOCAL: ${portd}"
    linea
else
    linea
    echo "ERROR: stunnel no pudo iniciar"
    echo "cat /etc/stunnel/stunnel.conf"
    echo "cat /tmp/stunnel_test.log"
    linea
fi

sleep 1
return 0
}

detener_stunnel () {
clean_screen
echo "PARANDO STUNNEL"
linea

service stunnel4 stop >/dev/null 2>&1
/etc/init.d/stunnel4 stop >/dev/null 2>&1
systemctl stop stunnel.target >/dev/null 2>&1
systemctl stop stunnel4 >/dev/null 2>&1
pkill -f stunnel >/dev/null 2>&1

sleep 1

linea
echo "PUERTOS SSL DETENIDOS CON EXITO"
linea

sleep 1
return 0
}

cert_ssl () {
clean_screen
echo "AGREGAR CERTIFICADO SSL"
linea
echo "INGRESA EL LINK DEL CERTIFICADO ZIP"
read -p "LINK: " linksd
linea

instalar_certificado_zip() {
    mkdir -p /etc/stunnel
    rm -f /etc/stunnel/certificado.zip
    rm -f /etc/stunnel/private.key /etc/stunnel/certificate.crt /etc/stunnel/ca_bundle.crt

    wget -q "$linksd" -O /etc/stunnel/certificado.zip || return 1
    cd /etc/stunnel || return 1
    unzip -o certificado.zip >/dev/null 2>&1 || return 1

    if [[ -f private.key && -f certificate.crt && -f ca_bundle.crt ]]; then
        cat certificate.crt ca_bundle.crt private.key > stunnel.pem
    elif [[ -f private.key && -f certificate.crt ]]; then
        cat certificate.crt private.key > stunnel.pem
    else
        return 1
    fi

    chmod 600 /etc/stunnel/stunnel.pem
    chown root:root /etc/stunnel/stunnel.pem 2>/dev/null
}

fun_bar "instalar_certificado_zip" || {
    echo "No se pudo instalar el certificado. Verifica el ZIP."
    sleep 2
    return 1
}

if restart_stunnel_compatible; then
    linea
    echo "CERTIFICADO INSTALADO CON EXITO"
    linea
else
    linea
    echo "CERTIFICADO INSTALADO, PERO STUNNEL NO REINICIO"
    linea
fi

sleep 1
return 0
}

gestor_fun () {
while true; do
clean_screen
mostrar_ssl_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR SSL${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}ABRIR PUERTO SSL${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS SSL"
echo -e "   ${cor[2]}[3]${cor[0]}  REDIRECCIONAR PUERTO SSL"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DETENER PUERTOS SSL${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  AGREGAR CERTIFICADO SSL"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) ssl_stunel ;;
    2) ssl_puerto ;;
    3) ssl_redir ;;
    4) detener_stunnel ;;
    5) cert_ssl ;;
esac

sleep 1
done
}

gestor_fun