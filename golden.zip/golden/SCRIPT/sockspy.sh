#!/bin/bash
export PATH=/root/.cargo/bin:$HOME/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C
stty -ixon 2>/dev/null || true

RUSTY_DIR="/opt/rustyproxy"
BIN_FILE="${RUSTY_DIR}/target/release/rustyproxy"
SERVICE_PREFIX="wscloud"
mkdir -p "$RUSTY_DIR/src" >/dev/null 2>&1

cor0='\033[1;37m'; cor1='\033[1;34m'; cor2='\033[1;31m'; cor3='\033[1;33m'; cor4='\033[1;32m'; cor5='\033[1;36m'
barra="${cor3}════════════════════════════════════════════${cor0}"

msg_bar(){ echo -e "$barra"; }
pause_menu(){ echo; read -r -p "Enter para continuar..."; }
valid_port(){ [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]; }

cargo_status(){ command -v cargo >/dev/null 2>&1 && echo -e "${cor4}INSTALADO${cor0}" || echo -e "${cor2}NO INSTALADO${cor0}"; }
rust_status(){ [[ -x "$BIN_FILE" ]] && echo -e "${cor4}INSTALADO${cor0}" || echo -e "${cor2}NO INSTALADO${cor0}"; }
service_count(){ find /etc/systemd/system -maxdepth 1 -type f -name "${SERVICE_PREFIX}-*.service" 2>/dev/null | wc -l; }

is_port_listening(){
    local PORT="$1"
    ss -H -ltn "sport = :$PORT" 2>/dev/null | grep -q .
}

open_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1
    mkdir -p /etc/iptables
    iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    if command -v ufw >/dev/null 2>&1; then ufw allow "$PORT"/tcp >/dev/null 2>&1 || true; fi
}

close_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1
    while iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null; do
        iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null || break
    done
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    if command -v ufw >/dev/null 2>&1; then ufw delete allow "$PORT"/tcp >/dev/null 2>&1 || true; fi
}

fix_limits(){
    mkdir -p /etc/systemd/system.conf.d /etc/systemd/user.conf.d /etc/security/limits.d /etc/sysctl.d /etc/iptables

cat >/etc/security/limits.d/99-rustyproxy.conf <<'LIMITS'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
LIMITS

cat >/etc/systemd/system.conf.d/99-rustyproxy.conf <<'SYSTEMD'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
SYSTEMD

cat >/etc/systemd/user.conf.d/99-rustyproxy.conf <<'SYSTEMDUSER'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
SYSTEMDUSER

cat >/etc/sysctl.d/99-rustyproxy.conf <<'SYSCTL'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 250000
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
SYSCTL

    sysctl --system >/dev/null 2>&1 || true
    systemctl daemon-reexec >/dev/null 2>&1 || true
    systemctl daemon-reload >/dev/null 2>&1 || true
    ulimit -n 1048576 >/dev/null 2>&1 || true
}

show_header(){
    clear
    msg_bar
    echo -e "${cor5}        WEBSOCKET RUST PANEL PRO${cor0}"
    echo -e "${cor3}        NEW GOLDEN DASHBOARD${cor0}"
    msg_bar
    echo -e " Rust/Cargo       : $(cargo_status)"
    echo -e " RustyProxy       : $(rust_status)"
    echo -e " Servicios creados: ${cor3}$(service_count)${cor0}"
    msg_bar
}

check_rust(){
    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
    if ! command -v cargo >/dev/null 2>&1; then
        echo -e "${cor3}Instalando Rust/Cargo...${cor0}"
        apt-get update -y
        apt-get install -y curl build-essential pkg-config libssl-dev iptables iptables-persistent netfilter-persistent
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
        [[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
        [[ -f "/root/.cargo/env" ]] && source "/root/.cargo/env"
    fi
    command -v cargo >/dev/null 2>&1
}

create_rust_proxy(){
    check_rust || { echo -e "${cor2}ERROR: No se pudo instalar Rust/Cargo.${cor0}"; return 1; }
    fix_limits
    mkdir -p "${RUSTY_DIR}/src"

cat > "${RUSTY_DIR}/Cargo.toml" <<'CARGO'
[package]
name = "rustyproxy"
version = "0.1.0"
edition = "2021"

[profile.release]
opt-level = 3
lto = "thin"
codegen-units = 1
panic = "abort"
strip = true

[dependencies]
tokio = { version = "1", features = ["rt-multi-thread", "macros", "net", "io-util", "time"] }
CARGO

cat > "${RUSTY_DIR}/src/main.rs" <<'RUST'
use std::env;
use tokio::io::{AsyncReadExt, AsyncWriteExt, copy_bidirectional};
use tokio::net::{TcpListener, TcpStream};
use tokio::time::{timeout, Duration};

#[tokio::main(flavor = "multi_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let port = get_port();
    println!("rustyproxy online: {}", port);
    let listener = TcpListener::bind(("0.0.0.0", port)).await?;

    loop {
        let (client, _) = listener.accept().await?;
        tokio::spawn(async move {
            let _ = handle_client(client).await;
        });
    }
}

async fn handle_client(mut client: TcpStream) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let status = get_status();

    // LOGICA ORIGINAL COMPATIBLE CON TU APP:
    // 1) Respuesta falsa 101
    // 2) Lee datos del cliente
    // 3) Respuesta falsa 200
    // 4) Decide SSH/OpenVPN y hace puente
    client.write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes()).await?;

    let mut first_buf = vec![0u8; 1024];
    let n = timeout(Duration::from_secs(3), client.read(&mut first_buf)).await??;

    client.write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes()).await?;

    let first_data = String::from_utf8_lossy(&first_buf[..n]);
    let target = if !first_data.is_empty() && !first_data.contains("SSH") {
        "127.0.0.1:1194"
    } else {
        "127.0.0.1:22"
    };

    let mut server = TcpStream::connect(target).await?;

    if n > 0 {
        let _ = server.write_all(&first_buf[..n]).await;
    }

    let _ = copy_bidirectional(&mut client, &mut server).await;
    Ok(())
}

fn get_port() -> u16 {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--port" && i + 1 < args.len() {
            return args[i + 1].parse().unwrap_or(8080);
        }
    }
    8080
}

fn get_status() -> String {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--status" && i + 1 < args.len() {
            return args[i + 1].clone();
        }
    }
    "@RustyManager".to_string()
}
RUST

    echo -e "${cor3}Compilando RustyProxy...${cor0}"
    cd "$RUSTY_DIR" || return 1
    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
    cargo build --release --jobs "$(nproc)" || { echo -e "${cor2}ERROR: Falló la compilación.${cor0}"; return 1; }
    chmod +x "$BIN_FILE"
    echo -e "${cor4}RustyProxy instalado correctamente.${cor0}"
}

create_systemd_service(){
    local PORT="$1" BANNER="$2" SERVICE_FILE="/etc/systemd/system/${SERVICE_PREFIX}-${PORT}.service"
    [[ -x "$BIN_FILE" ]] || { echo -e "${cor2}ERROR: RustyProxy no está instalado. Usa opción 1 primero.${cor0}"; return 1; }
    valid_port "$PORT" || { echo -e "${cor2}ERROR: Puerto inválido.${cor0}"; return 1; }

    fix_limits
    systemctl stop "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true
    systemctl disable "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true

cat > "$SERVICE_FILE" <<EOF2
[Unit]
Description=Proxy WebSocket Rust puerto $PORT
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${BIN_FILE} --port $PORT --status "$BANNER"
Restart=always
RestartSec=2
User=root
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
OOMScoreAdjust=-500
StandardOutput=null
StandardError=null

[Install]
WantedBy=multi-user.target
EOF2

    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1
    systemctl restart "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1
    open_port "$PORT"

    sleep 2
    if systemctl is-active --quiet "${SERVICE_PREFIX}-${PORT}" && is_port_listening "$PORT"; then
        echo -e "${cor4}Proxy WebSocket iniciado correctamente.${cor0}"
        echo -e "Puerto : ${cor3}$PORT${cor0}"
        echo -e "Banner : ${cor3}$BANNER${cor0}"
    else
        echo -e "${cor2}ERROR: ${SERVICE_PREFIX}-${PORT} no inicio o no escucho el puerto.${cor0}"
        echo "Ejecuta: systemctl status ${SERVICE_PREFIX}-${PORT} --no-pager"
        echo "Ejecuta: journalctl -u ${SERVICE_PREFIX}-${PORT} -n 80 --no-pager"
        echo "Ejecuta: ss -ltnp | grep ':$PORT'"
        return 1
    fi
}

stop_proxy_service(){
    local PORT="$1"
    valid_port "$PORT" || { echo -e "${cor2}Puerto inválido.${cor0}"; return 1; }
    systemctl stop "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true
    systemctl disable "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true
    echo -e "${cor4}Proxy Rust puerto $PORT detenido.${cor0}"
}

delete_proxy_service(){
    local PORT="$1"
    valid_port "$PORT" || { echo -e "${cor2}Puerto inválido.${cor0}"; return 1; }
    systemctl stop "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true
    systemctl disable "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1 || true
    rm -f "/etc/systemd/system/${SERVICE_PREFIX}-${PORT}.service"
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
    close_port "$PORT"
    echo -e "${cor4}Servicio ${SERVICE_PREFIX}-${PORT} eliminado completamente.${cor0}"
}

show_active_proxies(){
    echo -e "${cor5}PUERTOS WEBSOCKET ABIERTOS${cor0}"
    msg_bar
    local found=0 file svc PORT_NUM BANNER STATUS
    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        PORT_NUM=$(echo "$svc" | grep -oE '[0-9]+' | tail -n1)
        BANNER=$(grep -m1 'ExecStart=' "$file" | sed -n 's/.*--status "\(.*\)".*/\1/p')
        if systemctl is-active --quiet "$svc" && is_port_listening "$PORT_NUM"; then
            STATUS="${cor4}ONLINE${cor0}"
        else
            STATUS="${cor2}OFFLINE${cor0}"
        fi
        echo -e " Puerto ${cor3}$PORT_NUM${cor0} : $STATUS | Banner: ${cor5}${BANNER:-N/A}${cor0}"
        found=1
    done
    [[ "$found" == "0" ]] && echo -e "${cor2}No hay puertos WebSocket creados.${cor0}"
    msg_bar
}

restart_all_services(){
    local found=0 file svc
    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        systemctl restart "$svc" >/dev/null 2>&1
        echo -e "${cor4}Reiniciado:${cor0} $svc"
        found=1
    done
    [[ "$found" == "0" ]] && echo -e "${cor2}No hay servicios para reiniciar.${cor0}"
}

show_logs(){
    echo -ne "Puerto para ver logs: "; read -r PORT
    valid_port "$PORT" || { echo -e "${cor2}Puerto inválido.${cor0}"; return 1; }
    journalctl -u "${SERVICE_PREFIX}-${PORT}" -n 60 --no-pager
}

uninstall_all(){
    msg_bar; echo -e "${cor2}DESINSTALAR RUSTYPROXY COMPLETO${cor0}"; msg_bar
    echo -ne "Confirmar desinstalación completa [s/n]: "; read -r resp
    [[ "$resp" != "s" && "$resp" != "S" ]] && { echo -e "${cor3}Cancelado.${cor0}"; return; }

    local file svc PORT_NUM
    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        PORT_NUM=$(echo "$svc" | grep -oE '[0-9]+' | tail -n1)
        systemctl stop "$svc" >/dev/null 2>&1 || true
        systemctl disable "$svc" >/dev/null 2>&1 || true
        close_port "$PORT_NUM"
        rm -f "$file"
        echo -e "${cor4}Eliminado:${cor0} $svc"
    done

    rm -rf "$RUSTY_DIR"
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
    echo -e "${cor4}RustyProxy eliminado completamente.${cor0}"
}

while true; do
    show_header
    show_active_proxies
    echo -e "${cor3}[1]${cor0} Instalar / Recompilar RustyProxy"
    echo -e "${cor3}[2]${cor0} Iniciar puerto WebSocket"
    echo -e "${cor3}[3]${cor0} Detener puerto WebSocket"
    echo -e "${cor3}[4]${cor0} Eliminar puerto WebSocket"
    echo -e "${cor3}[5]${cor0} Reiniciar todos los servicios"
    echo -e "${cor3}[6]${cor0} Ver logs por puerto"
    echo -e "${cor3}[7]${cor0} Desinstalar RustyProxy completo"
    echo -e "${cor3}[0]${cor0} Salir"
    msg_bar
    echo -ne "${cor0}Seleccione opcion: "; read -r opcion

    case "$opcion" in
        1) create_rust_proxy; pause_menu ;;
        2)
            echo -ne "Puerto [8080]: "; read -r PORT; PORT="${PORT:-8080}"
            valid_port "$PORT" || { echo -e "${cor2}Puerto inválido.${cor0}"; pause_menu; continue; }
            echo -ne "Banner [@RustyManager]: "; read -r BANNER; BANNER="${BANNER:-@RustyManager}"
            create_systemd_service "$PORT" "$BANNER"; pause_menu ;;
        3) echo -ne "Puerto WebSocket a detener: "; read -r PORT; stop_proxy_service "$PORT"; pause_menu ;;
        4) echo -ne "Puerto WebSocket a eliminar: "; read -r PORT; delete_proxy_service "$PORT"; pause_menu ;;
        5) restart_all_services; pause_menu ;;
        6) show_logs; pause_menu ;;
        7) uninstall_all; pause_menu ;;
        0) msg_bar; echo -e "${cor4}Saliendo del panel WebSocket.${cor0}"; msg_bar; break ;;
        *) echo -e "${cor2}Opción no válida.${cor0}"; sleep 0.5 ;;
    esac
done
