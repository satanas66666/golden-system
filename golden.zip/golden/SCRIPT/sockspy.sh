#!/bin/bash
# WEBSOCKET RUST PANEL PRO - EXTREMO SIMPLE
# Optimizado para muchas conexiones, bajo consumo y reinicio automatico por puerto.

export PATH=/root/.cargo/bin:$HOME/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C

RUSTY_DIR="/opt/rustyproxy"
BIN_FILE="${RUSTY_DIR}/target/release/rustyproxy"
SERVICE_PREFIX="wscloud"

mkdir -p "$RUSTY_DIR/src" /etc/systemd/system.conf.d /etc/security/limits.d /etc/sysctl.d /etc/iptables 2>/dev/null

R='\033[1;31m'; G='\033[1;32m'; Y='\033[1;33m'; B='\033[1;34m'; C='\033[1;36m'; W='\033[1;37m'; N='\033[0m'
bar(){ echo -e "${Y}════════════════════════════════════════════${N}"; }
pause(){ echo; read -r -p "Enter para continuar..."; }
valid_port(){ [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]; }

fast_active(){ timeout 1 systemctl is-active --quiet "$1" 2>/dev/null; }
service_files(){ find /etc/systemd/system -maxdepth 1 -type f -name "${SERVICE_PREFIX}-*.service" 2>/dev/null | sort -V; }
service_count(){ service_files | wc -l 2>/dev/null; }

cargo_status(){ command -v cargo >/dev/null 2>&1 && echo -e "${G}INSTALADO${N}" || echo -e "${R}NO INSTALADO${N}"; }
rust_status(){ [[ -x "$BIN_FILE" ]] && echo -e "${G}INSTALADO${N}" || echo -e "${R}NO INSTALADO${N}"; }

show_header(){
    clear
    bar
    echo -e "${C}        WEBSOCKET RUST EXTREMO${N}"
    echo -e "${Y}        NEW GOLDEN DASHBOARD${N}"
    bar
    echo -e " Rust/Cargo       : $(cargo_status)"
    echo -e " RustyProxy       : $(rust_status)"
    echo -e " Servicios creados: ${Y}$(service_count)${N}"
    bar
}

install_deps(){
    apt-get update -y
    apt-get install -y curl build-essential pkg-config libssl-dev iptables iptables-persistent netfilter-persistent ca-certificates
}

check_rust(){
    if command -v cargo >/dev/null 2>&1; then return 0; fi
    echo -e "${Y}Instalando Rust/Cargo...${N}"
    install_deps || return 1
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y || return 1
    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
    [[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
    [[ -f "/root/.cargo/env" ]] && source "/root/.cargo/env"
    command -v cargo >/dev/null 2>&1
}

optimize_system(){
cat >/etc/security/limits.d/99-rustyproxy-extremo.conf <<EOF2
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF2

cat >/etc/systemd/system.conf.d/99-rustyproxy-extremo.conf <<EOF2
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF2

cat >/etc/sysctl.d/99-rustyproxy-extremo.conf <<EOF2
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 250000
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_fastopen = 3
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF2
    sysctl --system >/dev/null 2>&1
    systemctl daemon-reexec >/dev/null 2>&1
    systemctl daemon-reload >/dev/null 2>&1
}

build_proxy(){
    check_rust || { echo -e "${R}ERROR instalando Rust.${N}"; return 1; }
    optimize_system
    mkdir -p "$RUSTY_DIR/src"

cat >"$RUSTY_DIR/Cargo.toml" <<'EOF2'
[package]
name = "rustyproxy"
version = "0.2.0"
edition = "2021"

[profile.release]
opt-level = 3
lto = true
codegen-units = 1
panic = "abort"
strip = true

[dependencies]
tokio = { version = "1", features = ["full"] }
EOF2

cat >"$RUSTY_DIR/src/main.rs" <<'EOF2'
use std::env;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::time::{timeout, Duration};

#[tokio::main(flavor = "multi_thread")]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let port = arg_value("--port").unwrap_or_else(|| "8080".to_string()).parse::<u16>().unwrap_or(8080);
    let status = arg_value("--status").unwrap_or_else(|| "@RustyManager".to_string());
    let listener = TcpListener::bind(("0.0.0.0", port)).await?;
    println!("rustyproxy online: {}", port);

    loop {
        let (client, _) = listener.accept().await?;
        let status_clone = status.clone();
        tokio::spawn(async move {
            let _ = handle_client(client, status_clone).await;
        });
    }
}

async fn handle_client(mut client: TcpStream, status: String) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let _ = client.set_nodelay(true);

    // Respuesta rapida compatible con payloads WebSocket/HTTP Injector.
    client.write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes()).await?;

    let mut first = vec![0u8; 8192];
    let n = timeout(Duration::from_secs(2), client.read(&mut first)).await??;
    if n == 0 { return Ok(()); }

    let text = String::from_utf8_lossy(&first[..n]);
    let target = if text.contains("SSH") || text.contains("CONNECT") || text.contains("Upgrade") {
        "127.0.0.1:22"
    } else {
        "127.0.0.1:1194"
    };

    client.write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes()).await?;

    let mut server = TcpStream::connect(target).await?;
    let _ = server.set_nodelay(true);

    // Envia lo que ya se leyo para no perder datos.
    let _ = server.write_all(&first[..n]).await;

    // Menos consumo que usar Mutex por cada lectura/escritura.
    let _ = tokio::io::copy_bidirectional(&mut client, &mut server).await;
    Ok(())
}

fn arg_value(name: &str) -> Option<String> {
    let args: Vec<String> = env::args().collect();
    for i in 0..args.len() {
        if args[i] == name && i + 1 < args.len() { return Some(args[i + 1].clone()); }
    }
    None
}
EOF2

    echo -e "${Y}Compilando RustyProxy extremo...${N}"
    cd "$RUSTY_DIR" || return 1
    cargo build --release --jobs "$(nproc)" || return 1
    chmod +x "$BIN_FILE"
    echo -e "${G}RustyProxy extremo instalado.${N}"
}

open_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1
    iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$PORT" -j ACCEPT
    iptables-save >/etc/iptables/rules.v4 2>/dev/null || true
    command -v ufw >/dev/null 2>&1 && ufw allow "$PORT"/tcp >/dev/null 2>&1 || true
}

close_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1
    while iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null; do iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null; done
    iptables-save >/etc/iptables/rules.v4 2>/dev/null || true
    command -v ufw >/dev/null 2>&1 && ufw delete allow "$PORT"/tcp >/dev/null 2>&1 || true
}

create_service(){
    local PORT="$1" BANNER="$2" SVC="${SERVICE_PREFIX}-${PORT}" FILE="/etc/systemd/system/${SVC}.service"
    valid_port "$PORT" || { echo -e "${R}Puerto invalido.${N}"; return 1; }
    [[ -x "$BIN_FILE" ]] || { echo -e "${R}Primero instala/recompila RustyProxy.${N}"; return 1; }

    systemctl stop "$SVC" 2>/dev/null || true
    systemctl disable "$SVC" 2>/dev/null || true

cat >"$FILE" <<EOF2
[Unit]
Description=WebSocket Rust Extremo puerto $PORT
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=root
ExecStart=$BIN_FILE --port $PORT --status "$BANNER"
Restart=always
RestartSec=1
KillMode=process
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
OOMScoreAdjust=-500
Nice=-5
TimeoutStartSec=10
TimeoutStopSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SVC

[Install]
WantedBy=multi-user.target
EOF2

    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable "$SVC" >/dev/null 2>&1
    systemctl restart "$SVC" >/dev/null 2>&1
    open_port "$PORT"
    sleep 0.3
    if fast_active "$SVC"; then
        echo -e "${G}ONLINE:${N} $SVC  Banner: ${C}$BANNER${N}"
    else
        echo -e "${R}ERROR:${N} $SVC no inicio. Logs: journalctl -u $SVC -n 80 --no-pager"
    fi
}

stop_service(){
    local PORT="$1" SVC="${SERVICE_PREFIX}-${PORT}"
    valid_port "$PORT" || { echo -e "${R}Puerto invalido.${N}"; return 1; }
    systemctl stop "$SVC" 2>/dev/null || true
    systemctl disable "$SVC" 2>/dev/null || true
    echo -e "${G}Detenido:${N} $SVC"
}

delete_service(){
    local PORT="$1" SVC="${SERVICE_PREFIX}-${PORT}"
    valid_port "$PORT" || { echo -e "${R}Puerto invalido.${N}"; return 1; }
    systemctl stop "$SVC" 2>/dev/null || true
    systemctl disable "$SVC" 2>/dev/null || true
    rm -f "/etc/systemd/system/${SVC}.service"
    close_port "$PORT"
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
    echo -e "${G}Eliminado:${N} $SVC"
}

show_ports(){
    echo -e "${C}PUERTOS WEBSOCKET${N}"
    bar
    local found=0
    while read -r file; do
        [[ -f "$file" ]] || continue
        local svc port banner status
        svc=$(basename "$file" .service)
        port=${svc##*-}
        banner=$(grep -m1 '^ExecStart=' "$file" | sed -n 's/.*--status "\(.*\)"/\1/p')
        if fast_active "$svc"; then status="${G}ONLINE${N}"; else status="${R}OFFLINE${N}"; fi
        echo -e " Puerto ${Y}$port${N}: $status | Banner: ${C}${banner:-N/A}${N}"
        found=1
    done < <(service_files)
    [[ "$found" = 0 ]] && echo -e "${R}No hay puertos creados.${N}"
    bar
}

restart_all(){
    local found=0
    while read -r file; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        systemctl restart "$svc" >/dev/null 2>&1
        echo -e "${G}Reiniciado:${N} $svc"
        found=1
    done < <(service_files)
    [[ "$found" = 0 ]] && echo -e "${R}No hay servicios.${N}"
}

logs(){
    read -r -p "Puerto: " PORT
    valid_port "$PORT" || { echo -e "${R}Puerto invalido.${N}"; return 1; }
    journalctl -u "${SERVICE_PREFIX}-${PORT}" -n 80 --no-pager
}

uninstall_all(){
    read -r -p "Confirmar desinstalacion completa [s/n]: " r
    [[ "$r" = s || "$r" = S ]] || return 0
    while read -r file; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        port=${svc##*-}
        systemctl stop "$svc" 2>/dev/null || true
        systemctl disable "$svc" 2>/dev/null || true
        close_port "$port"
        rm -f "$file"
        echo -e "${G}Eliminado:${N} $svc"
    done < <(service_files)
    # No usar pkill -f para no matar el panel.
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
    rm -rf "$RUSTY_DIR"
    echo -e "${G}RustyProxy eliminado.${N}"
}

while true; do
    show_header
    show_ports
    echo -e "${Y}[1]${N} Instalar/Recompilar RustyProxy Extremo"
    echo -e "${Y}[2]${N} Iniciar puerto WebSocket"
    echo -e "${Y}[3]${N} Detener puerto WebSocket"
    echo -e "${Y}[4]${N} Eliminar puerto WebSocket"
    echo -e "${Y}[5]${N} Reiniciar todos"
    echo -e "${Y}[6]${N} Ver logs"
    echo -e "${Y}[7]${N} Desinstalar completo"
    echo -e "${Y}[0]${N} Salir"
    bar
    read -r -p "Seleccione opcion: " op
    case "$op" in
        1) build_proxy; pause ;;
        2) read -r -p "Puerto [8080]: " PORT; PORT=${PORT:-8080}; read -r -p "Banner [@RustyManager]: " BANNER; BANNER=${BANNER:-@RustyManager}; create_service "$PORT" "$BANNER"; pause ;;
        3) read -r -p "Puerto: " PORT; stop_service "$PORT"; pause ;;
        4) read -r -p "Puerto: " PORT; delete_service "$PORT"; pause ;;
        5) restart_all; pause ;;
        6) logs; pause ;;
        7) uninstall_all; pause ;;
        0) break ;;
        *) echo -e "${R}Opcion no valida.${N}"; sleep 0.5 ;;
    esac
done
