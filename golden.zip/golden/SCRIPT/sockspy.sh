#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
SCPinst="/etc/proxy/rust"
mkdir -p "$SCPinst/src/bin" &>/dev/null

# Colores y barra
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
msg_bar() { echo -e "$barra"; }
msg_title() { echo -e "${cor[3]}          WEB SOCKET RUST PANEL"; }

# ---------------- CREAR PROXY RUST + COMPILAR ----------------
create_ws_script() {
    # Cargo.toml
    cat << 'EOT' > ${SCPinst}/Cargo.toml
[package]
name = "pdirect"
version = "0.1.0"
edition = "2021"

[dependencies]
tokio = { version = "1.28.2", features = ["full"] }
EOT

    # Código Rust (idéntico al que funciona)
    cat << 'EOF' > ${SCPinst}/src/bin/PDirect.rs
use std::env;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Mutex;
use tokio::{time::{Duration}};
use tokio::time::timeout;

#[tokio::main]
async fn main() {
    let port = get_port();
    println!("Proxy Rust iniciado en puerto: {}", port);
    start_http(port).await.unwrap();
}

async fn start_http(port: u16) -> Result<(), Box<dyn std::error::Error>> {
    let listener = TcpListener::bind(format!("[::]:{}", port)).await?;
    loop {
        match listener.accept().await {
            Ok((client_stream, addr)) => {
                tokio::spawn(async move {
                    if let Err(e) = handle_client(client_stream).await {
                        println!("Error procesando cliente {}: {}", addr, e);
                    }
                });
            }
            Err(e) => println!("Error aceptando conexión: {}", e),
        }
    }
}

async fn handle_client(mut client_stream: TcpStream) -> Result<(), Box<dyn std::error::Error>> {
    let status = get_status();
    client_stream.write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes()).await?;
    let mut buffer = vec![0; 1024];
    let _ = client_stream.read(&mut buffer).await?;
    client_stream.write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes()).await?;

    let mut addr_proxy = "127.0.0.1:22";
    let peek_result = timeout(Duration::from_secs(1), peek_stream(&mut client_stream))
        .await.unwrap_or_else(|_| Ok(String::new()));

    if let Ok(data) = peek_result {
        if !data.is_empty() && !data.contains("SSH") {
            addr_proxy = "127.0.0.1:1194";
        }
    }

    let server_stream = TcpStream::connect(addr_proxy).await?;
    let (client_read, client_write) = client_stream.into_split();
    let (server_read, server_write) = server_stream.into_split();

    let client_read = Arc::new(Mutex::new(client_read));
    let client_write = Arc::new(Mutex::new(client_write));
    let server_read = Arc::new(Mutex::new(server_read));
    let server_write = Arc::new(Mutex::new(server_write));

    tokio::try_join!(
        transfer_data(client_read, server_write),
        transfer_data(server_read, client_write)
    )?;
    Ok(())
}

async fn transfer_data(
    read_stream: Arc<Mutex<tokio::net::tcp::OwnedReadHalf>>,
    write_stream: Arc<Mutex<tokio::net::tcp::OwnedWriteHalf>>,
) -> Result<(), Box<dyn std::error::Error>> {
    let mut buffer = [0; 8192];
    loop {
        let bytes_read = {
            let mut read_guard = read_stream.lock().await;
            read_guard.read(&mut buffer).await?
        };
        if bytes_read == 0 { break; }
        let mut write_guard = write_stream.lock().await;
        write_guard.write_all(&buffer[..bytes_read]).await?;
    }
    Ok(())
}

async fn peek_stream(stream: &TcpStream) -> Result<String, Box<dyn std::error::Error>> {
    let mut peek_buffer = vec![0; 8192];
    let bytes_peeked = stream.peek(&mut peek_buffer).await?;
    Ok(String::from_utf8_lossy(&peek_buffer[..bytes_peeked]).to_string())
}

fn get_port() -> u16 {
    let args: Vec<String> = env::args().collect();
    let mut port = 8080;
    for i in 1..args.len() {
        if args[i] == "--port" && i+1 < args.len() {
            port = args[i+1].parse().unwrap_or(8080);
        }
    }
    port
}

fn get_status() -> String {
    let args: Vec<String> = env::args().collect();
    let mut status = "@RustyManager".to_string();
    for i in 1..args.len() {
        if args[i] == "--status" && i+1 < args.len() {
            status = args[i+1].clone();
        }
    }
    status
}
EOF

    echo "[+] Proxy Rust generado en ${SCPinst}/src/bin/PDirect.rs"

    # Compilar automáticamente el binario release
    cd ${SCPinst}
    cargo build --release
    cd - &>/dev/null
    echo "[+] Proxy Rust compilado: target/release/PDirect"
}

# ---------------- SYSTEMD SERVICE ----------------
create_systemd_service() {
    PORT=$1
    BANNER="$2"
    SERVICE_FILE="/etc/systemd/system/wscloud-$PORT.service"

    systemctl stop wscloud-$PORT 2>/dev/null
    systemctl disable wscloud-$PORT 2>/dev/null

    cat << EOF | tee $SERVICE_FILE >/dev/null
[Unit]
Description=Proxy WebSocket Rust puerto $PORT
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
ExecStart=${SCPinst}/target/release/PDirect --port $PORT --status "$BANNER"
Restart=always
RestartSec=3
User=root
LimitNOFILE=65535
TimeoutStartSec=30
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=wscloud-$PORT

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable wscloud-$PORT
    systemctl start wscloud-$PORT
    echo "[+] Proxy Rust puerto $PORT iniciado con banner '$BANNER'"
}

# ---------------- PANEL INTERACTIVO ----------------
while true; do
    clear
    msg_bar
    msg_title
    msg_bar
    echo -e "${cor[3]}1) Instalar Proxy Rust WebSocket"
    echo -e "2) Iniciar Proxy Rust"
    echo -e "3) Detener Proxy Rust"
    echo -e "4) Mostrar proxies activos"
    echo -e "0) Salir"
    msg_bar
    echo -ne "${cor[0]}Seleccione opción: " && read opcion

    case $opcion in
    1)
        create_ws_script
        echo -ne "Puerto WebSocket (default 8080): " && read PORT
        [[ -z "$PORT" ]] && PORT=8080
        echo -ne "Banner: " && read BANNER
        [[ -z "$BANNER" ]] && BANNER="@RustyManager"
        create_systemd_service $PORT "$BANNER"
        ;;
    2)
        echo -ne "Puerto WebSocket a iniciar: " && read PORT
        echo -ne "Banner: " && read BANNER
        [[ -z "$PORT" ]] && PORT=8080
        [[ -z "$BANNER" ]] && BANNER="@RustyManager"
        create_systemd_service $PORT "$BANNER"
        ;;
    3)
        echo -ne "Puerto WebSocket a detener: " && read PORT
        systemctl stop wscloud-$PORT
        systemctl disable wscloud-$PORT
        echo "[+] Proxy Rust puerto $PORT detenido"
        ;;
    4)
        echo -e "\n===== PROXYS ACTIVOS ====="
        for svc in $(systemctl list-units --type=service | grep wscloud- | awk '{print $1}'); do
            PORT_NUM=$(echo $svc | grep -oP '(?<=wscloud-)[0-9]+')
            if systemctl is-active --quiet wscloud-$PORT_NUM; then
                STATUS="[ON]"
            else
                STATUS="[OFF]"
            fi
            echo "Puerto $PORT_NUM : $STATUS"
        done
        msg_bar
        ;;
    0) break;;
    *) echo "Opción no válida"; sleep 1;;
    esac
done
msg_bar