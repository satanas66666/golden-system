#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

#25/01/2021 by @Kalix1
clear
clear
#!/bin/bash
# Panel WebSocket Cloudflare PRO - con dashboard automático y barra personalizada

SCPinst="/etc/ger-inst"
mkdir -p "$SCPinst" &>/dev/null

# Colores
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Barra personalizada
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
msg_bar() { echo -e "$barra"; }
msg_title() { echo -e "${cor[3]}          WEB SOCKET CLOUDFLARE PANEL"; }

# Crear script Python del Proxy ultra estable compatible con panel
create_ws_script() {
cat << 'EOF' > ${SCPinst}/PDirect.py
#!/usr/bin/env python3
import socket, selectors, sys, types, time

LISTEN_ADDR = '0.0.0.0'
LISTEN_PORT = int(sys.argv[1])
TARGET = '127.0.0.1:22'
BUFLEN = 8192
STATUS = sys.argv[2] if len(sys.argv) > 2 else "@Proxy"

sel = selectors.DefaultSelector()

# ---------------- CONEXIÓN ----------------
class ProxyConnection:
    def __init__(self, client_sock):
        self.client = client_sock
        self.client.setblocking(False)
        self.remote = None
        self.client_buffer = b''
        self.remote_buffer = b''
        self.fake_response_sent = False
        self.setup_remote()

    def setup_remote(self):
        try:
            host, port = TARGET.split(":")
            self.remote = socket.create_connection((host, int(port)))
            self.remote.setblocking(False)
            self.remote.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.remote.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.client.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

            # Registramos ambos sockets en el selector
            sel.register(self.client, selectors.EVENT_READ | selectors.EVENT_WRITE, self)
            sel.register(self.remote, selectors.EVENT_READ | selectors.EVENT_WRITE, self)
        except Exception as e:
            print("Error conectando backend:", e)
            self.close()

    def handle_read(self, sock):
        try:
            data = sock.recv(BUFLEN)
            if not data:
                self.close()
                return

            if sock is self.client:
                # ---- RESPUESTA FALSA (panel) ----
                if not self.fake_response_sent:
                    self.client.sendall(f"HTTP/1.1 101 {STATUS}\r\n\r\n".encode())
                    try: self.client.recv(BUFLEN)
                    except: pass
                    self.client.sendall(f"HTTP/1.1 200 {STATUS}\r\n\r\n".encode())
                    self.fake_response_sent = True

                # Enviar datos al backend
                if self.remote:
                    self.remote_buffer += data
            else:
                # Enviar datos al cliente
                self.client_buffer += data
        except BlockingIOError:
            pass
        except Exception:
            self.close()

    def handle_write(self, sock):
        try:
            if sock is self.client and self.client_buffer:
                sent = self.client.send(self.client_buffer)
                self.client_buffer = self.client_buffer[sent:]
            elif sock is self.remote and self.remote_buffer:
                sent = self.remote.send(self.remote_buffer)
                self.remote_buffer = self.remote_buffer[sent:]
        except BlockingIOError:
            pass
        except Exception:
            self.close()

    def close(self):
        for s in [self.client, self.remote]:
            if s:
                try: sel.unregister(s)
                except Exception: pass
                try: s.close()
                except Exception: pass
        self.client = None
        self.remote = None

# ---------------- SERVIDOR ----------------
def start_server():
    lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    lsock.bind((LISTEN_ADDR, LISTEN_PORT))
    lsock.listen(50000)
    lsock.setblocking(False)
    sel.register(lsock, selectors.EVENT_READ, data=None)
    print(f"Proxy ultra estable iniciado en {LISTEN_ADDR}:{LISTEN_PORT}")

    while True:
        events = sel.select(timeout=1)
        for key, mask in events:
            if key.data is None:
                # Nueva conexión
                client_sock, addr = key.fileobj.accept()
                ProxyConnection(client_sock)
            else:
                conn = key.data
                sock = key.fileobj
                if mask & selectors.EVENT_READ:
                    conn.handle_read(sock)
                if mask & selectors.EVENT_WRITE:
                    conn.handle_write(sock)

if __name__ == "__main__":
    try:
        start_server()
    except KeyboardInterrupt:
        print("Cerrando proxy...")
EOF

chmod +x ${SCPinst}/PDirect.py
}

create_systemd_service() {
    PORT=$1
    BANNER="$2"
    SERVICE_FILE="/etc/systemd/system/wscloud-$PORT.service"

    systemctl stop wscloud-$PORT 2>/dev/null
    systemctl disable wscloud-$PORT 2>/dev/null

    cat << EOF | tee $SERVICE_FILE >/dev/null
[Unit]
Description=Proxy WebSocket/TCP Cloudflare puerto $PORT
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
ExecStart=/usr/bin/python3 ${SCPinst}/PDirect.py $PORT "$BANNER"
Restart=always
RestartSec=3
User=root
LimitNOFILE=65535
TimeoutStartSec=30
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=wscloud-$PORT

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable wscloud-$PORT
    systemctl start wscloud-$PORT

    # Optimización VPS silenciosa
    ulimit -n 65535
    cat >> /etc/security/limits.conf <<EOL
* soft nofile 65535
* hard nofile 65535
root soft nofile 65535
root hard nofile 65535
EOL

    sysctl -w net.core.somaxconn=65535 >/dev/null
    sysctl -w net.core.netdev_max_backlog=65535 >/dev/null
    sysctl -w net.ipv4.tcp_max_syn_backlog=65535 >/dev/null
    sysctl -w net.ipv4.ip_local_port_range="1024 65535" >/dev/null
    sysctl -w net.ipv4.tcp_tw_reuse=1 >/dev/null
    sysctl -w net.ipv4.tcp_fin_timeout=15 >/dev/null
}

stop_systemd_service() {
echo -ne "Digite puerto a detener: " && read PORT
sudo systemctl stop wscloud-$PORT
sudo systemctl disable wscloud-$PORT
echo -e "${cor[2]}Proxy WebSocket puerto $PORT detenido"
}

proxy_status() {
PORT=$1
if systemctl is-active --quiet wscloud-$PORT; then
echo -e "${cor[4]}[ON]"
else
echo -e "${cor[2]}[OFF]"
fi
}

# Mostrar todos los proxies arriba
show_active_proxies() {
echo -e "\n${cor[3]}===== PUERTOS WebSocket ACTIVOS ====="
for svc in $(systemctl list-units --type=service | grep wscloud- | awk '{print $1}'); do
PORT_NUM=$(echo $svc | grep -oP '(?<=wscloud-)[0-9]+')
echo -n "Puerto $PORT_NUM : "
proxy_status $PORT_NUM
done
msg_bar
}

# Menú principal
while true; do
clear
msg_bar
msg_title
msg_bar
show_active_proxies   # Dashboard arriba
echo -e "${cor[3]}1) Iniciar Proxy WebSocket"
echo -e "2) Detener Proxy WebSocket"
echo -e "3) Agregar nuevo puerto WebSocket"
echo -e "0) Volver al panel principal"
msg_bar
echo -ne "${cor[0]}Seleccione opción: " && read opcion

case $opcion in
1)
create_ws_script
echo -ne "Puerto WebSocket (default 8080): " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
2)
stop_systemd_service
;;
3)
create_ws_script
echo -ne "Nuevo puerto WebSocket: " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
0) break;;
*) echo -e "${cor[2]}Opción no válida"; sleep 1;;
esac
done
msg_bar