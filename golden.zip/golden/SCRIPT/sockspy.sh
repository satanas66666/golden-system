#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

#25/01/2021 by @Kalix1
clear
clear
SCPdir="/etc/newadm"
SCPusr="${SCPdir}/ger-user"
SCPfrm="/etc/ger-frm"
SCPfrm3="/etc/adm-lite"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"
SCPfrm="/etc/ger-frm" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="/etc/ger-inst" && [[ ! -d ${SCPinst} ]] && exit
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
[[ $(dpkg --get-selections|grep -w "python"|head -1) ]] || apt-get install python -y &>/dev/null
mportas () {
unset portas
portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
while read port; do
var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
[[ "$(echo -e $portas|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
done <<< "$portas_var"
i=1
echo -e "$portas"
}
meu_ip () {
MEU_IP=$(ip addr | grep 'inet' | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -o -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | head -1)
MEU_IP2=$(wget -qO- ipv4.icanhazip.com)
[[ "$MEU_IP" != "$MEU_IP2" ]] && echo "$MEU_IP2" || echo "$MEU_IP"
}
tcpbypass_fun () {
[[ -e $HOME/socks ]] && rm -rf $HOME/socks > /dev/null 2>&1
[[ -d $HOME/socks ]] && rm -rf $HOME/socks > /dev/null 2>&1
cd $HOME && mkdir socks > /dev/null 2>&1
cd socks
patch="https://www.dropbox.com/s/nultfnykf50f4pl/backsocz"
arq="backsocz"
wget $patch -o /dev/null
unzip $arq > /dev/null 2>&1
mv -f ./ssh /etc/ssh/sshd_config && service ssh restart 1> /dev/null 2>/dev/null
mv -f sckt$(python3 --version|awk '{print $2}'|cut -d'.' -f1,2) /usr/sbin/sckt
mv -f scktcheck /bin/scktcheck
chmod +x /bin/scktcheck
chmod +x  /usr/sbin/sckt
rm -rf $HOME/socks
cd $HOME
msg="$2"
[[ $msg = "" ]] && msg="@Kalix1"
portxz="$1"
[[ $portxz = "" ]] && portxz="8080"
screen -dmS sokz scktcheck "$portxz" "$msg" > /dev/null 2>&1
}
gettunel_fun () {
echo "master=NetVPS" > ${SCPinst}/pwd.pwd
while read service; do
[[ -z $service ]] && break
echo "127.0.0.1:$(echo $service|cut -d' ' -f2)=$(echo $service|cut -d' ' -f1)" >> ${SCPinst}/pwd.pwd
done <<< "$(mportas)"
screen -dmS getpy python ${SCPinst}/PGet.py -b "0.0.0.0:$1" -p "${SCPinst}/pwd.pwd"
 [[ "$(ps x | grep "PGet.py" | grep -v "grep" | awk -F "pts" '{print $1}')" ]] && {
 echo -e "$(fun_trans  "Gettunel Iniciado com Sucesso")"
 msg -bar
 echo -ne "$(fun_trans  "Sua Senha Gettunel e"):"
 echo -e "\033[1;32m NetVPS"
 msg -bar
 } || echo -e "$(fun_trans  "Gettunel nao foi iniciado")"
 msg -bar
}

wscloud_fun() {
    SCPinst="/etc/ger-inst"
    mkdir -p "$SCPinst" &>/dev/null

    # Puerto local SSH/DROPBEAR
    PUERTO_LOCAL=22

    # Puerto WebSocket (Cloudflare-friendly)
    porta_socket=80

    # Banner por defecto
    TEXTO_BANNER="Conectando..."

    # Verificar si el proxy ya está corriendo
    pid_old=$(pgrep -f "PWebSocket.py")
    if [[ ! -z $pid_old ]]; then
        echo "Se encontró un proceso anterior de WebSocket, deteniéndolo..."
        kill -9 $pid_old &>/dev/null
    fi

    # Crear script Python si no existe
    if [[ ! -f ${SCPinst}/PWebSocket.py ]]; then
        cat << EOF > ${SCPinst}/PWebSocket.py
import socket, threading, select, time

LISTEN_ADDR='0.0.0.0'
LISTEN_PORT=$porta_socket
TARGET='127.0.0.1:$PUERTO_LOCAL'
BUFLEN=4096*4
TIMEOUT=60
HTTP_RESPONSE='HTTP/1.1 200 OK\r\nContent-length: 0\r\n\r\n'
WEBSOCKET_RESPONSE='HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n'

class Server(threading.Thread):
    def __init__(self, host, port):
        threading.Thread.__init__(self)
        self.host=host
        self.port=port
        self.running=False
        self.threads=[]
    def run(self):
        self.soc=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.soc.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        self.soc.bind((self.host,self.port))
        self.soc.listen(0)
        self.running=True
        try:
            while self.running:
                client, addr=self.soc.accept()
                client.setblocking(1)
                conn=ConnectionHandler(client)
                conn.start()
                self.threads.append(conn)
        finally:
            self.running=False
            self.soc.close()

class ConnectionHandler(threading.Thread):
    def __init__(self, client):
        threading.Thread.__init__(self)
        self.client=client
        self.target=None
    def run(self):
        try:
            data=self.client.recv(BUFLEN)
            if not data: return
            host,port=TARGET.split(':')
            self.target=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            self.target.connect((host,int(port)))
            if b"Upgrade: websocket" in data:
                self.client.sendall(WEBSOCKET_RESPONSE.encode())
            else:
                self.client.sendall(HTTP_RESPONSE.encode())
                self.target.sendall(data)
            self.forward_data()
        except: pass
        finally:
            self.close()
    def forward_data(self):
        sockets=[self.client,self.target]
        count,error=0,False
        while not error:
            count+=1
            r,_,e=select.select(sockets,[],sockets,3)
            if e: error=True
            for s in r:
                try:
                    data=s.recv(BUFLEN)
                    if not data: error=True; break
                    if s is self.client: self.target.sendall(data)
                    else: self.client.sendall(data)
                    count=0
                except: error=True
            if count>=TIMEOUT: error=True
    def close(self):
        try: self.client.close()
        except: pass
        try: self.target.close()
        except: pass

def main():
    server=Server(LISTEN_ADDR,LISTEN_PORT)
    server.start()
    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        server.running=False
        print("Proxy detenido")

if __name__=="__main__":
    main()
EOF
        chmod +x ${SCPinst}/PWebSocket.py
    fi

    # Ejecutar en screen
    screen -dmS wscloudflare python3 ${SCPinst}/PWebSocket.py

    echo -e "\033[1;32mProxy WebSocket Cloudflare iniciado en puerto $porta_socket -> SSH $PUERTO_LOCAL"
}

PythonDic_fun () {
echo -e "\033[1;33mSelecciona Puerto Local Y El Encabezado\033[1;37m" 
msg -bar
echo -ne "\033[1;97mDigite Un Puerto SSH/DROPBEAR activo: \033[1;92m" && read puetoantla 
msg -bar
echo -ne "\033[1;97mRespuesta de encabezado (200,101,404,500,etc): \033[1;92m" && read rescabeza
msg -bar
(
less << PYTHON  > /etc/ger-inst/PDirect.py
import socket, threading, select, sys, time

# Constantes
LISTENING_ADDR = '0.0.0.0'
LISTENING_PORT = int(sys.argv[1]) if sys.argv[1:] else 80
BUFLEN = 4096 * 4
TIMEOUT = 60
DEFAULT_HOST = '127.0.0.1:$puetoantla'

# Respuestas
HTTP_RESPONSE = 'HTTP/1.1 $rescabeza <strong>$texto_soket</strong>\r\nContent-length: 0\r\n\r\n'
WEBSOCKET_RESPONSE = 'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n'

class Server(threading.Thread):
    def __init__(self, host, port):
        threading.Thread.__init__(self)
        self.running = False
        self.host = host
        self.port = port
        self.threads = []
        self.threadsLock = threading.Lock()
        self.logLock = threading.Lock()

    def run(self):
        self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.soc.bind((self.host, int(self.port)))
        self.soc.listen(0)
        self.running = True

        try:
            while self.running:
                try:
                    client, addr = self.soc.accept()
                    client.setblocking(1)
                except socket.timeout:
                    continue
                conn = ConnectionHandler(client, self, addr)
                conn.start()
                self.addConn(conn)
        finally:
            self.running = False
            self.soc.close()

    def addConn(self, conn):
        with self.threadsLock:
            if self.running:
                self.threads.append(conn)

    def removeConn(self, conn):
        with self.threadsLock:
            if conn in self.threads:
                self.threads.remove(conn)

    def printLog(self, log):
        with self.logLock:
            print(log)

    def close(self):
        self.running = False
        with self.threadsLock:
            for t in self.threads:
                t.close()
                
class ConnectionHandler(threading.Thread):
    def __init__(self, client, server, addr):
        threading.Thread.__init__(self)
        self.client = client
        self.server = server
        self.addr = addr
        self.clientClosed = False
        self.targetClosed = True
        self.target = None
        self.log = f'Connection: {addr}'

    def close(self):
        try:
            if not self.clientClosed:
                self.client.shutdown(socket.SHUT_RDWR)
                self.client.close()
        except: pass
        self.clientClosed = True

        try:
            if self.target and not self.targetClosed:
                self.target.shutdown(socket.SHUT_RDWR)
                self.target.close()
        except: pass
        self.targetClosed = True

    def run(self):
        try:
            data = self.client.recv(BUFLEN)
            if not data: return
            host = DEFAULT_HOST

            # Conectar al puerto local
            self.target = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.target.connect((host.split(':')[0], int(host.split(':')[1])))
            self.targetClosed = False

            # Detectar WebSocket
            if b"Upgrade: websocket" in data:
                self.client.sendall(WEBSOCKET_RESPONSE)
            else:
                # HTTP normal
                self.client.sendall(HTTP_RESPONSE)
                self.target.sendall(data)

            self.forward_data()
        except Exception as e:
            self.server.printLog(f"{self.log} - error: {e}")
        finally:
            self.close()
            self.server.removeConn(self)

    def forward_data(self):
        sockets = [self.client, self.target]
        count = 0
        error = False
        while not error:
            count += 1
            r, _, e = select.select(sockets, [], sockets, 3)
            if e: error = True
            for s in r:
                try:
                    data = s.recv(BUFLEN)
                    if not data:
                        error = True
                        break
                    if s is self.client:
                        self.target.sendall(data)
                    else:
                        self.client.sendall(data)
                    count = 0
                except:
                    error = True
            if count >= TIMEOUT:
                error = True

def main():
    print("\n:-------PythonProxy WebSocket/HTTP-------:")
    print(f"Listening addr: {LISTENING_ADDR}")
    print(f"Listening port: {LISTENING_PORT}\n")
    server = Server(LISTENING_ADDR, LISTENING_PORT)
    server.start()
    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        print("Stopping...")
        server.close()

if __name__ == "__main__":
    main()
PYTHON
) > $HOME/proxy.log

chmod +x /etc/ger-inst/PDirect.py
screen -dmS pydic-"$porta_socket" python ${SCPinst}/PDirect.py "$porta_socket" "$texto_soket" && echo ""$porta_socket" "$texto_soket"" >> /etc/newadm/PortPD.log
}


pid_kill () {
[[ -z $1 ]] && refurn 1
pids="$@"
for pid in $(echo $pids); do
kill -9 $pid &>/dev/null
done
}
remove_fun() {
    echo -e "$(fun_trans "Parando Socks Python")"
    msg -bar

    # Lista de scripts de proxy a detener
    proxies=("PPub.py" "PPriv.py" "PDirect.py" "POpen.py" "PGet.py" "scktcheck" "PWebSocket.py")

    for proxy in "${proxies[@]}"; do
        # Buscar PID de procesos activos
        pid=$(ps x | grep -w "$proxy" | grep -v "grep" | awk '{print $1}')
        if [[ ! -z $pid ]]; then
            echo -e "\033[1;33mDeteniendo $proxy -> PID $pid\033[0m"
            pid_kill $pid
        fi

        # Buscar sesiones screen activas con este proxy
        screen_pid=$(screen -ls | grep -w "$proxy" | awk '{print $1}' | cut -d. -f1)
        if [[ ! -z $screen_pid ]]; then
            echo -e "\033[1;33mCerrando screen $proxy -> SID $screen_pid\033[0m"
            screen -S "$screen_pid" -X quit
        fi
    done

    echo -e "\033[1;91m$(fun_trans "Socks DETENIDOS")"
    msg -bar

    # Limpiar log de puertos
    : > /etc/newadm/PortPD.log

    exit 0
}

iniciarsocks() {
    # Verificar estado de cada proxy
    pidproxy=$(pgrep -f "PPub.py") && [[ ! -z $pidproxy ]] && P1="\033[1;32m[ON]" || P1="\033[1;31m[OFF]"
    pidproxy2=$(pgrep -f "PPriv.py") && [[ ! -z $pidproxy2 ]] && P2="\033[1;32m[ON]" || P2="\033[1;31m[OFF]"
    pidproxy3=$(pgrep -f "PDirect.py") && [[ ! -z $pidproxy3 ]] && P3="\033[1;32m[ON]" || P3="\033[1;31m[OFF]"
    pidproxy4=$(pgrep -f "POpen.py") && [[ ! -z $pidproxy4 ]] && P4="\033[1;32m[ON]" || P4="\033[1;31m[OFF]"
    pidproxy5=$(pgrep -f "PGet.py") && [[ ! -z $pidproxy5 ]] && P5="\033[1;32m[ON]" || P5="\033[1;31m[OFF]"
    pidproxy6=$(pgrep -f "scktcheck") && [[ ! -z $pidproxy6 ]] && P6="\033[1;32m[ON]" || P6="\033[1;31m[OFF]"
    pidproxy8=$(pgrep -f "PWebSocket.py") && [[ ! -z $pidproxy8 ]] && P8="\033[1;32m[ON]" || P8="\033[1;31m[OFF]"

    # Mostrar menú
    msg -bar
    msg -tit
    msg -ama "   INSTALADOR DE PROXY'S SOCKS"
    msg -bar
    echo -e "${cor[4]} [1] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python SIMPLE")\033[1;97m ------------- $P1"
    echo -e "${cor[4]} [2] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python SEGURO")\033[1;97m ------------- $P2"
    echo -e "${cor[4]} [3] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python DIRETO")\033[1;97m ------------- $P3"
    echo -e "${cor[4]} [4] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python OPENVPN")\033[1;97m ------------ $P4"
    echo -e "${cor[4]} [5] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python GETTUNEL")\033[1;97m ----------- $P5"
    echo -e "${cor[4]} [6] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "Proxy Python TCP BYPASS")\033[1;97m --------- $P6"
    echo -e "${cor[4]} [7] $(msg -verm2 "==>>") \033[1;97m$(fun_trans "¡¡ PARAR TODOS LOS PROXY'S !!")"
    echo -e "${cor[4]} [8] $(msg -verm2 "==>>") \033[1;97mProxy WebSocket Cloudflare\033[1;97m ------------- $P8"
    echo -e "$(msg -bar)\n${cor[4]} [0] $(msg -verm2 "==>>")  \e[97m\033[1;41m VOLVER \033[1;37m"
    msg -bar

    # IP para Proxy Seguro
    IP=$(meu_ip)

    # Leer opción del usuario
    while [[ -z $portproxy || ! $portproxy =~ ^[0-8]$ ]]; do
        echo -ne "$(fun_trans "Digite Una Opcion"): \033[1;37m" && read portproxy
        tput cuu1 && tput dl1
    done

    case $portproxy in
        7) remove_fun;;
        0) return;;
    esac

    # Seleccionar puerto del proxy
    echo -e "Selecciona Puerto Principal del Proxy"
    msg -bar
    porta_socket=
    while [[ -z $porta_socket || ! -z $(mportas | grep -w $porta_socket) ]]; do
        echo -ne "Digite el Puerto: \033[1;37m" && read porta_socket
        tput cuu1 && tput dl1
    done

    # Mini-banner
    echo -e "$(fun_trans "Introduzca su Mini-Banner")"
    msg -bar
    echo -ne "Introduzca el texto de estado plano o en HTML:\n \033[1;37m" && read texto_soket
    msg -bar

    # Asegurar puerto por defecto para WebSocket Cloudflare
    [[ -z "$porta_socket" ]] && porta_socket=80

    # Iniciar proxy según opción
    case $portproxy in
        1) screen -dmS ppub python ${SCPinst}/PPub.py "$porta_socket" "$texto_soket";;
        2) screen -dmS ppriv python3 ${SCPinst}/PPriv.py "$porta_socket" "$texto_soket" "$IP";;
        3) PythonDic_fun;;
        4) screen -dmS popen python ${SCPinst}/POpen.py "$porta_socket" "$texto_soket";;
        5) gettunel_fun "$porta_socket";;
        6) tcpbypass_fun "$porta_socket" "$texto_soket";;
        8)
            # Detener cualquier proceso anterior para evitar conflicto
            pid_old=$(pgrep -f "PWebSocket.py")
            [[ ! -z $pid_old ]] && kill -9 $pid_old &>/dev/null
            screen -dmS wscloudflare python3 ${SCPinst}/PWebSocket.py "$porta_socket" "$texto_soket"
        ;;
    esac

    echo -e "\033[1;92m$(fun_trans "Procedimiento COMPLETO")"
    msg -bar
}

# Ejecutar la función
iniciarsocks