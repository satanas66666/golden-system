#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

#25/01/2021 by @Kalix1
clear
clear
#!/bin/bash
# Panel WebSocket Cloudflare PRO - con dashboard automático y barra personalizada

SCPinst="/etc/ger-inst"
mkdir -p "$SCPinst" &>/dev/null

# Colores
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Barra personalizada
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
msg_bar() { echo -e "$barra"; }
msg_title() { echo -e "${cor[3]}          WEB SOCKET CLOUDFLARE PANEL"; }

# Crear script Python del Proxy
create_ws_script() {
cat << 'EOF' > ${SCPinst}/PDirect.py
#!/usr/bin/env python3
import socket, threading, select, time, sys
import base64, hashlib

LISTEN_ADDR='0.0.0.0'
LISTEN_PORT=int(sys.argv[1])
TARGET='127.0.0.1:22'
BUFLEN=4096*4
TIMEOUT=60
BANNER=sys.argv[2] if len(sys.argv)>2 else "Conectando..."
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

class Server(threading.Thread):
    def __init__(self, host, port):
        super().__init__()
        self.host = host
        self.port = port
        self.running = False
        self.threads = []

    def run(self):
        self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.soc.bind((self.host, self.port))
        self.soc.listen(0)
        self.running = True
        try:
            while self.running:
                client, addr = self.soc.accept()
                client.setblocking(1)
                conn = ConnectionHandler(client)
                conn.start()
                self.threads.append(conn)
        finally:
            self.running = False
            self.soc.close()

class ConnectionHandler(threading.Thread):
    def __init__(self, client):
        super().__init__()
        self.client = client
        self.target = None

    def run(self):
        try:
            data = self.client.recv(BUFLEN)
            if not data: return
            host, port = TARGET.split(':')
            self.target = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.target.connect((host, int(port)))

            if b"Upgrade: websocket" in data:
                self.handle_websocket(data)
            else:
                self.handle_tcp(data)
            self.forward_data()
        except Exception as e:
            print(f"[Error] {e}")
        finally:
            self.close()

    def handle_websocket(self, data):
        headers = self.parse_headers(data)
        key = headers.get('Sec-WebSocket-Key', '')
        accept = base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()
        response = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
        )
        self.client.sendall(response.encode())

    def handle_tcp(self, data):
        if BANNER:
            self.client.sendall((BANNER + "\n").encode())
        self.target.sendall(data)

    def parse_headers(self, data):
        headers = {}
        try:
            lines = data.decode(errors='ignore').split("\r\n")
            for line in lines[1:]:
                if ": " in line:
                    k, v = line.split(": ", 1)
                    headers[k.strip()] = v.strip()
        except: pass
        return headers

    def forward_data(self):
        sockets = [self.client, self.target]
        count, error = 0, False
        while not error:
            count += 1
            r, _, e = select.select(sockets, [], sockets, 3)
            if e: error = True
            for s in r:
                try:
                    data = s.recv(BUFLEN)
                    if not data: error = True; break
                    if s is self.client:
                        self.target.sendall(data)
                    else:
                        self.client.sendall(data)
                    count = 0
                except: error = True
            if count >= TIMEOUT: error = True

    def close(self):
        try: self.client.close()
        except: pass
        try: self.target.close()
        except: pass

def main():
    server = Server(LISTEN_ADDR, LISTEN_PORT)
    server.start()
    print(f"Proxy iniciado en puerto {LISTEN_PORT} - Banner: {BANNER}")
    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        server.running = False
        print("Proxy detenido")

if __name__ == "__main__":
    main()
EOF

chmod +x ${SCPinst}/PDirect.py
}

# Crear service systemd
create_systemd_service() {
PORT=$1
BANNER="$2"
SERVICE_FILE="/etc/systemd/system/wscloud-$PORT.service"

sudo systemctl stop wscloud-$PORT 2>/dev/null
sudo systemctl disable wscloud-$PORT 2>/dev/null

cat << EOF | sudo tee $SERVICE_FILE
[Unit]
Description=Proxy WebSocket/TCP Cloudflare puerto $PORT
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 ${SCPinst}/PDirect.py $PORT "$BANNER"
Restart=always
RestartSec=3
User=root
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable wscloud-$PORT
sudo systemctl start wscloud-$PORT
}

stop_systemd_service() {
echo -ne "Digite puerto a detener: " && read PORT
sudo systemctl stop wscloud-$PORT
sudo systemctl disable wscloud-$PORT
echo -e "${cor[2]}Proxy WebSocket puerto $PORT detenido"
}

proxy_status() {
PORT=$1
if systemctl is-active --quiet wscloud-$PORT; then
echo -e "${cor[4]}[ON]"
else
echo -e "${cor[2]}[OFF]"
fi
}

# Mostrar todos los proxies arriba
show_active_proxies() {
echo -e "\n${cor[3]}===== PUERTOS WebSocket ACTIVOS ====="
for svc in $(systemctl list-units --type=service | grep wscloud- | awk '{print $1}'); do
PORT_NUM=$(echo $svc | grep -oP '(?<=wscloud-)[0-9]+')
echo -n "Puerto $PORT_NUM : "
proxy_status $PORT_NUM
done
msg_bar
}

# Menú principal
while true; do
clear
msg_bar
msg_title
msg_bar
show_active_proxies   # Dashboard arriba
echo -e "${cor[3]}1) Iniciar Proxy WebSocket"
echo -e "2) Detener Proxy WebSocket"
echo -e "3) Agregar nuevo puerto WebSocket"
echo -e "0) Volver al panel principal"
msg_bar
echo -ne "${cor[0]}Seleccione opción: " && read opcion

case $opcion in
1)
create_ws_script
echo -ne "Puerto WebSocket (default 8080): " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
2)
stop_systemd_service
;;
3)
create_ws_script
echo -ne "Nuevo puerto WebSocket: " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
0) break;;
*) echo -e "${cor[2]}Opción no válida"; sleep 1;;
esac
done
msg_bar