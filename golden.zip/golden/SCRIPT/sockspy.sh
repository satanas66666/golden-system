#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
export DEBIAN_FRONTEND=noninteractive

RUSTY_DIR="/opt/rustyproxy"
BIN_FILE="${RUSTY_DIR}/target/release/rustyproxy"
mkdir -p "$RUSTY_DIR/src" &>/dev/null

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
[5]="\033[1;36m"
)

barra="${cor[3]}════════════════════════════════════════════${cor[0]}"

msg_bar() { echo -e "$barra"; }

pause_menu() {
    echo
    read -n1 -s -r -p "Presione Enter para continuar..."
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

rust_status() {
    [[ -x "$BIN_FILE" ]] && echo -e "${cor[4]}INSTALADO${cor[0]}" || echo -e "${cor[2]}NO INSTALADO${cor[0]}"
}

cargo_status() {
    command -v cargo &>/dev/null && echo -e "${cor[4]}INSTALADO${cor[0]}" || echo -e "${cor[2]}NO INSTALADO${cor[0]}"
}

service_count() {
    systemctl list-unit-files 2>/dev/null | grep -c '^wscloud-[0-9].*\.service'
}

show_header() {
    clear
    msg_bar
    echo -e "${cor[5]}        WEBSOCKET RUST PANEL PRO${cor[0]}"
    echo -e "${cor[3]}        NEW GOLDEN DASHBOARD${cor[0]}"
    msg_bar
    echo -e " Rust/Cargo       : $(cargo_status)"
    echo -e " RustyProxy       : $(rust_status)"
    echo -e " Servicios creados: ${cor[3]}$(service_count)${cor[0]}"
    msg_bar
}

check_rust() {
    if ! command -v cargo &>/dev/null; then
        echo -e "${cor[3]}Instalando Rust/Cargo...${cor[0]}"
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        source "$HOME/.cargo/env"
        export PATH="$HOME/.cargo/bin:$PATH"

        if ! command -v cargo &>/dev/null; then
            echo -e "${cor[2]}ERROR: no se pudo instalar Rust/Cargo.${cor[0]}"
            exit 1
        fi
    fi
}

create_rust_proxy() {
    check_rust
    mkdir -p "${RUSTY_DIR}/src"

cat << 'EOT' > "${RUSTY_DIR}/Cargo.toml"
[package]
name = "rustyproxy"
version = "0.1.0"
edition = "2021"

[dependencies]
tokio = { version = "1.28.2", features = ["full"] }
EOT

cat << 'EOF' > "${RUSTY_DIR}/src/main.rs"
use std::env;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Mutex;
use tokio::time::{Duration, timeout};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let port = get_port();
    println!("Proxy Rust iniciado en puerto: {}", port);
    start_http(port).await?;
    Ok(())
}

async fn start_http(port: u16) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let listener = TcpListener::bind(("0.0.0.0", port)).await?;
    loop {
        let (client_stream, addr) = listener.accept().await?;
        tokio::spawn(async move {
            if let Err(e) = handle_client(client_stream).await {
                eprintln!("Error procesando cliente {}: {:?}", addr, e);
            }
        });
    }
}

async fn handle_client(client_stream: TcpStream) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let status = get_status();
    let mut client_stream = client_stream;
    client_stream.write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes()).await?;
    let mut buffer = vec![0; 1024];
    let _ = client_stream.read(&mut buffer).await?;
    client_stream.write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes()).await?;

    let mut addr_proxy = "127.0.0.1:22";

    let peek_result = timeout(Duration::from_secs(1), peek_stream(&client_stream))
        .await
        .unwrap_or_else(|_| Ok(String::new()))?;

    if !peek_result.is_empty() && !peek_result.contains("SSH") {
        addr_proxy = "127.0.0.1:1194";
    }

    let server_stream = TcpStream::connect(addr_proxy).await?;
    let (client_read, client_write) = client_stream.into_split();
    let (server_read, server_write) = server_stream.into_split();

    let client_read = Arc::new(Mutex::new(client_read));
    let client_write = Arc::new(Mutex::new(client_write));
    let server_read = Arc::new(Mutex::new(server_read));
    let server_write = Arc::new(Mutex::new(server_write));

    tokio::try_join!(
        transfer_data(client_read, server_write),
        transfer_data(server_read, client_write)
    )?;
    Ok(())
}

async fn transfer_data(
    read_stream: Arc<Mutex<tokio::net::tcp::OwnedReadHalf>>,
    write_stream: Arc<Mutex<tokio::net::tcp::OwnedWriteHalf>>
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut buffer = [0; 8192];
    loop {
        let bytes_read = {
            let mut read_guard = read_stream.lock().await;
            read_guard.read(&mut buffer).await?
        };
        if bytes_read == 0 { break; }
        let mut write_guard = write_stream.lock().await;
        write_guard.write_all(&buffer[..bytes_read]).await?;
    }
    Ok(())
}

async fn peek_stream(stream: &TcpStream) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    let mut peek_buffer = vec![0; 8192];
    let bytes_peeked = stream.peek(&mut peek_buffer).await?;
    Ok(String::from_utf8_lossy(&peek_buffer[..bytes_peeked]).to_string())
}

fn get_port() -> u16 {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--port" && i+1 < args.len() {
            return args[i+1].parse().unwrap_or(8080);
        }
    }
    8080
}

fn get_status() -> String {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--status" && i+1 < args.len() {
            return args[i+1].clone();
        }
    }
    "@RustyManager".to_string()
}
EOF

    echo -e "${cor[3]}Compilando RustyProxy...${cor[0]}"
    cd "$RUSTY_DIR" || return 1

    cargo build --release --jobs "$(nproc)" || {
        echo -e "${cor[2]}ERROR: Falló la compilación.${cor[0]}"
        cd - &>/dev/null
        return 1
    }

    cd - &>/dev/null
    chmod +x "$BIN_FILE"

    echo -e "${cor[4]}RustyProxy instalado correctamente.${cor[0]}"
}

create_systemd_service() {
    PORT="$1"
    BANNER="$2"
    SERVICE_FILE="/etc/systemd/system/wscloud-${PORT}.service"

    if [[ ! -x "$BIN_FILE" ]]; then
        echo -e "${cor[2]}ERROR: RustyProxy no está instalado. Usa opción 1 primero.${cor[0]}"
        return 1
    fi

    valid_port "$PORT" || {
        echo -e "${cor[2]}ERROR: Puerto inválido.${cor[0]}"
        return 1
    }

    systemctl stop "wscloud-${PORT}" 2>/dev/null
    systemctl disable "wscloud-${PORT}" 2>/dev/null

cat << EOF > "$SERVICE_FILE"
[Unit]
Description=Proxy WebSocket Rust puerto $PORT
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${BIN_FILE} --port $PORT --status "$BANNER"
Restart=always
RestartSec=3
User=root
LimitNOFILE=65535
TimeoutStartSec=30
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=wscloud-$PORT

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable "wscloud-${PORT}" >/dev/null 2>&1
    systemctl start "wscloud-${PORT}" >/dev/null 2>&1

    sleep 1

    if systemctl is-active --quiet "wscloud-${PORT}"; then
        echo -e "${cor[4]}Proxy WebSocket iniciado correctamente.${cor[0]}"
        echo -e "Puerto : ${cor[3]}$PORT${cor[0]}"
        echo -e "Banner : ${cor[3]}$BANNER${cor[0]}"
    else
        echo -e "${cor[2]}ERROR: No pudo iniciar el servicio.${cor[0]}"
        systemctl status "wscloud-${PORT}" --no-pager
    fi
}

stop_proxy_service() {
    PORT="$1"

    valid_port "$PORT" || {
        echo -e "${cor[2]}Puerto inválido.${cor[0]}"
        return 1
    }

    systemctl stop "wscloud-${PORT}" 2>/dev/null
    systemctl disable "wscloud-${PORT}" 2>/dev/null

    if systemctl is-active --quiet "wscloud-${PORT}"; then
        echo -e "${cor[2]}No se pudo detener wscloud-${PORT}.${cor[0]}"
    else
        echo -e "${cor[4]}Proxy Rust puerto $PORT detenido correctamente.${cor[0]}"
    fi
}

show_active_proxies() {
    echo -e "${cor[5]}PUERTOS WEBSOCKET ABIERTOS${cor[0]}"
    msg_bar

    found=0

    for file in /etc/systemd/system/wscloud-*.service; do
        [[ -f "$file" ]] || continue

        svc=$(basename "$file")
        PORT_NUM=$(echo "$svc" | grep -oE '[0-9]+')
        BANNER=$(grep 'ExecStart' "$file" | awk -F '--status ' '{print $2}' | sed 's/"//g')

        if systemctl is-active --quiet "wscloud-${PORT_NUM}"; then
            STATUS="${cor[4]}ONLINE${cor[0]}"
        else
            STATUS="${cor[2]}OFFLINE${cor[0]}"
        fi

        echo -e " Puerto ${cor[3]}$PORT_NUM${cor[0]} : $STATUS | Banner: ${cor[5]}${BANNER:-N/A}${cor[0]}"
        found=1
    done

    if [[ "$found" == "0" ]]; then
        echo -e "${cor[2]}No hay puertos WebSocket creados.${cor[0]}"
    fi

    msg_bar
}

while true; do
    show_header
    show_active_proxies

    echo -e "${cor[3]}[1]${cor[0]} Instalar RustyProxy"
    echo -e "${cor[3]}[2]${cor[0]} Iniciar puerto WebSocket"
    echo -e "${cor[3]}[3]${cor[0]} Detener puerto WebSocket"
    echo -e "${cor[3]}[0]${cor[0]} Salir"
    msg_bar

    echo -ne "${cor[0]}Seleccione opción: "
    read -r opcion

    case "$opcion" in
        1)
            create_rust_proxy
            pause_menu
            ;;

        2)
            echo -ne "Puerto WebSocket a iniciar [8080]: "
            read -r PORT
            PORT="${PORT:-8080}"

            if ! valid_port "$PORT"; then
                echo -e "${cor[2]}Puerto inválido.${cor[0]}"
                pause_menu
                continue
            fi

            echo -ne "Banner [@RustyManager]: "
            read -r BANNER
            BANNER="${BANNER:-@RustyManager}"

            create_systemd_service "$PORT" "$BANNER"
            pause_menu
            ;;

        3)
            echo -ne "Puerto WebSocket a detener: "
            read -r PORT
            stop_proxy_service "$PORT"
            pause_menu
            ;;

        0)
            msg_bar
            echo -e "${cor[4]}Saliendo del panel WebSocket.${cor[0]}"
            msg_bar
            break
            ;;

        *)
            echo -e "${cor[2]}Opción no válida.${cor[0]}"
            sleep 1
            ;;
    esac
done