#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/
Block="/etc/nanotxz" && [[ ! -d ${Block} ]] && exit
Block > /dev/null 2>&1

#25/01/2021 by @Kalix1
clear
clear
#!/bin/bash
# Panel WebSocket Cloudflare PRO - con dashboard automático y barra personalizada

SCPinst="/etc/ger-inst"
mkdir -p "$SCPinst" &>/dev/null

# Colores
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Barra personalizada
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
msg_bar() { echo -e "$barra"; }
msg_title() { echo -e "${cor[3]}          WEB SOCKET CLOUDFLARE PANEL"; }

# Crear script Python del Proxy
create_ws_script() {
cat << 'EOF' > ${SCPinst}/PDirect.py
#!/usr/bin/env python3
import socket, threading, time, sys, select

LISTEN_ADDR = '0.0.0.0'
LISTEN_PORT = int(sys.argv[1])
TARGET = '127.0.0.1:22'
BUFLEN = 8192
STATUS = sys.argv[2] if len(sys.argv) > 2 else "@Proxy"

class Server(threading.Thread):
    def __init__(self, host, port):
        super().__init__()
        self.host = host
        self.port = port

    def run(self):
        soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        soc.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        soc.bind((self.host, self.port))
        soc.listen(5000)  # soporte para muchas conexiones
        print(f"Proxy híbrido activo en puerto {self.port}")

        while True:
            try:
                client, addr = soc.accept()
                Connection(client).start()
            except Exception as e:
                print("Error al aceptar cliente:", e)

class Connection(threading.Thread):
    def __init__(self, client):
        super().__init__()
        self.client = client

    def run(self):
        remote = None
        try:
            # ---- RESPUESTA FALSA ----
            self.client.sendall(f"HTTP/1.1 101 {STATUS}\r\n\r\n".encode())
            try:
                self.client.recv(BUFLEN)
            except:
                pass
            self.client.sendall(f"HTTP/1.1 200 {STATUS}\r\n\r\n".encode())

            # ---- CONECTAR BACKEND ----
            host, port = TARGET.split(":")
            remote = socket.create_connection((host, int(port)))
            remote.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.client.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)

            # ---- PIPE NO BLOQUEANTE ----
            c, r = self.client, remote
            c.setblocking(False)
            r.setblocking(False)
            sockets = [c, r]

            while True:
                try:
                    readable, _, exceptional = select.select(sockets, [], sockets, 1.0)

                    for s in readable:
                        try:
                            data = s.recv(BUFLEN)
                            if not data:
                                # cierre solo si desconectó realmente
                                return
                            if s is c:
                                r.sendall(data)
                            else:
                                c.sendall(data)
                        except:
                            return

                    for s in exceptional:
                        return

                except Exception:
                    return

        except Exception as e:
            print("Error en conexión:", e)
        finally:
            try: self.client.close()
            except: pass
            if remote:
                try: remote.close()
                except: pass

def main():
    Server(LISTEN_ADDR, LISTEN_PORT).start()
    while True:
        time.sleep(10)

if __name__ == "__main__":
    main()
EOF

chmod +x ${SCPinst}/PDirect.py
}

# Crear service systemd
create_systemd_service() {
    PORT=$1
    BANNER="$2"
    SERVICE_FILE="/etc/systemd/system/wscloud-$PORT.service"

    # Detener y deshabilitar si existe (evita conflictos)
    sudo systemctl stop wscloud-$PORT 2>/dev/null
    sudo systemctl disable wscloud-$PORT 2>/dev/null

    # Crear el archivo de servicio
    cat << EOF | sudo tee $SERVICE_FILE >/dev/null
[Unit]
Description=Proxy WebSocket/TCP Cloudflare puerto $PORT
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 ${SCPinst}/PDirect.py $PORT "$BANNER"
Restart=always           # Reinicia automáticamente si falla
RestartSec=3             # Espera 3 segundos antes de reiniciar
User=root
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

    # Recargar systemd, habilitar y arrancar el servicio
    sudo systemctl daemon-reload
    sudo systemctl enable wscloud-$PORT  # Asegura que se inicie al reinicio de la VPS
    sudo systemctl start wscloud-$PORT

    echo -e "✅ Proxy WebSocket en puerto $PORT activo y protegido contra reinicios"
}

stop_systemd_service() {
echo -ne "Digite puerto a detener: " && read PORT
sudo systemctl stop wscloud-$PORT
sudo systemctl disable wscloud-$PORT
echo -e "${cor[2]}Proxy WebSocket puerto $PORT detenido"
}

proxy_status() {
PORT=$1
if systemctl is-active --quiet wscloud-$PORT; then
echo -e "${cor[4]}[ON]"
else
echo -e "${cor[2]}[OFF]"
fi
}

# Mostrar todos los proxies arriba
show_active_proxies() {
echo -e "\n${cor[3]}===== PUERTOS WebSocket ACTIVOS ====="
for svc in $(systemctl list-units --type=service | grep wscloud- | awk '{print $1}'); do
PORT_NUM=$(echo $svc | grep -oP '(?<=wscloud-)[0-9]+')
echo -n "Puerto $PORT_NUM : "
proxy_status $PORT_NUM
done
msg_bar
}

# Menú principal
while true; do
clear
msg_bar
msg_title
msg_bar
show_active_proxies   # Dashboard arriba
echo -e "${cor[3]}1) Iniciar Proxy WebSocket"
echo -e "2) Detener Proxy WebSocket"
echo -e "3) Agregar nuevo puerto WebSocket"
echo -e "0) Volver al panel principal"
msg_bar
echo -ne "${cor[0]}Seleccione opción: " && read opcion

case $opcion in
1)
create_ws_script
echo -ne "Puerto WebSocket (default 8080): " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
2)
stop_systemd_service
;;
3)
create_ws_script
echo -ne "Nuevo puerto WebSocket: " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
0) break;;
*) echo -e "${cor[2]}Opción no válida"; sleep 1;;
esac
done
msg_bar