import socket, threading, select, sys, time

# Listen
LISTENING_ADDR = '0.0.0.0'
LISTENING_PORT = int(sys.argv[1]) if sys.argv[1:] else 80

# Pass
PASS = ''

# Constantes
BUFLEN = 4096 * 4
TIMEOUT = 60
DEFAULT_HOST = '127.0.0.1:22'

# Respuestas
HTTP_RESPONSE = 'HTTP/1.1 200 Connection established\r\n\r\n'
WEBSOCKET_RESPONSE = 'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n'

class Server(threading.Thread):
    def __init__(self, host, port):
        threading.Thread.__init__(self)
        self.running = False
        self.host = host
        self.port = port
        self.threads = []
        self.threadsLock = threading.Lock()
        self.logLock = threading.Lock()

    def run(self):
        self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.soc.bind((self.host, self.port))
        self.soc.listen(0)
        self.running = True

        try:
            while self.running:
                try:
                    client, addr = self.soc.accept()
                    client.setblocking(1)
                except socket.timeout:
                    continue
                conn = ConnectionHandler(client, self, addr)
                conn.start()
                self.addConn(conn)
        finally:
            self.running = False
            self.soc.close()

    def addConn(self, conn):
        with self.threadsLock:
            if self.running:
                self.threads.append(conn)

    def removeConn(self, conn):
        with self.threadsLock:
            if conn in self.threads:
                self.threads.remove(conn)

    def printLog(self, log):
        with self.logLock:
            print(log)

    def close(self):
        self.running = False
        with self.threadsLock:
            for t in self.threads:
                t.close()


class ConnectionHandler(threading.Thread):
    def __init__(self, client, server, addr):
        threading.Thread.__init__(self)
        self.client = client
        self.server = server
        self.addr = addr
        self.clientClosed = False
        self.targetClosed = True
        self.target = None
        self.log = f'Connection: {addr}'

    def close(self):
        try:
            if not self.clientClosed:
                self.client.shutdown(socket.SHUT_RDWR)
                self.client.close()
        except: pass
        self.clientClosed = True

        try:
            if self.target and not self.targetClosed:
                self.target.shutdown(socket.SHUT_RDWR)
                self.target.close()
        except: pass
        self.targetClosed = True

    def run(self):
        try:
            data = self.client.recv(BUFLEN)
            if not data:
                return

            hostPort = self.findHeader(data, 'X-Real-Host') or DEFAULT_HOST
            passwd = self.findHeader(data, 'X-Pass')

            # Autenticación simple
            if PASS and passwd != PASS:
                self.client.send(b'HTTP/1.1 400 WrongPass!\r\n\r\n')
                return

            # Conexión permitida solo a localhost
            if not (hostPort.startswith('127.0.0.1') or hostPort.startswith('localhost')):
                self.client.send(b'HTTP/1.1 403 Forbidden!\r\n\r\n')
                return

            # Detectar WebSocket
            if b'Upgrade: websocket' in data:
                self.client.sendall(WEBSOCKET_RESPONSE)
                self.connect_target(hostPort)
                self.forward_data()
            else:
                # CONNECT normal o HTTP
                self.client.sendall(HTTP_RESPONSE)
                self.connect_target(hostPort)
                self.target.sendall(data)
                self.forward_data()

        except Exception as e:
            self.server.printLog(f"{self.log} - error: {e}")
        finally:
            self.close()
            self.server.removeConn(self)

    def findHeader(self, data, header):
        try:
            headers = data.decode(errors='ignore').split('\r\n')
            for h in headers:
                if h.startswith(header + ':'):
                    return h.split(':', 1)[1].strip()
        except: pass
        return ''

    def connect_target(self, host):
        if ':' in host:
            h, p = host.split(':')
            port = int(p)
        else:
            h = host
            port = 22
        self.target = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.target.connect((h, port))
        self.targetClosed = False

    def forward_data(self):
        sockets = [self.client, self.target]
        count = 0
        error = False
        while not error:
            count += 1
            r, _, e = select.select(sockets, [], sockets, 3)
            if e: error = True
            for s in r:
                try:
                    data = s.recv(BUFLEN)
                    if not data:
                        error = True
                        break
                    if s is self.client:
                        self.target.sendall(data)
                    else:
                        self.client.sendall(data)
                    count = 0
                except:
                    error = True
            if count >= TIMEOUT:
                error = True


def main():
    print(f"\n:-------PythonProxy WebSocket/HTTP-------:")
    print(f"Listening addr: {LISTENING_ADDR}")
    print(f"Listening port: {LISTENING_PORT}\n")
    server = Server(LISTENING_ADDR, LISTENING_PORT)
    server.start()
    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        print("Stopping...")
        server.close()


if __name__ == "__main__":
    main()