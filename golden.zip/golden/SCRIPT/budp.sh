#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-verd) shift; echo -e "${cor[4]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

BIN="/bin/badvpn-udpgw"
SERVICE="/etc/systemd/system/badvpn-udpgw.service"
PORTS_FILE="/etc/badvpn-ports.conf"
LOG_FILE="/tmp/badvpn_install.log"

fun_bar () {
    comando="$1"
    $comando >"$LOG_FILE" 2>&1 &
    pid=$!

    i=0
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando BADVPN UDPGW..." "$s"
        sleep 0.15
    done

    wait "$pid"
    res=$?
    printf "\r\033[K"

    if [[ "$res" != "0" ]]; then
        echo "ERROR EN BADVPN UDPGW"
        tail -n 40 "$LOG_FILE"
        sleep 2
        return 1
    fi

    echo "OK - COMPLETADO"
    sleep 0.5
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

crear_puertos_default_badvpn() {
    if [[ ! -f "$PORTS_FILE" ]]; then
        echo "7200" > "$PORTS_FILE"
        echo "7300" >> "$PORTS_FILE"
        echo "7400" >> "$PORTS_FILE"
    fi
}

instalar_base_badvpn() {
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1
    dpkg --configure -a >/dev/null 2>&1

    apt-get update -y
    apt-get install -y wget curl screen net-tools iproute2 ca-certificates \
        git cmake make gcc g++ build-essential
}

optimizar_badvpn_juegos() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-badvpn-games.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.udp_mem = 3145728 4194304 8388608
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden-badvpn.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    systemctl daemon-reexec >/dev/null 2>&1
    systemctl daemon-reload >/dev/null 2>&1
}

descargar_badvpn() {
    if [[ -x "$BIN" ]]; then
        return 0
    fi

    apt-get install -y badvpn >/dev/null 2>&1

    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null
        chmod +x "$BIN"
        return 0
    fi

    rm -rf /tmp/badvpn-src
    git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn-src >/dev/null 2>&1 || return 1

    cd /tmp/badvpn-src || return 1
    mkdir -p build
    cd build || return 1

    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >/dev/null 2>&1 || return 1
    make -j"$(nproc)" >/dev/null 2>&1 || return 1

    if [[ -x udpgw/badvpn-udpgw ]]; then
        cp udpgw/badvpn-udpgw "$BIN"
        chmod +x "$BIN"
        return 0
    fi

    return 1
}

crear_servicio_badvpn() {
    crear_puertos_default_badvpn

cat > "$SERVICE" <<'EOF'
[Unit]
Description=BadVPN UDPGW MultiPort - New Golden Games
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'ulimit -n 1048576; while read PORT; do [[ -n "$PORT" ]] && /bin/badvpn-udpgw --listen-addr 127.0.0.1:$PORT --max-clients 5000 --max-connections-for-client 20 & done < /etc/badvpn-ports.conf; wait'
ExecStop=/bin/bash -c 'pkill -f badvpn-udpgw'
Restart=always
RestartSec=2
StartLimitIntervalSec=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Nice=-5
IOSchedulingClass=best-effort
IOSchedulingPriority=0
KillMode=control-group
TimeoutStartSec=20
TimeoutStopSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

restart_badvpn() {
    systemctl enable badvpn-udpgw >/dev/null 2>&1
    systemctl restart badvpn-udpgw >/dev/null 2>&1
    sleep 1

    if pgrep -f badvpn-udpgw >/dev/null 2>&1; then
        return 0
    fi

    systemctl restart badvpn-udpgw >/dev/null 2>&1
    sleep 1

    pgrep -f badvpn-udpgw >/dev/null 2>&1
}

mostrar_badvpn_activos() {
    linea
    echo -e "        ${cor[3]}BADVPN UDPGW - JUEGOS ONLINE${cor[0]}"
    linea2

    if pgrep -f badvpn-udpgw >/dev/null 2>&1; then
        echo -e "   ${cor[4]}[ONLINE] BADVPN UDPGW ACTIVO${cor[0]}"
    else
        echo -e "   ${cor[2]}[OFFLINE] BADVPN UDPGW DESACTIVADO${cor[0]}"
    fi

    linea2

    if [[ -f "$PORTS_FILE" ]]; then
        echo -e "   ${cor[3]}Puertos configurados:${cor[0]}"
        while read -r p; do
            [[ -n "$p" ]] && echo "   [UDP] Puerto : $p"
        done < "$PORTS_FILE"
    else
        echo -e "   ${cor[2]}No hay puertos configurados.${cor[0]}"
    fi
}

instalar_badvpn() {
    clean_screen
    echo "INSTALAR BADVPN UDPGW"
    linea
    echo "Esta opcion instalara BADVPN para juegos online"
    echo "Puertos default: 7200, 7300, 7400"
    linea

    fun_bar "instalar_base_badvpn" || return 1
    optimizar_badvpn_juegos

    descargar_badvpn || {
        linea
        echo "ERROR: No se pudo instalar badvpn-udpgw"
        echo "Revisa conexion a internet o paquetes de compilacion"
        linea
        read -p "Presiona ENTER para continuar..."
        return 1
    }

    crear_servicio_badvpn

    if restart_badvpn; then
        linea
        echo "BADVPN UDPGW INSTALADO CON EXITO"
        echo "Puertos activos:"
        cat "$PORTS_FILE"
        linea
    else
        linea
        echo "ERROR: BADVPN no pudo iniciar"
        echo "Revisa: systemctl status badvpn-udpgw"
        linea
    fi

    read -p "Presiona ENTER para continuar..."
}

agregar_puerto_badvpn() {
    clean_screen
    echo "AGREGAR PUERTO BADVPN UDPGW"
    linea

    crear_puertos_default_badvpn

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    while true; do
        read -p "Nuevo puerto UDP: " NEWPORT
        valid_port "$NEWPORT" || { echo "Puerto invalido"; continue; }

        if grep -wq "$NEWPORT" "$PORTS_FILE"; then
            echo "Ese puerto ya esta agregado"
        else
            break
        fi
    done

    echo "$NEWPORT" >> "$PORTS_FILE"

    descargar_badvpn || {
        echo "ERROR: badvpn-udpgw no existe"
        read -p "Presiona ENTER para continuar..."
        return 1
    }

    crear_servicio_badvpn

    if restart_badvpn; then
        linea
        echo "PUERTO AGREGADO CON EXITO"
        echo "BADVPN UDP: $NEWPORT"
        linea
    else
        linea
        echo "ERROR: No se pudo reiniciar BADVPN"
        linea
    fi

    read -p "Presiona ENTER para continuar..."
}

eliminar_puerto_badvpn() {
    clean_screen
    echo "ELIMINAR PUERTO BADVPN UDPGW"
    linea

    if [[ ! -f "$PORTS_FILE" ]]; then
        echo "No hay puertos configurados"
        read -p "Presiona ENTER para continuar..."
        return 0
    fi

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    read -p "Puerto a eliminar: " DELPORT
    valid_port "$DELPORT" || {
        echo "Puerto invalido"
        read -p "Presiona ENTER para continuar..."
        return 1
    }

    if ! grep -wq "$DELPORT" "$PORTS_FILE"; then
        echo "Ese puerto no existe"
        read -p "Presiona ENTER para continuar..."
        return 1
    fi

    grep -vw "$DELPORT" "$PORTS_FILE" > /tmp/badvpn_ports.tmp
    mv /tmp/badvpn_ports.tmp "$PORTS_FILE"

    restart_badvpn

    linea
    echo "PUERTO ELIMINADO: $DELPORT"
    linea

    read -p "Presiona ENTER para continuar..."
}

desinstalar_badvpn() {
    clean_screen
    echo "DESINSTALAR BADVPN UDPGW"
    linea
    echo "Esta opcion eliminara BADVPN UDPGW completamente"
    linea

    read -p "¿Deseas continuar? [s/n]: " confirm
    [[ "$confirm" != "s" && "$confirm" != "S" ]] && return 0

    desinstalar_badvpn_completo() {
        systemctl stop badvpn-udpgw >/dev/null 2>&1
        systemctl disable badvpn-udpgw >/dev/null 2>&1
        pkill -f badvpn-udpgw >/dev/null 2>&1

        rm -f "$SERVICE"
        rm -f "$PORTS_FILE"
        rm -f "$LOG_FILE"

        rm -f /etc/sysctl.d/99-newgolden-badvpn-games.conf
        rm -f /etc/security/limits.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/system.conf.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/user.conf.d/99-newgolden-badvpn.conf

        sysctl --system >/dev/null 2>&1
        systemctl daemon-reexec >/dev/null 2>&1
        systemctl daemon-reload >/dev/null 2>&1
        systemctl reset-failed >/dev/null 2>&1
    }

    fun_bar "desinstalar_badvpn_completo"

    linea
    echo "BADVPN UDPGW ELIMINADO COMPLETAMENTE"
    linea

    read -p "Presiona ENTER para continuar..."
}

ver_estado_badvpn() {
    clean_screen
    mostrar_badvpn_activos
    linea2
    echo "Procesos activos:"
    ps x | grep badvpn-udpgw | grep -v grep || echo "No hay procesos activos"
    linea2
    echo "Puertos UDP escuchando:"
    ss -lunp 2>/dev/null | grep badvpn || echo "No hay puertos UDP activos"
    linea2
    echo "Estado systemd:"
    systemctl is-active badvpn-udpgw 2>/dev/null || echo "inactive"
    linea
    read -p "Presiona ENTER para continuar..."
}

gestor_fun () {
while true; do
clean_screen
mostrar_badvpn_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR BADVPN UDPGW${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}INSTALAR / ACTIVAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS UDP"
echo -e "   ${cor[2]}[3]${cor[0]}  ELIMINAR PUERTO UDP"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  VER ESTADO BADVPN"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) instalar_badvpn ;;
    2) agregar_puerto_badvpn ;;
    3) eliminar_puerto_badvpn ;;
    4) desinstalar_badvpn ;;
    5) ver_estado_badvpn ;;
esac
done
}

gestor_fun