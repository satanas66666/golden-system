#!/bin/bash
# BADVPN UDPGW EXTREMO - New Golden ADM PRO
# Compatible: Ubuntu 20/22/24 y Debian 10/11/12
# Arquitectura: 1 servicio systemd independiente por puerto
# Ventaja: si cae un puerto, se reinicia solo sin tumbar los demas.

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-verd) shift; echo -e "${cor[4]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

BIN="/usr/local/bin/badvpn-udpgw"
BIN_ALT="/bin/badvpn-udpgw"
TEMPLATE_SERVICE="/etc/systemd/system/badvpn-udpgw@.service"
TARGET_SERVICE="/etc/systemd/system/badvpn-udpgw.target"
PORTS_FILE="/etc/badvpn-ports.conf"
LOG_DIR="/var/log/badvpn-udpgw"
LOG_FILE="/tmp/badvpn_install.log"

MAX_CLIENTS="20000"
MAX_CONN_CLIENT="50"

fun_bar () {
    local comando="$1"
    $comando >"$LOG_FILE" 2>&1 &
    local pid=$!
    local i=0 s
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando BADVPN UDPGW EXTREMO..." "$s"
        sleep 0.15
    done
    wait "$pid"
    local res=$?
    printf "\r\033[K"
    if [[ "$res" != "0" ]]; then
        echo "ERROR EN BADVPN UDPGW"
        tail -n 100 "$LOG_FILE"
        sleep 2
        return 1
    fi
    echo "OK - COMPLETADO"
    sleep 0.5
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

crear_puertos_default_badvpn() {
    if [[ ! -f "$PORTS_FILE" ]]; then
        {
            echo "7200"
            echo "7300"
            echo "7400"
        } > "$PORTS_FILE"
    fi
    sed -i '/^[[:space:]]*$/d' "$PORTS_FILE"
    grep -E '^[0-9]+$' "$PORTS_FILE" | awk '$1>=1 && $1<=65535' | sort -n -u > /tmp/badvpn_ports_clean.tmp
    mv /tmp/badvpn_ports_clean.tmp "$PORTS_FILE"
}

reparar_dpkg_apache() {
    if dpkg -l apache2 >/dev/null 2>&1 || [[ -d /etc/apache2 ]]; then
        mkdir -p /etc/apache2/mods-enabled /etc/apache2/mods-available
        if [[ -e /etc/apache2/mods-available/mpm_event.load ]]; then
            rm -f /etc/apache2/mods-enabled/mpm_prefork.load /etc/apache2/mods-enabled/mpm_prefork.conf
            rm -f /etc/apache2/mods-enabled/mpm_worker.load  /etc/apache2/mods-enabled/mpm_worker.conf
            ln -sf ../mods-available/mpm_event.load /etc/apache2/mods-enabled/mpm_event.load
            [[ -e /etc/apache2/mods-available/mpm_event.conf ]] && ln -sf ../mods-available/mpm_event.conf /etc/apache2/mods-enabled/mpm_event.conf
        fi
    fi
    dpkg --configure -a >/dev/null 2>&1 || true
    apt-get -f install -y >/dev/null 2>&1 || true
}

instalar_base_badvpn() {
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1
    reparar_dpkg_apache
    apt-get update -y
    apt-get install -y wget curl net-tools iproute2 ca-certificates git cmake make gcc g++ build-essential
}

optimizar_badvpn_extremo() {
    mkdir -p /etc/sysctl.d /etc/security/limits.d /etc/systemd/system.conf.d /etc/systemd/user.conf.d "$LOG_DIR"

cat >/etc/sysctl.d/99-newgolden-badvpn-extremo.conf <<'SYSCTL'
fs.file-max = 4194304
fs.nr_open = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 250000
net.core.rmem_max = 268435456
net.core.wmem_max = 268435456
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 32768
net.ipv4.udp_wmem_min = 32768
net.ipv4.udp_mem = 4194304 8388608 16777216
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 60
net.ipv4.tcp_keepalive_intvl = 15
net.ipv4.tcp_keepalive_probes = 4
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_syncookies = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
SYSCTL
    sysctl --system >/dev/null 2>&1 || true

cat >/etc/security/limits.d/99-newgolden-badvpn-extremo.conf <<'LIMITS'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
* soft nproc 1048576
* hard nproc 1048576
root soft nproc 1048576
root hard nproc 1048576
LIMITS

cat >/etc/systemd/system.conf.d/99-newgolden-badvpn-extremo.conf <<'SYSD'
[Manager]
DefaultLimitNOFILE=1048576
DefaultLimitNPROC=1048576
DefaultTasksMax=infinity
SYSD

cat >/etc/systemd/user.conf.d/99-newgolden-badvpn-extremo.conf <<'SYSDU'
[Manager]
DefaultLimitNOFILE=1048576
DefaultLimitNPROC=1048576
DefaultTasksMax=infinity
SYSDU

    systemctl daemon-reexec >/dev/null 2>&1 || true
    systemctl daemon-reload >/dev/null 2>&1 || true
}

descargar_badvpn() {
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN" 2>/dev/null || true
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi
    if [[ -x "$BIN" ]]; then
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi
    apt-get install -y badvpn >/dev/null 2>&1 || true
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN"
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi
    rm -rf /tmp/badvpn-src
    git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn-src >/dev/null 2>&1 || return 1
    cd /tmp/badvpn-src || return 1
    mkdir -p build && cd build || return 1
    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >/dev/null 2>&1 || return 1
    make -j"$(nproc)" >/dev/null 2>&1 || return 1
    if [[ -x udpgw/badvpn-udpgw ]]; then
        cp udpgw/badvpn-udpgw "$BIN"
        chmod +x "$BIN"
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi
    return 1
}

crear_servicios_extremos() {
    crear_puertos_default_badvpn
    mkdir -p "$LOG_DIR"

cat > "$TEMPLATE_SERVICE" <<EOF2
[Unit]
Description=BadVPN UDPGW Puerto %i - New Golden EXTREMO
After=network-online.target
Wants=network-online.target
PartOf=badvpn-udpgw.target

[Service]
Type=simple
ExecStart=$BIN --listen-addr 0.0.0.0:%i --max-clients $MAX_CLIENTS --max-connections-for-client $MAX_CONN_CLIENT
Restart=always
RestartSec=1
StartLimitIntervalSec=0
StartLimitBurst=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Nice=-10
OOMScoreAdjust=-900
KillMode=process
TimeoutStartSec=10
TimeoutStopSec=10
StandardOutput=append:$LOG_DIR/port-%i.log
StandardError=append:$LOG_DIR/port-%i.log

[Install]
WantedBy=multi-user.target
EOF2

cat > "$TARGET_SERVICE" <<'EOF2'
[Unit]
Description=BadVPN UDPGW MultiPuerto Target - New Golden EXTREMO
After=network-online.target
Wants=network-online.target
AllowIsolate=no

[Install]
WantedBy=multi-user.target
EOF2

    systemctl daemon-reload >/dev/null 2>&1
}

abrir_firewall_badvpn() {
    [[ -f "$PORTS_FILE" ]] || return 0
    if command -v ufw >/dev/null 2>&1; then
        while read -r p; do
            valid_port "$p" || continue
            ufw allow "$p"/tcp >/dev/null 2>&1 || true
            ufw allow "$p"/udp >/dev/null 2>&1 || true
        done < "$PORTS_FILE"
    fi
    if command -v iptables >/dev/null 2>&1; then
        while read -r p; do
            valid_port "$p" || continue
            iptables -C INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
            iptables -C INPUT -p udp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p udp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
        done < "$PORTS_FILE"
    fi
}

habilitar_puertos_badvpn() {
    crear_puertos_default_badvpn
    systemctl enable badvpn-udpgw.target >/dev/null 2>&1 || true
    while read -r p; do
        valid_port "$p" || continue
        systemctl enable "badvpn-udpgw@$p" >/dev/null 2>&1 || true
        systemctl restart "badvpn-udpgw@$p" >/dev/null 2>&1 || true
    done < "$PORTS_FILE"
}

restart_badvpn() {
    descargar_badvpn || return 1
    crear_servicios_extremos
    abrir_firewall_badvpn
    habilitar_puertos_badvpn
    sleep 2
    while read -r p; do
        valid_port "$p" || continue
        systemctl is-active --quiet "badvpn-udpgw@$p" || return 1
    done < "$PORTS_FILE"
    return 0
}

puerto_activo_badvpn() {
    local p="$1"
    systemctl is-active --quiet "badvpn-udpgw@$p" 2>/dev/null && ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(:|\\.)${p}$"
}

mostrar_badvpn_activos() {
    linea
    echo -e "        ${cor[3]}BADVPN UDPGW EXTREMO - JUEGOS ONLINE${cor[0]}"
    linea2
    if systemctl list-units --type=service --state=running 'badvpn-udpgw@*.service' 2>/dev/null | grep -q badvpn-udpgw@; then
        echo -e "   ${cor[4]}[ONLINE] BADVPN EXTREMO ACTIVO${cor[0]}"
    else
        echo -e "   ${cor[2]}[OFFLINE] BADVPN EXTREMO DESACTIVADO${cor[0]}"
    fi
    linea2
    if [[ -f "$PORTS_FILE" ]]; then
        echo -e "   ${cor[3]}Puertos configurados:${cor[0]}"
        while read -r p; do
            [[ -n "$p" ]] || continue
            if puerto_activo_badvpn "$p"; then
                echo -e "   [${cor[4]}ON${cor[0]}] BADVPN : $p"
            else
                echo -e "   [${cor[2]}OFF${cor[0]}] BADVPN : $p"
            fi
        done < "$PORTS_FILE"
    else
        echo -e "   ${cor[2]}No hay puertos configurados.${cor[0]}"
    fi
}

instalar_badvpn() {
    clean_screen
    echo "INSTALAR BADVPN EXTREMO"
    linea
    echo "Esta opcion instalara BADVPN para miles de usuarios"
    echo "Puertos default: 7200, 7300, 7400"
    echo "Modo: 1 servicio systemd independiente por puerto"
    linea
    fun_bar "instalar_base_badvpn" || return 1
    optimizar_badvpn_extremo
    descargar_badvpn || {
        linea
        echo "ERROR: No se pudo instalar badvpn-udpgw"
        echo "Revisa conexion a internet o paquetes de compilacion"
        linea
        read -p "Presiona ENTER para continuar..."
        return 1
    }
    if restart_badvpn; then
        linea
        echo "BADVPN UDPGW EXTREMO INSTALADO CON EXITO"
        echo "Puertos activos:"
        while read -r p; do [[ -n "$p" ]] && echo "BADVPN : $p"; done < "$PORTS_FILE"
        linea
    else
        linea
        echo "ERROR: BADVPN no pudo iniciar"
        echo "Ejecuta: systemctl status 'badvpn-udpgw@7200' --no-pager"
        echo "Ejecuta: journalctl -u 'badvpn-udpgw@7200' -n 80 --no-pager"
        linea
    fi
    read -p "Presiona ENTER para continuar..."
}

agregar_puerto_badvpn() {
    clean_screen
    echo "AGREGAR PUERTO BADVPN EXTREMO"
    linea
    crear_puertos_default_badvpn
    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea
    while true; do
        read -p "Nuevo puerto BADVPN: " NEWPORT
        valid_port "$NEWPORT" || { echo "Puerto invalido"; continue; }
        if grep -wq "$NEWPORT" "$PORTS_FILE"; then
            echo "Ese puerto ya esta agregado"
        else
            break
        fi
    done
    echo "$NEWPORT" >> "$PORTS_FILE"
    crear_puertos_default_badvpn
    crear_servicios_extremos
    abrir_firewall_badvpn
    systemctl enable "badvpn-udpgw@$NEWPORT" >/dev/null 2>&1 || true
    systemctl restart "badvpn-udpgw@$NEWPORT" >/dev/null 2>&1 || true
    sleep 1
    linea
    if puerto_activo_badvpn "$NEWPORT"; then
        echo "PUERTO AGREGADO CON EXITO"
        echo "BADVPN: $NEWPORT"
    else
        echo "ERROR: No se pudo iniciar el puerto $NEWPORT"
        echo "Revisa: journalctl -u badvpn-udpgw@$NEWPORT -n 80 --no-pager"
    fi
    linea
    read -p "Presiona ENTER para continuar..."
}

eliminar_puerto_badvpn() {
    clean_screen
    echo "ELIMINAR PUERTO BADVPN EXTREMO"
    linea
    if [[ ! -f "$PORTS_FILE" ]]; then
        echo "No hay puertos configurados"
        read -p "Presiona ENTER para continuar..."
        return 0
    fi
    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea
    read -p "Puerto a eliminar: " DELPORT
    valid_port "$DELPORT" || { echo "Puerto invalido"; read -p "Presiona ENTER para continuar..."; return 1; }
    if ! grep -wq "$DELPORT" "$PORTS_FILE"; then
        echo "Ese puerto no existe"
        read -p "Presiona ENTER para continuar..."
        return 1
    fi
    systemctl stop "badvpn-udpgw@$DELPORT" >/dev/null 2>&1 || true
    systemctl disable "badvpn-udpgw@$DELPORT" >/dev/null 2>&1 || true
    grep -vw "$DELPORT" "$PORTS_FILE" > /tmp/badvpn_ports.tmp
    mv /tmp/badvpn_ports.tmp "$PORTS_FILE"
    crear_puertos_default_badvpn
    systemctl daemon-reload >/dev/null 2>&1 || true
    linea
    echo "PUERTO ELIMINADO: $DELPORT"
    linea
    read -p "Presiona ENTER para continuar..."
}

reiniciar_todo_badvpn() {
    clean_screen
    echo "REINICIAR TODOS LOS PUERTOS BADVPN"
    linea
    if [[ -f "$PORTS_FILE" ]]; then
        while read -r p; do
            valid_port "$p" || continue
            systemctl restart "badvpn-udpgw@$p" >/dev/null 2>&1 || true
        done < "$PORTS_FILE"
    fi
    sleep 1
    mostrar_badvpn_activos
    linea
    read -p "Presiona ENTER para continuar..."
}

desinstalar_badvpn() {
    clean_screen
    echo "DESINSTALAR BADVPN EXTREMO"
    linea
    echo "Esta opcion eliminara BADVPN UDPGW completamente"
    linea
    read -p "¿Deseas continuar? [s/n]: " confirm
    [[ "$confirm" != "s" && "$confirm" != "S" ]] && return 0
    desinstalar_badvpn_completo() {
        if [[ -f "$PORTS_FILE" ]]; then
            while read -r p; do
                valid_port "$p" || continue
                systemctl stop "badvpn-udpgw@$p" >/dev/null 2>&1 || true
                systemctl disable "badvpn-udpgw@$p" >/dev/null 2>&1 || true
            done < "$PORTS_FILE"
        fi
        systemctl stop badvpn-udpgw.target >/dev/null 2>&1 || true
        systemctl disable badvpn-udpgw.target >/dev/null 2>&1 || true
        rm -f "$TEMPLATE_SERVICE" "$TARGET_SERVICE" "$PORTS_FILE" "$LOG_FILE"
        rm -rf "$LOG_DIR"
        rm -f /etc/sysctl.d/99-newgolden-badvpn-extremo.conf
        rm -f /etc/security/limits.d/99-newgolden-badvpn-extremo.conf
        rm -f /etc/systemd/system.conf.d/99-newgolden-badvpn-extremo.conf
        rm -f /etc/systemd/user.conf.d/99-newgolden-badvpn-extremo.conf
        # Limpia servicios viejos del panel anterior si existen.
        systemctl stop badvpn-udpgw.service >/dev/null 2>&1 || true
        systemctl disable badvpn-udpgw.service >/dev/null 2>&1 || true
        rm -f /etc/systemd/system/badvpn-udpgw.service
        rm -f /usr/local/sbin/badvpn-udpgw-runner /usr/local/sbin/badvpn-udpgw-stop
        sysctl --system >/dev/null 2>&1 || true
        systemctl daemon-reexec >/dev/null 2>&1 || true
        systemctl daemon-reload >/dev/null 2>&1 || true
        systemctl reset-failed >/dev/null 2>&1 || true
    }
    fun_bar "desinstalar_badvpn_completo"
    linea
    echo "BADVPN UDPGW EXTREMO ELIMINADO COMPLETAMENTE"
    linea
    read -p "Presiona ENTER para continuar..."
}

ver_estado_badvpn() {
    clean_screen
    mostrar_badvpn_activos
    linea2
    echo "Servicios activos:"
    systemctl list-units --type=service 'badvpn-udpgw@*.service' --no-pager 2>/dev/null || true
    linea2
    echo "Puertos BADVPN escuchando:"
    ss -ltnp 2>/dev/null | grep badvpn || echo "No hay puertos BADVPN activos"
    linea2
    echo "Logs recientes:"
    journalctl -u 'badvpn-udpgw@*' -n 25 --no-pager 2>/dev/null || echo "Sin logs"
    linea
    read -p "Presiona ENTER para continuar..."
}

gestor_fun () {
while true; do
clean_screen
mostrar_badvpn_activos
linea
echo -e "        ${cor[3]}ADMINISTRADOR BADVPN EXTREMO${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}INSTALAR / ACTIVAR BADVPN EXTREMO${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS"
echo -e "   ${cor[2]}[3]${cor[0]}  ELIMINAR PUERTO"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  VER ESTADO BADVPN"
echo -e "   ${cor[2]}[6]${cor[0]}  REINICIAR TODOS LOS PUERTOS"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea
opx=""
while [[ ! "$opx" =~ ^[0-6]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done
case "$opx" in
    0) return ;;
    1) instalar_badvpn ;;
    2) agregar_puerto_badvpn ;;
    3) eliminar_puerto_badvpn ;;
    4) desinstalar_badvpn ;;
    5) ver_estado_badvpn ;;
    6) reiniciar_todo_badvpn ;;
esac
done
}

gestor_fun
