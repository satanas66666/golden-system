#!/bin/bash
# BADVPN UDPGW - New Golden ADM PRO
# Compatible: Ubuntu 20/22/24 y Debian 10/11/12
# Correccion: no usa pkill -f para no matar el panel ("Terminated")

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-verd) shift; echo -e "${cor[4]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

BIN="/usr/local/bin/badvpn-udpgw"
BIN_ALT="/bin/badvpn-udpgw"
SERVICE="/etc/systemd/system/badvpn-udpgw.service"
RUNNER="/usr/local/sbin/badvpn-udpgw-runner"
STOPPER="/usr/local/sbin/badvpn-udpgw-stop"
PORTS_FILE="/etc/badvpn-ports.conf"
LOG_FILE="/tmp/badvpn_install.log"
RUNDIR="/run/badvpn-udpgw"

fun_bar () {
    local comando="$1"
    $comando >"$LOG_FILE" 2>&1 &
    local pid=$!

    local i=0 s
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando BADVPN UDPGW..." "$s"
        sleep 0.15
    done

    wait "$pid"
    local res=$?
    printf "\r\033[K"

    if [[ "$res" != "0" ]]; then
        echo "ERROR EN BADVPN UDPGW"
        tail -n 80 "$LOG_FILE"
        sleep 2
        return 1
    fi

    echo "OK - COMPLETADO"
    sleep 0.5
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

crear_puertos_default_badvpn() {
    if [[ ! -f "$PORTS_FILE" ]]; then
        {
            echo "7200"
            echo "7300"
            echo "7400"
        } > "$PORTS_FILE"
    fi
    sed -i '/^[[:space:]]*$/d' "$PORTS_FILE"
    sort -n -u "$PORTS_FILE" -o "$PORTS_FILE"
}

reparar_dpkg_apache() {
    # Evita que apache2 roto bloquee apt/dpkg durante instalacion de BADVPN.
    if dpkg -l apache2 >/dev/null 2>&1 || [[ -d /etc/apache2 ]]; then
        mkdir -p /etc/apache2/mods-enabled /etc/apache2/mods-available
        if [[ -e /etc/apache2/mods-available/mpm_event.load ]]; then
            rm -f /etc/apache2/mods-enabled/mpm_prefork.load /etc/apache2/mods-enabled/mpm_prefork.conf
            rm -f /etc/apache2/mods-enabled/mpm_worker.load  /etc/apache2/mods-enabled/mpm_worker.conf
            ln -sf ../mods-available/mpm_event.load /etc/apache2/mods-enabled/mpm_event.load
            [[ -e /etc/apache2/mods-available/mpm_event.conf ]] && ln -sf ../mods-available/mpm_event.conf /etc/apache2/mods-enabled/mpm_event.conf
        fi
    fi

    dpkg --configure -a >/dev/null 2>&1 || true
    apt-get -f install -y >/dev/null 2>&1 || true
}

instalar_base_badvpn() {
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1
    reparar_dpkg_apache

    apt-get update -y
    apt-get install -y wget curl net-tools iproute2 ca-certificates git cmake make gcc g++ build-essential
}

optimizar_badvpn_juegos() {
    mkdir -p /etc/sysctl.d /etc/security/limits.d /etc/systemd/system.conf.d /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-badvpn-games.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
    sysctl --system >/dev/null 2>&1 || true

cat >/etc/security/limits.d/99-newgolden-badvpn.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    systemctl daemon-reexec >/dev/null 2>&1 || true
    systemctl daemon-reload >/dev/null 2>&1 || true
}

descargar_badvpn() {
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN" 2>/dev/null || true
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi

    if [[ -x "$BIN" ]]; then
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi

    apt-get install -y badvpn >/dev/null 2>&1 || true

    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN"
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi

    rm -rf /tmp/badvpn-src
    git clone https://github.com/ambrop72/badvpn.git /tmp/badvpn-src >/dev/null 2>&1 || return 1

    cd /tmp/badvpn-src || return 1
    mkdir -p build
    cd build || return 1

    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >/dev/null 2>&1 || return 1
    make -j"$(nproc)" >/dev/null 2>&1 || return 1

    if [[ -x udpgw/badvpn-udpgw ]]; then
        cp udpgw/badvpn-udpgw "$BIN"
        chmod +x "$BIN"
        ln -sf "$BIN" "$BIN_ALT" 2>/dev/null || true
        return 0
    fi

    return 1
}

crear_runner_badvpn() {
cat > "$STOPPER" <<'EOF'
#!/bin/bash
set +e
RUNDIR="/run/badvpn-udpgw"

if [[ -d "$RUNDIR" ]]; then
    for f in "$RUNDIR"/*.pid; do
        [[ -f "$f" ]] || continue
        pid="$(cat "$f" 2>/dev/null)"
        if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" >/dev/null 2>&1; then
            kill "$pid" >/dev/null 2>&1
        fi
        rm -f "$f"
    done
fi

# Limpieza segura: solo mata procesos cuyo nombre real es badvpn-udpgw.
# No usa pkill -f porque eso puede matar el panel y causar "Terminated".
pgrep -x badvpn-udpgw 2>/dev/null | while read -r pid; do
    [[ "$pid" = "$$" ]] && continue
    kill "$pid" >/dev/null 2>&1 || true
done

sleep 1

pgrep -x badvpn-udpgw 2>/dev/null | while read -r pid; do
    kill -9 "$pid" >/dev/null 2>&1 || true
done

exit 0
EOF
chmod +x "$STOPPER"

cat > "$RUNNER" <<'EOF'
#!/bin/bash
set +e

BIN="/usr/local/bin/badvpn-udpgw"
PORTS_FILE="/etc/badvpn-ports.conf"
RUNDIR="/run/badvpn-udpgw"
LOG="/var/log/badvpn-udpgw.log"

mkdir -p "$RUNDIR"
touch "$LOG"
ulimit -n 1048576 >/dev/null 2>&1 || true

start_port() {
    local port="$1"
    [[ "$port" =~ ^[0-9]+$ ]] || return 1
    [[ "$port" -ge 1 && "$port" -le 65535 ]] || return 1

    # Si ya escucha en TCP, no lo dupliques.
    if ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(:|\\.)${port}$"; then
        return 0
    fi

    # Si hay PID viejo muerto, limpia.
    rm -f "$RUNDIR/$port.pid"

    "$BIN" \
        --listen-addr 0.0.0.0:"$port" \
        --max-clients 5000 \
        --max-connections-for-client 20 >>"$LOG" 2>&1 &

    echo $! > "$RUNDIR/$port.pid"
    sleep 0.3
}

stop_missing_ports() {
    for f in "$RUNDIR"/*.pid; do
        [[ -f "$f" ]] || continue
        port="$(basename "$f" .pid)"
        if ! grep -qx "$port" "$PORTS_FILE" 2>/dev/null; then
            pid="$(cat "$f" 2>/dev/null)"
            [[ "$pid" =~ ^[0-9]+$ ]] && kill "$pid" >/dev/null 2>&1 || true
            rm -f "$f"
        fi
    done
}

while true; do
    [[ -f "$PORTS_FILE" ]] || {
        echo "7200" > "$PORTS_FILE"
        echo "7300" >> "$PORTS_FILE"
        echo "7400" >> "$PORTS_FILE"
    }

    sed -i '/^[[:space:]]*$/d' "$PORTS_FILE"
    sort -n -u "$PORTS_FILE" -o "$PORTS_FILE"

    stop_missing_ports

    while read -r port; do
        [[ -n "$port" ]] || continue

        pidfile="$RUNDIR/$port.pid"
        pid=""
        [[ -f "$pidfile" ]] && pid="$(cat "$pidfile" 2>/dev/null)"

        if [[ "$pid" =~ ^[0-9]+$ ]] && kill -0 "$pid" >/dev/null 2>&1; then
            # Proceso vivo, pero confirmamos que el puerto escuche.
            if ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(:|\\.)${port}$"; then
                continue
            fi
            kill "$pid" >/dev/null 2>&1 || true
            rm -f "$pidfile"
        fi

        start_port "$port"
    done < "$PORTS_FILE"

    sleep 5
done
EOF
chmod +x "$RUNNER"
}

crear_servicio_badvpn() {
    crear_puertos_default_badvpn
    crear_runner_badvpn

cat > "$SERVICE" <<EOF
[Unit]
Description=BadVPN UDPGW MultiPort - New Golden Games
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$RUNNER
ExecStop=$STOPPER
Restart=always
RestartSec=2
StartLimitIntervalSec=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
KillMode=control-group
TimeoutStartSec=20
TimeoutStopSec=15

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

abrir_firewall_badvpn() {
    [[ -f "$PORTS_FILE" ]] || return 0

    if command -v ufw >/dev/null 2>&1; then
        while read -r p; do
            valid_port "$p" || continue
            ufw allow "$p"/tcp >/dev/null 2>&1 || true
            ufw allow "$p"/udp >/dev/null 2>&1 || true
        done < "$PORTS_FILE"
    fi

    if command -v iptables >/dev/null 2>&1; then
        while read -r p; do
            valid_port "$p" || continue
            iptables -C INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
            iptables -C INPUT -p udp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p udp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
        done < "$PORTS_FILE"
    fi
}

restart_badvpn() {
    descargar_badvpn || return 1
    crear_servicio_badvpn
    abrir_firewall_badvpn

    systemctl enable badvpn-udpgw >/dev/null 2>&1
    systemctl restart badvpn-udpgw >/dev/null 2>&1
    sleep 2

    systemctl is-active --quiet badvpn-udpgw || return 1

    # Confirmar al menos un puerto escuchando.
    while read -r p; do
        valid_port "$p" || continue
        if ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(:|\\.)${p}$"; then
            return 0
        fi
    done < "$PORTS_FILE"

    return 1
}

puerto_activo_badvpn() {
    local p="$1"
    ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(:|\\.)${p}$"
}

mostrar_badvpn_activos() {
    linea
    echo -e "        ${cor[3]}BADVPN UDPGW - JUEGOS ONLINE${cor[0]}"
    linea2

    if systemctl is-active --quiet badvpn-udpgw 2>/dev/null; then
        echo -e "   ${cor[4]}[ONLINE] SERVICIO BADVPN ACTIVO${cor[0]}"
    else
        echo -e "   ${cor[2]}[OFFLINE] SERVICIO BADVPN DESACTIVADO${cor[0]}"
    fi

    linea2

    if [[ -f "$PORTS_FILE" ]]; then
        echo -e "   ${cor[3]}Puertos configurados:${cor[0]}"
        while read -r p; do
            [[ -n "$p" ]] || continue
            if puerto_activo_badvpn "$p"; then
                echo -e "   [${cor[4]}ON${cor[0]}] BADVPN : $p"
            else
                echo -e "   [${cor[2]}OFF${cor[0]}] BADVPN : $p"
            fi
        done < "$PORTS_FILE"
    else
        echo -e "   ${cor[2]}No hay puertos configurados.${cor[0]}"
    fi
}

instalar_badvpn() {
    clean_screen
    echo "INSTALAR BADVPN"
    linea
    echo "Esta opcion instalara BADVPN para juegos online"
    echo "Puertos default: 7200, 7300, 7400"
    linea

    fun_bar "instalar_base_badvpn" || return 1
    optimizar_badvpn_juegos

    descargar_badvpn || {
        linea
        echo "ERROR: No se pudo instalar badvpn-udpgw"
        echo "Revisa conexion a internet o paquetes de compilacion"
        linea
        read -p "Presiona ENTER para continuar..."
        return 1
    }

    crear_servicio_badvpn

    if restart_badvpn; then
        linea
        echo "BADVPN UDPGW INSTALADO CON EXITO"
        echo "Puertos activos:"
        while read -r p; do
            [[ -n "$p" ]] && echo "BADVPN : $p"
        done < "$PORTS_FILE"
        linea
    else
        linea
        echo "ERROR: BADVPN no pudo iniciar"
        echo "Ejecuta: systemctl status badvpn-udpgw --no-pager"
        echo "Ejecuta: journalctl -u badvpn-udpgw -n 80 --no-pager"
        linea
    fi

    read -p "Presiona ENTER para continuar..."
}

agregar_puerto_badvpn() {
    clean_screen
    echo "AGREGAR PUERTO BADVPN UDPGW"
    linea

    crear_puertos_default_badvpn

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    while true; do
        read -p "Nuevo puerto BADVPN: " NEWPORT
        valid_port "$NEWPORT" || { echo "Puerto invalido"; continue; }

        if grep -wq "$NEWPORT" "$PORTS_FILE"; then
            echo "Ese puerto ya esta agregado"
        else
            break
        fi
    done

    echo "$NEWPORT" >> "$PORTS_FILE"
    sort -n -u "$PORTS_FILE" -o "$PORTS_FILE"

    if restart_badvpn; then
        linea
        echo "PUERTO AGREGADO CON EXITO"
        echo "BADVPN: $NEWPORT"
        linea
    else
        linea
        echo "ERROR: No se pudo reiniciar BADVPN"
        linea
    fi

    read -p "Presiona ENTER para continuar..."
}

eliminar_puerto_badvpn() {
    clean_screen
    echo "ELIMINAR PUERTO BADVPN UDPGW"
    linea

    if [[ ! -f "$PORTS_FILE" ]]; then
        echo "No hay puertos configurados"
        read -p "Presiona ENTER para continuar..."
        return 0
    fi

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    read -p "Puerto a eliminar: " DELPORT
    valid_port "$DELPORT" || {
        echo "Puerto invalido"
        read -p "Presiona ENTER para continuar..."
        return 1
    }

    if ! grep -wq "$DELPORT" "$PORTS_FILE"; then
        echo "Ese puerto no existe"
        read -p "Presiona ENTER para continuar..."
        return 1
    fi

    grep -vw "$DELPORT" "$PORTS_FILE" > /tmp/badvpn_ports.tmp
    mv /tmp/badvpn_ports.tmp "$PORTS_FILE"

    restart_badvpn

    linea
    echo "PUERTO ELIMINADO: $DELPORT"
    linea

    read -p "Presiona ENTER para continuar..."
}

desinstalar_badvpn() {
    clean_screen
    echo "DESINSTALAR BADVPN UDPGW"
    linea
    echo "Esta opcion eliminara BADVPN UDPGW completamente"
    linea

    read -p "¿Deseas continuar? [s/n]: " confirm
    [[ "$confirm" != "s" && "$confirm" != "S" ]] && return 0

    desinstalar_badvpn_completo() {
        systemctl stop badvpn-udpgw >/dev/null 2>&1 || true
        systemctl disable badvpn-udpgw >/dev/null 2>&1 || true

        [[ -x "$STOPPER" ]] && "$STOPPER" >/dev/null 2>&1 || true

        rm -f "$SERVICE" "$PORTS_FILE" "$LOG_FILE" "$RUNNER" "$STOPPER"
        rm -rf "$RUNDIR"

        rm -f /etc/sysctl.d/99-newgolden-badvpn-games.conf
        rm -f /etc/security/limits.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/system.conf.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/user.conf.d/99-newgolden-badvpn.conf

        sysctl --system >/dev/null 2>&1 || true
        systemctl daemon-reexec >/dev/null 2>&1 || true
        systemctl daemon-reload >/dev/null 2>&1 || true
        systemctl reset-failed >/dev/null 2>&1 || true
    }

    fun_bar "desinstalar_badvpn_completo"

    linea
    echo "BADVPN UDPGW ELIMINADO COMPLETAMENTE"
    linea

    read -p "Presiona ENTER para continuar..."
}

ver_estado_badvpn() {
    clean_screen
    mostrar_badvpn_activos
    linea2
    echo "Procesos activos:"
    pgrep -a -x badvpn-udpgw || echo "No hay procesos activos"
    linea2
    echo "Puertos BADVPN escuchando:"
    ss -ltnp 2>/dev/null | grep badvpn || echo "No hay puertos BADVPN activos"
    linea2
    echo "Estado systemd:"
    systemctl status badvpn-udpgw --no-pager 2>/dev/null | sed -n '1,18p' || echo "inactive"
    linea
    read -p "Presiona ENTER para continuar..."
}

gestor_fun () {
while true; do
clean_screen
mostrar_badvpn_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR BADVPN UDPGW${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}INSTALAR / ACTIVAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS"
echo -e "   ${cor[2]}[3]${cor[0]}  ELIMINAR PUERTO"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  VER ESTADO BADVPN"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) instalar_badvpn ;;
    2) agregar_puerto_badvpn ;;
    3) eliminar_puerto_badvpn ;;
    4) desinstalar_badvpn ;;
    5) ver_estado_badvpn ;;
esac
done
}

gestor_fun
