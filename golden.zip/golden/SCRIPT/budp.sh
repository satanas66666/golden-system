#!/bin/bash
# BADVPN UDPGW - NEW GOLDEN ADM PRO
# Compatible: Ubuntu 20/22/24 y Debian 10/11/12
# Corregido para instalar, desinstalar y reinstalar sin fallas.

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

Block="/etc/nanotxz"
[[ ! -d "$Block" ]] && exit 1

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ printf '%s\n' '════════════════════════════════════════'; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-verd) shift; echo -e "${cor[4]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

BIN="/usr/local/bin/badvpn-udpgw"
LEGACY_BIN="/bin/badvpn-udpgw"
SERVICE="/etc/systemd/system/badvpn-udpgw.service"
PORTS_FILE="/etc/badvpn-ports.conf"
LOG_FILE="/tmp/badvpn_install.log"
SRC_DIR="/tmp/badvpn-src"

fun_bar () {
    local comando="$1"
    $comando >"$LOG_FILE" 2>&1 &
    local pid=$!

    local i=0 s
    while kill -0 "$pid" >/dev/null 2>&1; do
        i=$((i + 1))
        case $((i % 4)) in
            0) s="/" ;;
            1) s="-" ;;
            2) s="\\" ;;
            3) s="|" ;;
        esac
        printf "\r [%s] Procesando BADVPN..." "$s"
        sleep 0.15
    done

    wait "$pid"
    local res=$?
    printf "\r\033[K"

    if [[ "$res" != "0" ]]; then
        echo "ERROR EN BADVPN"
        tail -n 80 "$LOG_FILE"
        sleep 2
        return 1
    fi

    echo "OK - COMPLETADO"
    sleep 0.5
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

pause_enter() {
    read -p "Presiona ENTER para continuar..."
}

crear_puertos_default_badvpn() {
    if [[ ! -f "$PORTS_FILE" ]]; then
        cat > "$PORTS_FILE" <<EOF
7200
7300
7400
EOF
    fi

    # Limpia duplicados, espacios y puertos invalidos.
    awk 'NF && $1 ~ /^[0-9]+$/ && $1 >= 1 && $1 <= 65535 {print $1}' "$PORTS_FILE" | sort -n -u > /tmp/badvpn_ports.clean
    mv /tmp/badvpn_ports.clean "$PORTS_FILE"
}

reparar_dpkg_apache() {
    # Apache roto puede bloquear cualquier apt install, aunque BADVPN no dependa de Apache.
    rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock >/dev/null 2>&1

    if dpkg -l apache2 >/dev/null 2>&1 || [[ -d /etc/apache2 ]]; then
        if [[ -d /etc/apache2/mods-enabled && -d /etc/apache2/mods-available ]]; then
            rm -f /etc/apache2/mods-enabled/mpm_*.load /etc/apache2/mods-enabled/mpm_*.conf >/dev/null 2>&1

            if [[ -f /etc/apache2/mods-available/mpm_event.load ]]; then
                ln -sf /etc/apache2/mods-available/mpm_event.load /etc/apache2/mods-enabled/mpm_event.load
                [[ -f /etc/apache2/mods-available/mpm_event.conf ]] && \
                    ln -sf /etc/apache2/mods-available/mpm_event.conf /etc/apache2/mods-enabled/mpm_event.conf
            elif [[ -f /etc/apache2/mods-available/mpm_prefork.load ]]; then
                ln -sf /etc/apache2/mods-available/mpm_prefork.load /etc/apache2/mods-enabled/mpm_prefork.load
                [[ -f /etc/apache2/mods-available/mpm_prefork.conf ]] && \
                    ln -sf /etc/apache2/mods-available/mpm_prefork.conf /etc/apache2/mods-enabled/mpm_prefork.conf
            fi
        fi
    fi

    dpkg --configure -a >/dev/null 2>&1 || true
    apt-get -f install -y >/dev/null 2>&1 || true
    dpkg --configure -a >/dev/null 2>&1 || true
}

instalar_base_badvpn() {
    reparar_dpkg_apache

    apt-get update -y || return 1
    apt-get install -y wget curl screen net-tools iproute2 ca-certificates \
        git cmake make gcc g++ build-essential lsof procps || return 1

    reparar_dpkg_apache
    return 0
}

optimizar_badvpn_juegos() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-badvpn-games.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1 || true

cat >/etc/security/limits.d/99-newgolden-badvpn.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden-badvpn.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    systemctl daemon-reexec >/dev/null 2>&1 || true
    systemctl daemon-reload >/dev/null 2>&1 || true
}

instalar_binario_desde_paquete() {
    apt-get install -y badvpn >/dev/null 2>&1 || return 1

    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || return 1
        chmod +x "$BIN"
        ln -sf "$BIN" "$LEGACY_BIN"
        return 0
    fi

    return 1
}

compilar_badvpn() {
    rm -rf "$SRC_DIR"
    git clone --depth=1 https://github.com/ambrop72/badvpn.git "$SRC_DIR" >/dev/null 2>&1 || return 1

    cd "$SRC_DIR" || return 1
    mkdir -p build
    cd build || return 1

    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >/dev/null 2>&1 || return 1
    make -j"$(nproc 2>/dev/null || echo 1)" >/dev/null 2>&1 || return 1

    if [[ -x udpgw/badvpn-udpgw ]]; then
        cp udpgw/badvpn-udpgw "$BIN" || return 1
        chmod +x "$BIN"
        ln -sf "$BIN" "$LEGACY_BIN"
        return 0
    fi

    return 1
}

descargar_badvpn() {
    if [[ -x "$BIN" ]]; then
        ln -sf "$BIN" "$LEGACY_BIN"
        return 0
    fi

    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null
        chmod +x "$BIN"
        ln -sf "$BIN" "$LEGACY_BIN"
        return 0
    fi

    instalar_binario_desde_paquete && return 0
    compilar_badvpn && return 0

    return 1
}

abrir_firewall_puertos() {
    [[ -f "$PORTS_FILE" ]] || return 0

    while read -r PORT; do
        valid_port "$PORT" || continue

        # BADVPN UDPGW escucha como TCP aunque se use para trafico UDP.
        iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT >/dev/null 2>&1 || \
            iptables -I INPUT -p tcp --dport "$PORT" -j ACCEPT >/dev/null 2>&1 || true

        # Se deja tambien UDP abierto para paneles/firewalls que lo exigen.
        iptables -C INPUT -p udp --dport "$PORT" -j ACCEPT >/dev/null 2>&1 || \
            iptables -I INPUT -p udp --dport "$PORT" -j ACCEPT >/dev/null 2>&1 || true

        if command -v ufw >/dev/null 2>&1; then
            ufw allow "$PORT"/tcp >/dev/null 2>&1 || true
            ufw allow "$PORT"/udp >/dev/null 2>&1 || true
        fi
    done < "$PORTS_FILE"

    if command -v netfilter-persistent >/dev/null 2>&1; then
        netfilter-persistent save >/dev/null 2>&1 || true
    elif command -v iptables-save >/dev/null 2>&1 && [[ -d /etc/iptables ]]; then
        iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
    fi
}

crear_servicio_badvpn() {
    crear_puertos_default_badvpn

cat > "$SERVICE" <<'EOF'
[Unit]
Description=BadVPN UDPGW MultiPort - New Golden
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'ulimit -n 1048576; pids=""; while read -r PORT; do case "$PORT" in ""|\#*) continue;; esac; if [[ "$PORT" =~ ^[0-9]+$ ]]; then /usr/local/bin/badvpn-udpgw --listen-addr 0.0.0.0:${PORT} --max-clients 5000 --max-connections-for-client 20 & pids="$pids $!"; fi; done < /etc/badvpn-ports.conf; trap "kill $pids 2>/dev/null" TERM INT; wait'
ExecStop=/bin/bash -c 'pkill -f "/usr/local/bin/badvpn-udpgw|/bin/badvpn-udpgw|badvpn-udpgw" || true'
Restart=always
RestartSec=2
StartLimitIntervalSec=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Nice=-5
KillMode=control-group
TimeoutStartSec=20
TimeoutStopSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

restart_badvpn() {
    descargar_badvpn || return 1
    crear_puertos_default_badvpn
    abrir_firewall_puertos
    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable badvpn-udpgw >/dev/null 2>&1
    systemctl restart badvpn-udpgw >/dev/null 2>&1
    sleep 1

    pgrep -f "badvpn-udpgw" >/dev/null 2>&1
}

puerto_escuchando() {
    local p="$1"
    ss -ltnp 2>/dev/null | grep -qE "[:.]${p}[[:space:]]"
}

mostrar_badvpn_activos() {
    linea
    echo -e "        ${cor[3]}BADVPN UDPGW - JUEGOS ONLINE${cor[0]}"
    linea2

    if systemctl is-active --quiet badvpn-udpgw || pgrep -f badvpn-udpgw >/dev/null 2>&1; then
        echo -e "   ${cor[4]}[ONLINE] BADVPN ACTIVO${cor[0]}"
    else
        echo -e "   ${cor[2]}[OFFLINE] BADVPN DESACTIVADO${cor[0]}"
    fi

    linea2

    if [[ -f "$PORTS_FILE" ]]; then
        echo -e "   ${cor[3]}Puertos configurados:${cor[0]}"
        while read -r p; do
            [[ -n "$p" ]] || continue
            if puerto_escuchando "$p"; then
                echo -e "   ${cor[4]}[ON]${cor[0]}  BADVPN : $p"
            else
                echo -e "   ${cor[2]}[OFF]${cor[0]} BADVPN : $p"
            fi
        done < "$PORTS_FILE"
    else
        echo -e "   ${cor[2]}No hay puertos configurados.${cor[0]}"
    fi
}

instalar_badvpn() {
    clean_screen
    echo "INSTALAR BADVPN"
    linea
    echo "Esta opcion instalara BADVPN para juegos online"
    echo "Puertos default: 7200, 7300, 7400"
    linea

    fun_bar "instalar_base_badvpn" || {
        linea
        echo "ERROR: No se pudo reparar apt/dpkg o instalar dependencias."
        echo "Revisa el log: $LOG_FILE"
        linea
        pause_enter
        return 1
    }

    optimizar_badvpn_juegos

    descargar_badvpn || {
        linea
        echo "ERROR: No se pudo instalar badvpn-udpgw"
        echo "Revisa conexion a internet o paquetes de compilacion"
        linea
        pause_enter
        return 1
    }

    crear_servicio_badvpn

    if restart_badvpn; then
        linea
        echo "BADVPN INSTALADO CON EXITO"
        echo "Puertos activos:"
        cat "$PORTS_FILE"
        linea
    else
        linea
        echo "ERROR: BADVPN no pudo iniciar"
        echo "Ejecuta: systemctl status badvpn-udpgw --no-pager"
        echo "Ejecuta: journalctl -u badvpn-udpgw -n 80 --no-pager"
        linea
    fi

    pause_enter
}

agregar_puerto_badvpn() {
    clean_screen
    echo "AGREGAR PUERTO BADVPN"
    linea

    crear_puertos_default_badvpn

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    while true; do
        read -p "Nuevo puerto BADVPN: " NEWPORT
        valid_port "$NEWPORT" || { echo "Puerto invalido"; continue; }

        if grep -xq "$NEWPORT" "$PORTS_FILE"; then
            echo "Ese puerto ya esta agregado"
        else
            break
        fi
    done

    echo "$NEWPORT" >> "$PORTS_FILE"
    crear_puertos_default_badvpn

    descargar_badvpn || {
        echo "ERROR: badvpn-udpgw no existe"
        pause_enter
        return 1
    }

    crear_servicio_badvpn

    if restart_badvpn; then
        linea
        echo "PUERTO AGREGADO CON EXITO"
        echo "BADVPN: $NEWPORT"
        linea
    else
        linea
        echo "ERROR: No se pudo reiniciar BADVPN"
        linea
    fi

    pause_enter
}

eliminar_puerto_badvpn() {
    clean_screen
    echo "ELIMINAR PUERTO BADVPN"
    linea

    if [[ ! -f "$PORTS_FILE" ]]; then
        echo "No hay puertos configurados"
        pause_enter
        return 0
    fi

    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea

    read -p "Puerto a eliminar: " DELPORT
    valid_port "$DELPORT" || {
        echo "Puerto invalido"
        pause_enter
        return 1
    }

    if ! grep -xq "$DELPORT" "$PORTS_FILE"; then
        echo "Ese puerto no existe"
        pause_enter
        return 1
    fi

    grep -vx "$DELPORT" "$PORTS_FILE" > /tmp/badvpn_ports.tmp
    mv /tmp/badvpn_ports.tmp "$PORTS_FILE"

    if [[ ! -s "$PORTS_FILE" ]]; then
        echo "7200" > "$PORTS_FILE"
    fi

    restart_badvpn

    linea
    echo "PUERTO ELIMINADO: $DELPORT"
    linea

    pause_enter
}

desinstalar_badvpn() {
    clean_screen
    echo "DESINSTALAR BADVPN"
    linea
    echo "Esta opcion eliminara BADVPN completamente"
    linea

    read -p "¿Deseas continuar? [s/n]: " confirm
    [[ "$confirm" != "s" && "$confirm" != "S" ]] && return 0

    desinstalar_badvpn_completo() {
        systemctl stop badvpn-udpgw >/dev/null 2>&1 || true
        systemctl disable badvpn-udpgw >/dev/null 2>&1 || true
        pkill -f badvpn-udpgw >/dev/null 2>&1 || true

        rm -f "$SERVICE"
        rm -f "$PORTS_FILE"
        rm -f "$LOG_FILE"
        rm -f "$BIN" "$LEGACY_BIN"

        rm -f /etc/sysctl.d/99-newgolden-badvpn-games.conf
        rm -f /etc/security/limits.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/system.conf.d/99-newgolden-badvpn.conf
        rm -f /etc/systemd/user.conf.d/99-newgolden-badvpn.conf

        sysctl --system >/dev/null 2>&1 || true
        systemctl daemon-reexec >/dev/null 2>&1 || true
        systemctl daemon-reload >/dev/null 2>&1 || true
        systemctl reset-failed >/dev/null 2>&1 || true

        rm -rf "$SRC_DIR"
    }

    fun_bar "desinstalar_badvpn_completo"

    linea
    echo "BADVPN ELIMINADO COMPLETAMENTE"
    linea

    pause_enter
}

ver_estado_badvpn() {
    clean_screen
    mostrar_badvpn_activos
    linea2
    echo "Procesos activos:"
    ps x | grep badvpn-udpgw | grep -v grep || echo "No hay procesos activos"
    linea2
    echo "Puertos BADVPN escuchando:"
    ss -ltnp 2>/dev/null | grep badvpn || echo "No hay puertos BADVPN activos"
    linea2
    echo "Estado systemd:"
    systemctl status badvpn-udpgw --no-pager 2>/dev/null | sed -n '1,12p' || echo "inactive"
    linea
    echo "Nota: BADVPN UDPGW escucha en TCP, aunque sirve para pasar trafico UDP de juegos."
    linea
    pause_enter
}

gestor_fun () {
while true; do
clean_screen
mostrar_badvpn_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR BADVPN${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}INSTALAR / ACTIVAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS"
echo -e "   ${cor[2]}[3]${cor[0]}  ELIMINAR PUERTO"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR BADVPN${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  VER ESTADO BADVPN"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) instalar_badvpn ;;
    2) agregar_puerto_badvpn ;;
    3) eliminar_puerto_badvpn ;;
    4) desinstalar_badvpn ;;
    5) ver_estado_badvpn ;;
esac
done
}

gestor_fun
