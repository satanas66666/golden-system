#!/bin/bash

# 🔥 FIX IMPORTANTE
shopt -s extglob

declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;32m" [3]="\033[1;36m" [4]="\033[1;31m" [5]="\033[1;33m" )

txt1="GENERADOR DE KEYS [ NEW-GOLDEN ADM PRO ]"
txt2="  EL DIABLO"
txt2_1=" LUCIFER"
txt3="   INSTALACIONES"
txt4=""
txt5=""

# COLORES (sin romper si tput falla)
fg_black="$(tput setaf 0 2>/dev/null || echo "")"
fg_red="$(tput setaf 1 2>/dev/null || echo "")"
fg_green="$(tput setaf 2 2>/dev/null || echo "")"
fg_yellow="$(tput setaf 3 2>/dev/null || echo "")"
fg_blue="$(tput setaf 4 2>/dev/null || echo "")"
fg_magenta="$(tput setaf 5 2>/dev/null || echo "")"
fg_cyan="$(tput setaf 6 2>/dev/null || echo "")"
fg_white="$(tput setaf 7 2>/dev/null || echo "")"
reset="$(tput sgr0 2>/dev/null || echo "")"

clear

BASICINST="menu PGet.py ports.sh budp.sh ADMbot.sh message.txt usercodes sockspy.sh POpen.py PPriv.py PPub.py PDirect.py speedtest.py speed.sh utils.sh dropbear.sh apacheon.sh openvpn.sh shadowsocks.sh ssl.sh squid.sh dados.sh Crear-Demo.sh squidpass.sh htop.sh gestor.sh shadowsocksLive.sh cambiarpass.sh Proxy-Publico.py Proxy-Privado.py ssrrmu.sh shadown.sh hora.sh panelweb.sh optimizar.sh v2ray.sh passvulrt.sh nload.sh bbr.sh ban_iptables.sh shadowsock.sh proxy_manager.sh"

IVAR="/etc/http-instas"
IVAR2="/etc/key-gerador"

# 🔥 evitar error si no existe
[[ ! -f $IVAR ]] && echo "0" > $IVAR

cabecalho_fun () {
BARRA="\033[0m\e[33m============================================================\033[1;37m"
echo -e "$BARRA"

echo -e "${fg_yellow}\t\t$txt1${reset}"
echo -e "\e[1;31m\t\t $txt2 ${fg_blue}$txt2_1${reset}"
echo -e "\e[3;36m\t\t$txt3: $(cat $IVAR 2>/dev/null)${reset}"

[[ -e $IVAR2 ]] && echo -e "\033[1;32mFIXKEY: $(cat $IVAR2)\033[0m"

SCPT_DIR="/etc/SCRIPT"
[[ ! -e ${SCPT_DIR} ]] && mkdir ${SCPT_DIR}

rm -f ${SCPT_DIR}/*.x.c &> /dev/null

INSTA_ARQUIVOS="ADMVPS.zip"
DIR="/etc/http-shell"
LIST="orp-nedlog"
}

meu_ip () {
MIP=$(ip addr 2>/dev/null | grep 'inet ' | grep -v inet6 | grep -v 127.0.0.1 | awk '{print $2}' | cut -d/ -f1 | head -n1)
MIP2=$(curl -s ipv4.icanhazip.com 2>/dev/null)
[[ "$MIP" != "$MIP2" && -n "$MIP2" ]] && IP="$MIP2" || IP="$MIP"
}

fun_trans () { 
local texto
local retorno

[[ ! -e  $HOME/ID ]] && local LANG=pt || local LANG="$(cat $HOME/ID)"

declare -A texto
[[ ! -e /etc/texto-adm ]] && touch /etc/texto-adm

source /etc/texto-adm 2>/dev/null

if [[ -z $(echo ${texto[$2]}) ]]; then

ENGINES=(aspell google deepl bing spell hunspell apertium yandex)

while [[ -z $retorno ]]; do
 local NUM="$(($RANDOM%${#ENGINES[@]}))"

 # 🔥 FIX: evitar error si no existe trans
 if command -v trans >/dev/null 2>&1; then
  retorno="$(trans -e ${ENGINES[$NUM]} -b pt:$LANG "$2" 2>/dev/null | sed -e 's/[^a-z0-9 -]//ig')"
 else
  retorno="$2"
 fi

done

echo "texto[$2]='$retorno'"  >> /etc/texto-adm
echo "$retorno"

else
echo "${texto[$2]}"
fi
}

meu_ip
cabecalho_fun

fun_list () {
unset KEY
KEY="$1"

[[ ! -e ${DIR} ]] && mkdir ${DIR}
[[ ! -e ${DIR}/${KEY} ]] && mkdir ${DIR}/${KEY}

i=0
for arqx in $(ls ${SCPT_DIR} 2>/dev/null); do
[[ $(echo $BASICINST | grep -w "${arqx}") ]] && continue
echo -e "[$i] -> FERRAMENTA \033[1;31m[${arqx}]\033[0m"
arq_list[$i]="${arqx}"
let i++
done

echo -e "[x] -> TODAS LAS HERRAMIENTAS"
echo -e "[b] -> \033[1;33mINSTALACION NEW-GOLDEN ADM PRO\033[0m"

read -p "ESCOJA LOS ARCHIVOS QUE SERAN INSTALADOS: " readvalue
[[ -z $readvalue ]] && readvalue="b"

read -p "NOMBRE DE USUARIO: " nombrevalue
[[ -z $nombrevalue ]] && nombrevalue="unnamed"

read -p "KEY FIJA? [S/N]: " -e -i n fixakey

[[ $fixakey = @(s|S|y|Y) ]] && read -p "IP-Fixo: " IPFIX && nombrevalue+=[FIXA]

if [[ $readvalue = @(b|B) ]]; then

arqslist="$BASICINST"
for arqx in `echo "${arqslist}"`; do
[[ -e ${DIR}/${KEY}/$arqx ]] && continue
cp ${SCPT_DIR}/$arqx ${DIR}/${KEY}/ 2>/dev/null
echo "$arqx" >> ${DIR}/${KEY}/${LIST}
done

elif [[ $readvalue = @(x|X) ]]; then

for arqx in `echo "${arq_list[@]}"`; do
[[ -e ${DIR}/${KEY}/$arqx ]] && continue
cp ${SCPT_DIR}/$arqx ${DIR}/${KEY}/
echo "$arqx" >> ${DIR}/${KEY}/${LIST}
done

echo "TRUE" >> ${DIR}/${KEY}/HERRAMIENTA

else

for arqx in `echo "${readvalue}"`; do
[[ -e ${DIR}/${KEY}/${arq_list[$arqx]} ]] && continue
cp ${SCPT_DIR}/${arq_list[$arqx]} ${DIR}/${KEY}/
echo "${arq_list[$arqx]}" >> ${DIR}/${KEY}/${LIST}
done

echo "TRUE" >> ${DIR}/${KEY}/HERRAMIENTA

fi

echo "$nombrevalue" > ${DIR}/${KEY}.name
[[ ! -z $IPFIX ]] && echo "$IPFIX" > ${DIR}/${KEY}/keyfixa

echo -e "$BARRA"
echo -e "KEY ACTIVA, Y ESPERANDO INSTALACION!"
echo -e "$BARRA"
}

ofus () {
unset txtofus
number=$(expr length "$1")

for((i=1; i<$number+1; i++)); do
txt[$i]=$(echo "$1" | cut -b $i)

case ${txt[$i]} in
".")txt[$i]="+";;
"+")txt[$i]=".";;
"1")txt[$i]="@";;
"@")txt[$i]="1";;
"2")txt[$i]="?";;
"?")txt[$i]="2";;
"3")txt[$i]="%";;
"%")txt[$i]="3";;
"/")txt[$i]="K";;
"K")txt[$i]="/";;
esac

txtofus+="${txt[$i]}"
done

echo "$txtofus" | rev
}

gerar_key () {
valuekey="$(date | md5sum | head -c10)"
valuekey+="$(echo $(($RANDOM*10))|head -c 5)"

fun_list "$valuekey"

keyfinal=$(ofus "$IP:8888/$valuekey/$LIST")

echo -e "KEY: $keyfinal\nGerada!"
echo -e "$BARRA"
read -p "Enter to Finalize"
}

start_gen () {
unset PIDGEN
PIDGEN=$(ps aux | grep -v grep | grep "http-server.sh")

if [[ ! $PIDGEN ]]; then
screen -dmS generador /bin/http-server.sh -start
else
killall http-server.sh 2>/dev/null
fi
}

message_gen () {
read -p "NEW MESSAGE: " MSGNEW
echo "$MSGNEW" > ${SCPT_DIR}/message.txt
echo -e "$BARRA"
}

atualizar_geb () {
wget -O $HOME/instger.sh https://www.dropbox.com/s/w0s2rv92wy7z3fq/instgerador.sh?dl=0 &>/dev/null
chmod +x $HOME/instger.sh
cd $HOME
./instger.sh
rm $HOME/instger.sh &>/dev/null
}

meu_ip
id=pt

unset PID_GEN
PID_GEN=$(ps x | grep -v grep | grep "http-server.sh")
[[ ! $PID_GEN ]] && PID_GEN="\033[1;31moff" || PID_GEN="\033[1;32monline"

echo -e "$BARRA"
echo -e "\033[93mGENERADOR DE KEYS PARA [ NEW-GOLDEN ADM PRO ]\033[0m"
echo -e "$BARRA"
echo -e "${fg_red}[1] = GENERAR 1 KEY ALEATORIA${reset}"
echo -e "${fg_cyan}[2] = APAGAR/BORRAR KEYS${reset}"
echo -e "${fg_cyan}[3] = LIMPAR KEYS USADAS${reset}"
echo -e "${fg_cyan}[4] = INICIAR/PARAR KEYGEN $PID_GEN\033[0m"
echo -e "${fg_cyan}[5] = VER REGISTRO${reset}"
echo -e "${fg_cyan}[6] = CAMBIAR MENSAGE EN NEW-ULTIMATE${reset}"
echo -e "${fg_cyan}[7] = ACTUALIZAR KEYS FIJA${reset}"
echo -e "${fg_cyan}[8] = ACTUALIZAR GENERADOR${reset}"
echo -e "${fg_red}[0] = SALIR${reset}"
echo -e "$BARRA"

while [[ ${varread} != @([0-8]) ]]; do
read -p "Opcion: " varread
done

echo -e "$BARRA"

if [[ ${varread} = 0 ]]; then
exit
elif [[ ${varread} = 1 ]]; then
gerar_key
elif [[ ${varread} = 2 ]]; then
remover_key
elif [[ ${varread} = 3 ]]; then
remover_key_usada
elif [[ ${varread} = 4 ]]; then
start_gen
elif [[ ${varread} = 5 ]]; then
echo -ne "\033[1;36m"
cat /etc/gerar-sh-log 2>/dev/null || echo "NO HAY REGISTROS EN ESTE MOMENTO"
echo -ne "\033[0m" && read -p "Enter"
elif [[ ${varread} = 6 ]]; then
message_gen
elif [[ ${varread} = 7 ]]; then
atualizar_keyfixa
elif [[ ${varread} = 8 ]]; then
atualizar_geb
fi

# 🔥 evita bug de recursión infinita si algo falla
exit 0

